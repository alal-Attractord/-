













import json
import os
import re as _re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

TEMPLATE = {
    "name": "实验名（如 R21 观测通道改写）",
    "claim": "一句话要证明的命题（越具体越好）",
    "arms": [
        {"name": "res", "type": "candidate", "seeds": 5, "reports_sd": True},
        {"name": "lstm", "type": "opponent", "seeds": 5, "reports_sd": True},
        {"name": "mlp", "type": "plain_baseline", "seeds": 3, "reports_sd": True},
        {"name": "ridge/knn 等闭式臂", "type": "opponent", "seeds": None,
         "reports_sd": True, "deterministic": True, "n_boot": 30},
    ],
    "systems": ["Lorenz", "Rossler", "Lorenz6"],
    "horizons": [1, 2, 5, 10, 20, 40, 80],
    "budget_parity": True,
    "zero_train_baselines": ["persist", "diff1", "diff2"],
    "protocols": {"ours": "base", "opponent_native": "base",
                  "match": True, "verified_from_source": True},
    "claim_types": [],
    "selector_oracle_upper_bound": False,
    "opponent_same_trick_control": False,
    "cross_env_claim": False,
    "novelty_claim": False,
    "literature_placeholder": False,
    "constraint": None,
    "constraint_measured_effect": None,
    "spectral_metric": {
        "used": False,
        "estimator": "rho(K) / 谱读数 / 由特征值推的 Lyapunov",
        "basis_kappa2": None,
        "sigma_max_crosscheck": False,
        "inv_error": None,
        "inv_error_bound_kappa_eps": None,
    },
    "max_ratio_claimed": 1.0,
    "zero_train_swept": None,
    "fix_regression": {
        "changed": False,
        "perf_after_vs_before": None,
        "defect_acted_as_regularizer_checked": False,
        "regularizer_note": "",
    },
    "excluded_baselines": [{"name": "tf", "reason": "自建稻草人，不作为对手"}],
    "notes": "",
}





def _arms(d):
    return d.get("arms") or []


def _live_arms(d):
    






    return [a for a in _arms(d) if not a.get("retired", False)]


def _retired_note(d):
    ret = [a for a in _arms(d) if a.get("retired", False)]
    if not ret:
        return ""
    return ("；**已退役 %d 臂（不计入证据，须在报告披露）**：%s"
            % (len(ret), [a.get("name", "?") for a in ret]))


def _unc_ok(a):
    











    if int(a.get("seeds", 0) or 0) >= 3:
        return True, "seeds>=3"
    if a.get("deterministic") and int(a.get("n_boot", 0) or 0) >= 30:
        return True, "确定性臂 + 自助 %d 次" % int(a.get("n_boot") or 0)
    if a.get("zero_param_formula") and a.get("reports_sd"):
        return True, "零参数固定公式(无随机性) + 已报分布"
    return False, "seeds=%s 且非(确定性+自助>=30) 且非(零参数公式+报分布)" % a.get("seeds")


def c01_seeds(d):
    bad = []
    for a in _live_arms(d):
        ok, why = _unc_ok(a)
        if not ok:
            bad.append("%s (%s)" % (a["name"], why))
    if bad:
        return "FAIL", f"这些臂的不确定度来源不合格：{bad}（铁律 9/15）"
    return "PASS", ("全部臂不确定性合格（共 %d 臂；闭式臂用自助重采样）%s"
                    % (len(_live_arms(d)), _retired_note(d)))


def c02_meansd(d):
    bad = [a["name"] for a in _live_arms(d) if not a.get("reports_sd", False)]
    if bad:
        return "FAIL", f"这些臂未报 mean±sd：{bad}（铁律 15：单点数字不得入判决表）"
    return "PASS", "全部臂均声明报 mean±sd%s" % _retired_note(d)


def c03_plain_baseline(d):
    types = {a.get("type") for a in _arms(d)}
    if "plain_baseline" not in types:
        return "FAIL", "**没有同参数量级的最普通基线**（铁律 44：`mlp` 一入列就把 7/7 变成 2/7）"
    nb = [a["name"] for a in _arms(d) if a.get("type") == "plain_baseline"]
    return "PASS", f"含最普通基线：{nb}"


def c04_budget(d):
    if not d.get("budget_parity", False):
        return "FAIL", "预算/视界未配平（铁律 8/29：预算不齐的比较无效，须用比例上界封堵）"
    return "PASS", "已声明预算/视界配平"


def c05_protocol_match(d):
    p = d.get("protocols") or {}
    if not p:
        return "FAIL", "未声明协议同构性（铁律 45）"
    if not p.get("match", False):
        return "FAIL", (f"协议不同构：ours={p.get('ours')} vs opponent_native="
                        f"{p.get('opponent_native')} ⇒ 可能是**假翻盘**（R15 教训）")
    return "PASS", f"协议同构：{p.get('ours')} == {p.get('opponent_native')}"


def c06_protocol_source(d):
    p = d.get("protocols") or {}
    if not p.get("verified_from_source", False):
        return "FAIL", ("未声明「已读过对手 `forward_roll` 源码确认 k=0 输入」"
                        "（铁律 45 前置：口径错配是本项目最大坑，造出过完整的假胜利）")
    return "PASS", "已从对手源码核实 k=0 输入"


def c07_zero_train(d):
    ct = set(d.get("claim_types") or [])
    if "short_horizon" not in ct:
        return "PASS", "不涉短程指标，跳过"
    zt = d.get("zero_train_baselines") or []
    if not zt:
        return "FAIL", ("断言短程指标但**未跑零训练外推基线**（铁律 48）："
                        "零参数 `diff2` @1 已胜过全部训练模型，该指标不构成架构证据")
    has_d2 = any("diff2" in str(x) for x in zt)
    has_p1 = any(("persist" in str(x)) or ("常值" in str(x)) or ("常数" in str(x)) or
                 ("最后值" in str(x)) or ("naive" in str(x).lower()) for x in zt)
    if not (has_d2 and has_p1):
        missing = ([] if has_d2 else ["diff2(二阶差分)"]) + \
                  ([] if has_p1 else ["persist(最后值外推)"])
        return "WARN", (f"含零训练基线 {zt}，但**未含 {missing}**。"
                        "注意：哪个零参数基线最强是**场地特异**的，须实测后写进报告 —— "
                        "本项目实测（`_real_zeroparam_arm.py`, 60 条真实记录）："
                        "persist 中位 6.33× 冠军 / diff1 12.37× / diff2 28.65×，"
                        "即噪声真实序列上 persist 最强；而合成/光滑序列上 diff2 可最强。")
    return "PASS", f"含零训练基线：{zt}"


def c08_selector(d):
    ct = set(d.get("claim_types") or [])
    need = ("selector" in ct) or ("ensemble" in ct)
    if not need:
        return "PASS", "不涉选择器/集成，跳过"
    miss = []
    if not d.get("selector_oracle_upper_bound", False):
        miss.append("**oracle 上界**（偷看真值挑最好分支）")
    if not d.get("opponent_same_trick_control", False):
        miss.append("**对手获得同一技巧的对照**（如 E_mlp）")
    if miss:
        return "FAIL", ("断言选择器/集成类结论但缺：" + "、".join(miss)
                        + "（铁律 50：只报「集成比单模型好」是普适技巧，不构成架构证据）")
    return "PASS", "已含 oracle 上界 + 对手同技巧对照"


def c09_long_horizon(d):
    hs = d.get("horizons") or []
    if not hs or max(hs) < 40:
        return "PASS", "不涉 @40+，跳过"
    bad = []
    for a in _arms(d):
        ok, why = _unc_ok(a)
        if not ok:
            bad.append("%s (%s)" % (a["name"], why))
    if bad:
        return "FAIL", f"含 @40+ 但 {bad} 不确定度来源不合格（铁律 27）"
    return "PASS", f"@40+ 且全部臂不确定性合格（max horizon = {max(hs)}）"


def c10_cross_env(d):
    if not d.get("cross_env_claim", False):
        return "PASS", "非跨环境断言，跳过"
    n = len(d.get("systems") or [])
    if n < 3:
        return "FAIL", f"断言跨环境但只有 {n} 个系统（铁律 1：须跨任务×环境×种子×尺度×制度）"
    return "PASS", f"跨 {n} 个系统"


def c11_anomaly(d):
    r = float(d.get("max_ratio_claimed", 1.0) or 1.0)
    if r < 3.0:
        return "PASS", f"最大申报比值 {r:.2f}× < 3×"
    p = d.get("protocols") or {}
    if not p.get("verified_from_source", False):
        return "FAIL", f"申报比值 {r:.2f}× ≥3× 但未核实口径（铁律 6/23：异常好 3× 以上先查口径）"
    return "WARN", f"申报比值 {r:.2f}× ≥3×，已声明核实口径 —— 建议附原始日志"


def c12_novelty(d):
    









    if not d.get("novelty_claim", False):
        return "PASS", "未主张新颖性，跳过"
    if not d.get("literature_placeholder", False):
        return "FAIL", ("主张新颖性但**未做逐成分文献占位**（铁律 40）："
                        "本项目两次栽在这——成分与组合均已被 DCRNN 2019 / DeepKoopFormer 2026 占位")

    tbl = d.get("literature_placeholders") or []
    if not tbl:
        return "FAIL", ("`literature_placeholder=true` 但**未附逐成分占位表**。"
                        "布尔占位不算占位：必须给 `literature_placeholders`: "
                        "[{component, occupier, difference}]，逐格说清「谁占了」与「差别在哪」。")
    missing = [str(e.get("component") or "?") for e in tbl
               if not str(e.get("component") or "").strip()
               or not str(e.get("occupier") or "").strip()
               or not str(e.get("difference") or "").strip()]
    if missing:
        return "FAIL", (f"占位表有 {len(missing)} 条缺字段（component/occupier/difference 三项必填）："
                        + "；".join(missing[:4]))

    scope = str(d.get("novelty_scope") or "").strip().lower()
    if scope not in ("component", "combination", "principle"):
        return "FAIL", ("已附占位表但**未声明新颖性层级** `novelty_scope` ∈ "
                        "{component, combination, principle}。不声明层级 = 默认暗示原理级，"
                        "而在逐成分已被占位时这是过度主张。")
    if scope == "principle":
        return "FAIL", (f"声明 `novelty_scope=principle`（原理级）但有 {len(tbl)} 个成分已被占位 ⇒ "
                        "自相矛盾：原理级新颖要求**无任何成分被占位**。应降级为 combination。")
    if scope == "combination":
        cell = str(d.get("unoccupied_cell") or "").strip()
        if not cell:
            return "FAIL", ("层级为 `combination`（组合级）但**未指明残留的未被占位格** "
                            "`unoccupied_cell`。组合级新颖的全部价值就在于那一格，必须写出来。")
        return "PASS", (f"逐成分占位 {len(tbl)} 条全部完整；层级 = **combination**；"
                        f"残留未占位格 = 「{cell[:80]}{'…' if len(cell) > 80 else ''}」")
    if len(tbl) < 3:
        return "WARN", f"层级 = component（单成分），占位表仅 {len(tbl)} 条，建议补齐同族其他成分"
    return "PASS", f"逐成分占位 {len(tbl)} 条完整；层级 = **component**"


def c13_constraint(d):
    if not d.get("constraint"):
        return "PASS", "未主张约束类结论，跳过"
    if d.get("constraint_measured_effect") in (None, "", []):
        return "FAIL", (f"主张约束 `{d['constraint']}` 生效但**未实测被约束对象的真实量**"
                        "（铁律 41：`Proj_ρ` 只作用 `K`，实测 σ_max(∂h'/∂h)=1.07–1.18 > ρ）")
    return "PASS", f"约束 `{d['constraint']}` 已实测生效量：{d['constraint_measured_effect']}"


def c14_strawman(d):
    ex = d.get("excluded_baselines") or []
    if not ex:
        return "WARN", "未列出**被显式排除的基线及理由**（铁律 22：基线须自证不是稻草人）"
    return "PASS", "已显式排除并说明：" + "；".join(f"{e['name']}（{e['reason']}）" for e in ex)


def c15_spectral(d):
    
    sm = d.get("spectral_metric")
    if not sm or not sm.get("used", False):
        return "PASS", "未用谱读数类指标做增长/稳定性判断，跳过"
    est = sm.get("estimator", "(未填)")
    k2 = sm.get("basis_kappa2")
    if k2 in (None, ""):
        return "FAIL", (f"用了谱读数 `{est}` 但**未量基的条件数 κ₂**（铁律 56：非正规算子下"
                        "(1/H)logρ ≤ 真FTLE ≤ (1/H)logρ+(1/H)logκ₂ ⇒ 谱读数只是下界，"
                        "κ₂ 无界时读数可任意错误乃至变号）")
    k2 = float(k2)
    xc = bool(sm.get("sigma_max_crosscheck", False))
    ie, bd = sm.get("inv_error"), sm.get("inv_error_bound_kappa_eps")
    note = ""
    if ie is not None and bd not in (None, 0) and float(ie) < 0.01 * float(bd):
        note = "；实测求逆误差 ≪ κ·ε 上界 ⇒ 探针失效应归因**结构**而非浮点噪声"
    if k2 > 3.0 and not xc:
        return "FAIL", (f"κ₂={k2:g} > 3 且**未做 σ_max 交叉校验**：谱读数 `{est}` 与实际增长率"
                        "可能符号相反（本项目实例：ρ=0.9949 ⇒ λ̂=−1.018，真值 +0.906）")
    return "PASS", f"κ₂={k2:g}，谱读数与 σ_max 的差距 ≤ (1/H)log κ₂" + (f"，已交叉校验{note}" if xc else note)


def c16_fix_regression(d):
    




    fr = d.get("fix_regression")
    if not fr or not fr.get("changed", False):
        return "PASS", "未申报缺陷修复类改动，跳过"
    perf = fr.get("perf_after_vs_before")
    if perf is None:
        return "FAIL", "申报了缺陷修复但**未报修改前后的性能对比**（铁律 57）"
    perf = float(perf)
    if perf > 1.0:
        if not fr.get("defect_acted_as_regularizer_checked", False):
            return "FAIL", (f"修复后性能**变差 {perf:.2f}×** 但未检查被修缺陷是否在起正则化作用"
                            "（铁律 57；本项目实例：冻结幂次=强收缩，修掉后 @80 退化 2.87×）")
        note = fr.get("regularizer_note", "")
        return "WARN", f"修复后性能变差 {perf:.2f}×，已说明缺陷的正则化作用{('：' + note) if note else ''}"
    return "PASS", f"修复后性能未变差（比值 {perf:.2f}×）"


def c17_zero_train_swept(d):
    





    z = d.get("zero_train_baselines") or []
    if not z:
        return "FAIL", "未声明任何零训练基线（铁律 48）"
    swept = d.get("zero_train_swept")
    if not swept:
        return "FAIL", (f"列了 {len(z)} 条零训练基线但**未说明是否扫过它们自己的超参**"
                        "（铁律 58：窗口 W / 近邻 k。本项目实例：单点线性 8.5e-4 → 扫 W 后 5.55e-18）")
    detail = swept if isinstance(swept, str) else str(swept)
    weak = [b for b in z if isinstance(b, str) and b in ("persist", "diff1", "diff2")]
    note = ""
    if weak and "W" not in detail and "窗口" not in detail:
        note = "；注意 diff1/diff2 只是 W=3 的一个特定线性组合，最优 W 点仿射更强"
    return "PASS", f"已扫零训练基线超参：{detail}{note}"


def c18_device_batch(d):
    




    dev = d.get("device_claim")
    if not dev:
        return "PASS", "未做设备快慢断言，跳过"
    sweep = dev.get("ms_per_iter_vs_batch")
    if not sweep:
        return "FAIL", ("断言设备快慢但**未扫 `ms/iter vs batch`**（铁律 60）。本项目实例："
                        "B=64 下判「GPU 慢 3.1×」是错的，扫到 B=8192 实为快 11.9×")
    return "PASS", f"已扫 ms/iter vs batch：{sweep}"


def c19_gpu_concurrency(d):
    
    g = d.get("gpu_parallelism")
    if not g or not g.get("multi_process", False):
        return "PASS", "未用多进程并行 GPU，跳过"
    lim = g.get("measured_concurrency_limit")
    if lim in (None, ""):
        return "FAIL", ("多进程并行用 GPU 但**未实测量并发上限**（铁律 61）。本项目实例："
                        "8 路 → 整机黑屏 TDR；2 路 → 两个都静默挂起；实测安全上限 = 1")
    return "PASS", f"已实测并发安全上限 = {lim}"


def _strip_negated(s):
    









    NEG = ("不", "禁", "勿", "别", "非", "无", "never", "not ", "no ", "n't",
           "without", "avoid")
    body = _re.sub(r"[（(][^）)]*[）)]", " ", s)
    keep = []
    for seg in _re.split(r"[;,，；。.、\n]", body):
        low = seg.lower()
        if any(t in low for t in NEG):
            continue
        keep.append(seg)
    out = " ".join(keep).strip()
    return out if out else s


def c20_val_not_test(d):
    
    bs = d.get("baseline_hparam_sweep")
    if not bs:
        return "PASS", "未申报基线超参扫描，跳过"
    raw = str(bs.get("selected_on", ""))
    sel = _strip_negated(raw).lower()
    if "test" in sel or "测试" in sel or "a_cont" in sel:
        return "FAIL", (f"基线超参在 **{bs.get('selected_on')}** 上选 ⇒ 数据泄漏（铁律 62）。"
                        "本项目实例：`rec[\"A_cont\"][\"nll\"]`（A_cont 即测试集）挑 W/k，"
                        "使 KNN @80 NLL 虚高至 3.126；改用独立 val 后为 278.978")
    if not sel:
        return "WARN", "未说明基线超参在哪个集合上选（铁律 62：须为独立验证集）"
    return "PASS", f"基线超参选择集 = {bs.get('selected_on')}"


def c21_probabilistic_var_floor(d):
    
    p = d.get("probabilistic_objective")
    if not p or not p.get("used", False):
        return "PASS", "未用概率目标，跳过"
    if not p.get("learnable_variance", False) or not p.get("variance_floor_or_clamp"):
        return "PASS", "概率目标未同时使用可学习方差与方差下界，跳过"
    if not p.get("grad_scale_checked", False):
        return "FAIL", ("NLL + 可学习方差 + 方差 clamp/floor 但**未查梯度放大**（铁律 63）。"
                        "本项目实例：地板 1e-12 ⇒ 方差梯度实测恒为 0、1/v=1e12 使梯度范数达 1.2e4、"
                        "`clip_grad_norm_(1.0)` 把步进方向交给 @1/@5 的舍入噪声"
                        "（共享梯度份额 @1 66%／@5 34%／**@80 0.0%**），每步都在破坏已有精确解，"
                        "专训 @80 也把 @80 训坏 2.9×")
    clip = str(p.get("grad_clip_scope", "")).lower()
    if not p.get("mean_var_decoupled", False) or "global" in clip or "全局" in clip:
        return "WARN", ("已查梯度放大，但仍有风险组合（铁律 63 修法：均值/方差**解耦两阶段**；"
                        "地板用 **softplus 下界替代 clamp**；**按视界分别裁剪**而非全局裁剪）")
    return "PASS", "已查梯度放大，且已用解耦 / softplus / 分视界裁剪"


def c22_local_baseline_present(d):
    
    z = d.get("zero_train_baselines") or []
    bl = d.get("baselines") or []
    allb = [str(x).lower() for x in list(z) + list(bl)]
    if not allb:
        return "PASS", "未声明基线，跳过（注意 C03 会单独判 FAIL）"
    KEY = ("knn", "k-nn", "近邻", "local", "局部", "nearest", "rf", "随机森林",
           "gpr", "gaussian process", "高斯过程", "spline", "样条", "interp", "插值")
    if not any(any(k in b for k in KEY) for b in allb):
        return "FAIL", ("基线族里**没有任何局部/非参方法**，只有全局参数模型 ⇒ 稻草人（铁律 64）。"
                        "本项目实例：拿「全局仿射 + kNN 局部**均值**」当基线，补上「kNN 局部**仿射**」"
                        "后真对手强 **3.5e5×**（τ=0.1: 1.71e-3 vs 2.57e-9），判决从「勉强接近」变成「差 2e5×」")

    loc = [b for b in allb if any(k in b for k in KEY)]
    FIT = ("affine", "仿射", "linear", "线性", "regress", "回归", "lstsq",
           "最小二乘", "ridge", "岭", "spline", "样条", "gpr", "高斯过程", "forest", "森林")
    if not any(any(k in b for k in FIT) for b in loc):
        return "WARN", ("局部方法只有**零阶（均值/质心）**一类，缺少**局部拟合（仿射/最小二乘）**。"
                        "本项目实例：局部均值比局部仿射弱 **1e6/1e4/1e2**（τ=0.1/0.2/0.4）⇒ 仍是弱对手")
    return "PASS", "基线族含局部/非参方法（且含局部拟合类）"


def c23_physical_scale_aligned(d):
    
    sc = d.get("scale_sweep")
    if not sc or not sc.get("used", False):
        return "PASS", "未做跨尺度/跨步长比较，跳过"
    if not sc.get("aligned_by_physical_quantity"):
        return "FAIL", ("跨步长/采样率比较但**按步数对齐**（铁律 65）。本项目实例：原协议 dt=0.005 的 @80 是"
                        "τ=0.4，dt=0.02 的 @80 是 τ=1.6，难度完全不同；按 **τ=h·dt** 对齐后才得到"
                        "干净结论——**线性失效点与 dt 无关，恒为 τ≈0.2（0.18 个 Lyapunov 时间）**")
    return "PASS", f"已按物理量对齐：{sc.get('physical_quantity', '(未填)')}"


def c24_paradigm_varied(d):
    
    neg = d.get("negative_novelty_claim")
    if not neg or not neg.get("claims_task_impossible", False):
        return "PASS", "未做『任务不可做』类否定断言，跳过"
    if not neg.get("paradigms_tested"):
        return "FAIL", ("断言任务不可做，但**只测了一个范式**（铁律 66）。本项目实例：据「全局仿射/局部均值/"
                        "局部仿射/局部二次在 τ>0.8 全退化到 0.12~0.13」宣布**「τ>0.8 信息论关闭」**——"
                        "**错**。上面每个变体都是「直接 h 步映射」（窗口一步回归到 x_{t+h}），"
                        "我把**基线族**的性质当成了**任务**的性质。换成「学单步 + 自回归 rollout」后："
                        "τ=0.8 从 1.35e-01 → **5.67e-06（好 2.4e4×）**，τ=2.4（2.17 Lyap.）仍有 **3.42e-04**")
    if neg.get("paradigm_varied"):
        return "PASS", f"已换范式复核：{neg.get('paradigms_tested')}"
    return "WARN", f"声明测过 {neg.get('paradigms_tested')}，但未说明是否跨范式（直接多步 ↔ 单步+自回归 ↔ 隐空间 rollout）"


def c25_closedform_basis(d):
    

    cl = d.get("capacity_claim") or d.get("param_vs_nonparam")
    if not cl:
        return "PASS", "未做『某类模型做不到』类断言，跳过"
    if not cl.get("closed_form_basis_tested", False):
        return "FAIL", ("断言某类模型（参数化/无参考数据）做不到，却**没跑闭式基函数拟合**（铁律 67）。"
                        "本项目实例：据「非参局部二次单步 val 1.1e-11，训练出的算子族落后」推断"
                        "『参数化模型推理时查不到参考数据 ⇒ 难度完全不同』——**错**。"
                        "252 个参数的全局 6 次多项式（闭式最小二乘、推理无参考数据）单步 test=**4.18e-19**，"
                        "τ=0.8 自回归=**3.58e-14**，比非参局部二次（6.15e-08）好 **1.72e6×**；"
                        "而 67,587 参数的 MLP 是 1.43e-05/9.7e-02 ⇒ 差 **1.6e12×**。"
                        "⇒ 差距是**函数类 + 数值条件 + 优化**问题，不是 access 问题。")
    if not cl.get("degree_swept", False):
        return "WARN", ("已跑闭式基函数，但**没扫次数/带宽**（铁律 68）：存在『复杂度 × 条件数』最优折衷。"
                        "本项目实例：poly6 最优（cond 2.5e12, test 4.18e-19），"
                        "poly16 因 cond=6.8e306 **反而退化到 6.37e-12**。")
    return "PASS", "闭式基函数已测且扫描过复杂度，并报了条件数"


CHECKS = [
    ("C01", "样本量 ≥3 种子", "铁律 9/15", c01_seeds),
    ("C02", "报 mean±sd", "铁律 15", c02_meansd),
    ("C03", "含最普通基线", "铁律 44", c03_plain_baseline),
    ("C04", "预算/视界配平", "铁律 8/29", c04_budget),
    ("C05", "协议同构", "铁律 45", c05_protocol_match),
    ("C06", "口径已从对手源码核实", "铁律 45", c06_protocol_source),
    ("C07", "短程指标配零训练基线", "铁律 48", c07_zero_train),
    ("C08", "选择器/集成配 oracle 上界+对手同技巧", "铁律 50", c08_selector),
    ("C09", "@40+ 须 ≥3 种子", "铁律 27", c09_long_horizon),
    ("C10", "跨环境断言须 ≥3 系统", "铁律 1", c10_cross_env),
    ("C11", "异常好 ≥3× 须先查口径", "铁律 6/23", c11_anomaly),
    ("C12", "新颖性断言须文献占位", "铁律 40", c12_novelty),
    ("C13", "约束生效须实测被约束对象", "铁律 41", c13_constraint),
    ("C14", "稻草人基线须显式排除", "铁律 22", c14_strawman),
    ("C15", "谱读数须先量 κ₂ 并做 σ_max 交叉校验", "铁律 56", c15_spectral),
    ("C16", "修复缺陷后变差须查正则化作用", "铁律 57", c16_fix_regression),
    ("C17", "零训练基线须扫过自身超参", "铁律 58", c17_zero_train_swept),
    ("C18", "设备选型须先扫 ms/iter vs batch", "铁律 60", c18_device_batch),
    ("C19", "GPU 并发上限须实测", "铁律 61", c19_gpu_concurrency),
    ("C20", "基线超参须用验证集选（非测试集）", "铁律 62", c20_val_not_test),
    ("C21", "概率目标+可学习方差须查梯度放大", "铁律 63", c21_probabilistic_var_floor),
    ("C22", "基线族须含局部/非参方法", "铁律 64", c22_local_baseline_present),
    ("C23", "视界/尺度须按物理量对齐", "铁律 65", c23_physical_scale_aligned),
    ("C24", "判「任务无空间」前须换范式重测", "铁律 66", c24_paradigm_varied),
    ("C25", "判「某类模型做不到」前须跑闭式基函数并扫复杂度", "铁律 67/68", c25_closedform_basis),
]

ICON = {"PASS": "[ ok ]", "WARN": "[warn]", "FAIL": "[FAIL]"}


def audit(d, path):
    print(f"\n{'=' * 104}")
    print(f"  实验审计：{d.get('name', os.path.basename(path))}")
    print(f"  命题：{d.get('claim', '(未填)')}")
    print(f"{'=' * 104}")
    results = []
    for cid, name, law, fn in CHECKS:
        try:
            st, detail = fn(d)
        except Exception as e:
            st, detail = "WARN", f"检查器异常（跳过）：{e!r}"
        results.append((cid, name, law, st, detail))
        print(f"  {ICON[st]} {cid} {name:<34} {law:<12} {detail}")
    nf = sum(1 for r in results if r[3] == "FAIL")
    nw = sum(1 for r in results if r[3] == "WARN")
    print(f"\n  ⇒ 合计：{len(results) - nf - nw} PASS / {nw} WARN / {nf} FAIL")
    if nf:
        print("  ⇒ **判决：不得下结论**（先修 FAIL 项；本项目 20 轮里有 6 轮的翻车正是这些项没查）")
    elif nw:
        print("  ⇒ 判决：可以下结论，但须在报告里逐条披露 WARN 项")
    else:
        print("  ⇒ 判决：可下结论")
    return nf


def main():
    args = [a for a in sys.argv[1:]]
    if not args or args[0] in ("--template", "-t"):
        print(json.dumps(TEMPLATE, ensure_ascii=False, indent=1))
        return 0
    total_fail = 0
    for p in args:
        if not os.path.exists(p):
            print(f"  [skip] 找不到 {p}")
            continue
        d = json.load(open(p, encoding="utf-8"))
        total_fail += audit(d, p)
    print()
    return 1 if total_fail else 0


if __name__ == "__main__":
    sys.exit(main())
