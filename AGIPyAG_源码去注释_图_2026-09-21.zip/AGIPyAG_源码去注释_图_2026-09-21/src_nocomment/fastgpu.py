
































import os
import sys
import contextlib
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import ln_split as LS

_ENABLED = False





def enable_fast(verbose=True):
    global _ENABLED
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass
    torch.backends.cudnn.benchmark = True
    _ENABLED = True
    if verbose:
        print(f"  [fastgpu] TF32={torch.backends.cuda.matmul.allow_tf32}"
              f"｜cudnn.benchmark={torch.backends.cudnn.benchmark}"
              f"｜matmul_precision={torch.get_float32_matmul_precision()}", flush=True)





def patch_linop():
    
    if getattr(LS.LinOp, "_fastgpu_patched", False):
        return

    def project(self, K):
        s = torch.linalg.svdvals(K.detach()).max()
        if self.rho is None:
            return K, s
        scale = (self.rho / s).clamp(max=1.0)
        return K * scale, s

    def prepare(self):
        self._fg_K, self._fg_s = self.project(self.K)
        self._fg_pre = True

    def unprepare(self):
        self._fg_pre = False
        self._fg_K = None

    def smax(self):
        
        if self._fg_pre and self._fg_s is not None:
            return float(self._fg_s)
        return float(torch.linalg.svdvals(self.K.detach()).max())

    def forward(self, h, z, a=None):
        if getattr(self, "_fg_pre", False):
            K = self._fg_K
        else:
            K, s = self.project(self.K)
            self._fg_s = s
        return h @ K.t() + self.B(z)

    LS.LinOp.project = project
    LS.LinOp.prepare = prepare
    LS.LinOp.unprepare = unprepare
    LS.LinOp.smax = smax
    LS.LinOp.forward = forward
    LS.LinOp._fastgpu_patched = True


@contextlib.contextmanager
def prepared(op):
    
    targets = []
    if hasattr(op, "lin") and hasattr(op.lin, "prepare"):
        targets.append(op.lin)
    elif hasattr(op, "prepare"):
        targets.append(op)
    for t in targets:
        t.prepare()
    try:
        yield
    finally:
        for t in targets:
            t.unprepare()





def _deriv_batch(name, env, S):
    
    if name == "Lorenz":
        x, y, z = S[:, 0], S[:, 1], S[:, 2]
        return np.stack([env.sigma * (y - x),
                         x * (env.rho - z) - y,
                         x * y - env.beta * z], 1)
    if name == "Rossler":
        x, y, z = S[:, 0], S[:, 1], S[:, 2]
        return np.stack([-y - z,
                         x + env.a * y,
                         env.b + z * (x - env.c)], 1)
    if name == "Duffing":
        x, y, ph = S[:, 0], S[:, 1], S[:, 2]
        th = 2 * np.pi * ph
        return np.stack([y,
                         -env.delta * y - env.alpha * x - env.beta * x ** 3
                         + env.gamma * np.cos(th),
                         env.omega / (2 * np.pi)], 1)
    if hasattr(env, "n_sys"):
        n = env.n_sys
        X = S.reshape(len(S), n, 3)
        d = np.empty_like(X)
        k = env.k
        for i in range(n):
            xi, yi, zi = X[:, i, 0], X[:, i, 1], X[:, i, 2]
            xp = X[:, (i - 1) % n, 0]
            xq = X[:, (i + 1) % n, 0]
            d[:, i, 0] = env.sigma * (yi - xi) + k * (xp + xq - 2.0 * xi)
            d[:, i, 1] = xi * (env.rho - zi) - yi
            d[:, i, 2] = xi * yi - env.beta * zi
        return d.reshape(len(S), -1)
    if name == "Lorenz6":
        x1, y1, z1, x2, y2, z2 = (S[:, i] for i in range(6))
        k = env.k
        return np.stack([env.sigma * (y1 - x1) + k * (x2 - x1),
                         x1 * (env.rho - z1) - y1,
                         x1 * y1 - env.beta * z1,
                         env.sigma * (y2 - x2) + k * (x1 - x2),
                         x2 * (env.rho - z2) - y2,
                         x2 * y2 - env.beta * z2], 1)
    raise ValueError(f"未实现批量导数的环境：{name}")


def _step_batch(name, env, S):
    dt = env.dt
    if getattr(env, "integrator", "euler") == "rk4":
        k1 = _deriv_batch(name, env, S)
        k2 = _deriv_batch(name, env, S + 0.5 * dt * k1)
        k3 = _deriv_batch(name, env, S + 0.5 * dt * k2)
        k4 = _deriv_batch(name, env, S + dt * k3)
        S = S + dt / 6.0 * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
    else:
        S = S + dt * _deriv_batch(name, env, S)
    if name == "Duffing":
        S[:, 2] = S[:, 2] % 1.0
    return S


def simulate_batch(name, env, n, s0s, burn=4000):
    
    S = np.asarray(s0s, dtype=np.float64).copy()
    for _ in range(burn):
        S = _step_batch(name, env, S)
    out = np.empty((len(S), n, env.obs_dim))
    for i in range(n):
        S = _step_batch(name, env, S)
        out[:, i] = S
    return out





def sample_windows_fast(xn, B, T, K, rng, device=None):
    n = len(xn) - T - K - 1
    i = rng.integers(0, n, B)
    idx = i[:, None] + np.arange(T)
    seed = xn[idx]
    tgt = xn[i[:, None] + T + np.arange(K)]
    return (torch.as_tensor(seed, device=device),
            torch.as_tensor(tgt, device=device))





def selftest():
    patch_linop()
    enable_fast()
    import wm_v2 as W
    env = W.get_env("Lorenz")
    env.rho = 28.0
    s0 = np.ones(3)
    t0 = __import__("time").time()
    ref = env.simulate(600, s0, burn=500)
    t1 = __import__("time").time()
    fast = simulate_batch("Lorenz", env, 600, s0[None], burn=500)[0]
    t2 = __import__("time").time()
    print(f"  [selftest] 单轨迹 600 步: 原 {t1 - t0:.3f}s | 批量(1条) {t2 - t1:.3f}s"
          f"｜逐点最大差 {np.abs(ref - fast).max():.3e}")

    rng = np.random.default_rng(0)
    s0s = np.stack([s0 + rng.normal(0, 4, 3) for _ in range(5)])
    t3 = __import__("time").time()
    [env.simulate(600, s, burn=500) for s in s0s]
    t4 = __import__("time").time()
    simulate_batch("Lorenz", env, 600, s0s, burn=500)
    t5 = __import__("time").time()
    print(f"  [selftest] 5 轨迹 600 步: 逐个 {t4 - t3:.3f}s | 批量 {t5 - t4:.3f}s"
          f" ⇒ 加速 {(t4 - t3) / max(t5 - t4, 1e-9):.1f}×")


if __name__ == "__main__":
    selftest()
