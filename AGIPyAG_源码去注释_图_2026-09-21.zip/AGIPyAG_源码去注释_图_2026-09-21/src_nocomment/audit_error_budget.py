#!/usr/bin/env python3



















import json
import math
import os

ROOT = os.path.dirname(os.path.abspath(__file__))


def load(name):
    p = os.path.join(ROOT, name)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def fnum(x):
    return x if isinstance(x, (int, float)) and x == x else None


def crit(df):
    
    if df != df:
        return float("nan")
    for k, v in [(2, 4.303), (3, 3.182), (4, 2.776), (6, 2.447),
                 (10, 2.228), (20, 2.086)]:
        if df <= k:
            return v
    return 1.96


def welch(m1, s1, n1, m2, s2, n2):
    se2 = s1 ** 2 / n1 + s2 ** 2 / n2
    if se2 <= 0:
        return float("nan"), float("nan")
    t = (m1 - m2) / math.sqrt(se2)
    num = se2 ** 2
    den = (s1 ** 2 / n1) ** 2 / max(n1 - 1, 1) + (s2 ** 2 / n2) ** 2 / max(n2 - 1, 1)
    return t, (num / den if den > 0 else float("nan"))


def verdict_word(t, df):
    if t != t or df != df:
        return "无法判定"
    c = crit(df)
    return "显著" if abs(t) > c else "**不显著**"



def audit_k2():
    d = load("wm_results_lm_bench.json")
    if not d:
        print("缺少 wm_results_lm_bench.json")
        return
    by = d["by"]
    grid = {}
    for _k, v in by.items():
        if v.get("bptt") != 128 or v.get("steps") != 600:
            continue
        b = fnum(v.get("val_bits_char"))
        if b is None:
            continue
        grid.setdefault(v["arm"], {})[v["lr"]] = b
        grid[v["arm"]]["_sd"] = grid[v["arm"]].get("_sd", {})
        grid[v["arm"]]["_sd"][v["lr"]] = (fnum(v.get("val_bits_char_sd")),
                                          v.get("n_seeds", 1))

    print("=" * 78)
    print("【K2 字符级 LM】臂 × lr 全网格（val bits/char，bptt=128，st=600，越低越好）")
    print("=" * 78)
    arms = [a for a in ["tf", "kov", "koop", "lstm", "dca"] if a in grid]
    lrs = sorted({l for a in arms for l in grid[a] if not str(l).startswith("_")})
    hdr = "lr".ljust(9) + "".join(a.rjust(10) for a in arms)
    print(hdr)
    print("-" * len(hdr))
    for lr in lrs:
        line = str(lr).ljust(9)
        for a in arms:
            b = grid[a].get(lr)
            line += ("—" if b is None else f"{b:.4f}").rjust(10)
        print(line)

    print("\n【公平性检验：只在两臂**共同扫过**的 lr 上比较排序】")
    flip = 0
    tot = 0
    for lr in lrs:
        got = {a: grid[a][lr] for a in arms if lr in grid[a]}
        if len(got) < 2:
            continue
        order = sorted(got, key=got.get)
        print(f"  lr={lr:<7} " + " < ".join(f"{a}({got[a]:.4f})" for a in order))
        if "tf" in got and "koop" in got:
            tot += 1
            flip += 1 if got["tf"] > got["koop"] else 0
        if "kov" in got and "koop" in got:
            tot += 1


    print("\n【两两对比：在共同 lr 上谁赢】")
    for a, b in [("tf", "kov"), ("kov", "koop"), ("tf", "koop"), ("tf", "lstm")]:
        common = sorted(set(grid[a]) & set(grid[b]) - {"_sd"})
        common = [l for l in common if not str(l).startswith("_")]
        if not common:
            continue
        wins = {a: 0, b: 0}
        detail = []
        for lr in common:
            va, vb = grid[a][lr], grid[b][lr]
            w = a if va < vb else b
            wins[w] += 1
            detail.append(f"lr={lr}: {a} {va:.4f} vs {b} {vb:.4f} → {w}")
        print(f"  {a} vs {b}（共同 lr {len(common)} 个）：{a} 胜 {wins[a]} / {b} 胜 {wins[b]}"
              f" → {'**稳健**' if max(wins.values()) == len(common) else '**翻转，不稳健**'}")
        for s in detail:
            print(f"      {s}")


    print("\n【L2 超参噪声】")
    ranges = {}
    for a in arms:
        vals = [v for l, v in grid[a].items() if not str(l).startswith("_")]
        if len(vals) >= 2:
            ranges[a] = max(vals) - min(vals)
            print(f"  {a:6s} {len(vals)} 个 lr｜极差 {ranges[a]:.4f}")
    lr_noise = sum(ranges.values()) / len(ranges) if ranges else float("nan")


    print("\n【L3 预算/协议噪声】")
    l3 = []
    for k, v in by.items():
        pass
    for a in arms:
        for lr in [l for l in grid[a] if not str(l).startswith("_")]:
            pass

    pairs = []
    for _k, v in by.items():
        if v["arm"] == "koop" and v["lr"] == 0.01:
            pairs.append((v["bptt"], v["steps"], fnum(v.get("val_bits_char")),
                          v.get("tokens_seen")))
    pairs = [p for p in pairs if p[2] is not None]
    by_tok = {}
    for bptt, st, bits, tok in pairs:
        by_tok.setdefault(tok, []).append((bptt, st, bits))
    for tok, lst in by_tok.items():
        if len(lst) >= 2:
            vals = [x[2] for x in lst]
            print(f"  koop lr=0.01 同 token 预算 {tok}: " +
                  ", ".join(f"bptt={x[0]}/st={x[1]}→{x[2]:.4f}" for x in lst) +
                  f"｜极差 {max(vals) - min(vals):.4f}")


    print("\n【L1 种子噪声】")
    seed_n = []
    for a in arms:
        for lr, (sd, n) in grid[a].get("_sd", {}).items():
            if sd is not None and n >= 3:
                print(f"  {a:6s} lr={lr:<7} sd={sd:.4f} (n={n})")
                seed_n.append(sd)
    seed_sd = sum(seed_n) / len(seed_n) if seed_n else float("nan")


    print("\n" + "=" * 78)
    print("★ 关键结论逐条过误差检验")
    print("=" * 78)
    def two(a, b):
        
        va, la = min(((v, l) for l, v in grid[a].items()
                      if not str(l).startswith("_")), key=lambda x: x[0])
        vb, lb = min(((v, l) for l, v in grid[b].items()
                      if not str(l).startswith("_")), key=lambda x: x[0])
        sa = grid[a]["_sd"].get(la, (None, 1))
        sb = grid[b]["_sd"].get(lb, (None, 1))
        return va, la, sa, vb, lb, sb

    checks = [
        ("Transformer 胜 Koopman 15.3%", "tf", "koop"),
        ("Transformer 胜 kov 8.1%（我方最强 Koopman 实现）", "tf", "kov"),
        ("kov（无递归）胜 koop（递推+自适应）6.3% ⇒ 递推是负贡献", "kov", "koop"),
        ("Transformer 胜 LSTM", "tf", "lstm"),
    ]
    for name, a, b in checks:
        va, la, (sa, na), vb, lb, (sb, nb) = two(a, b)
        d_ = vb - va
        line = f"\n  · {name}\n      {a}(lr={la}) {va:.4f} vs {b}(lr={lb}) {vb:.4f}｜差 {d_:+.4f}"
        if sa is not None and sb is not None:
            t, df = welch(va, sa, na, vb, sb, nb)
            line += f"\n      种子检验：t={t:.2f}, df={df:.1f} → {verdict_word(t, df)}"

        common = sorted([l for l in (set(grid[a]) & set(grid[b]))
                         if not str(l).startswith("_")])
        if common:
            wins = sum(1 for l in common if grid[a][l] < grid[b][l])
            n = len(common)
            frac = wins / n
            tag = ("稳健（全胜）" if wins == n else
                   "强倾向（非全胜）" if frac >= 0.75 else
                   "**接近随机 → 结论翻转**" if frac > 0.25 else "**反向**")
            line += (f"\n      公平性检验（共同 lr {n} 个）：{a} 胜 {wins}/{n}"
                     f"（{frac * 100:.0f}%）→ {tag}")
        print(line)

    print("\n【汇总】")
    print(f"  L1 种子噪声（平均 sd）      : {seed_sd:.4f}")
    print(f"  L2 超参噪声（平均极差）     : {lr_noise:.4f}")
    print(f"  ⇒ 比值 L2/L1 = {lr_noise / seed_sd:.1f}×  "
          f"（超参自由度远大于种子自由度）")



def audit_e1():
    print("\n" + "=" * 78)
    print("【E1 外挂读音头】误差审计")
    print("=" * 78)
    files = ["wm_results_ext_mem.json", "wm_results_ext_mem_s1.json",
             "wm_results_ext_mem_s2.json"]
    acc = {}
    for fn in files:
        d = load(fn)
        if not d:
            continue
        for arm, blk in d.get("arms", {}).items():
            sg = blk.get("signals", {})
            rec = {"val": fnum(blk.get("val_bits_char")),
                   "knn": fnum(blk.get("knn_upper_bound_on_emb"))}
            for k, v in sg.items():
                if k.startswith("s（"):
                    rec["auc"] = fnum(v.get("auc"))
                elif k.startswith("当前步 NLL"):
                    rec["same_fun"] = fnum(v.get("auc"))
                elif k.startswith("−log p"):
                    rec["pure_stat"] = fnum(v.get("auc"))
                elif k.startswith("‖h‖"):
                    rec["h_norm"] = fnum(v.get("auc"))
            acc.setdefault(arm, []).append(rec)

    stats = {}
    for arm, recs in acc.items():
        def ms(key):
            vs = [r[key] for r in recs if r.get(key) is not None]
            if not vs:
                return float("nan"), float("nan"), 0
            m = sum(vs) / len(vs)
            sd = (sum((v - m) ** 2 for v in vs) / (len(vs) - 1)) ** 0.5 if len(vs) > 1 else 0.0
            return m, sd, len(vs)
        stats[arm] = {k: ms(k) for k in
                      ["auc", "same_fun", "pure_stat", "h_norm", "val", "knn"]}

    print(f"  {'臂':<14}{'信号 AUC':>16}{'同泛函':>14}{'纯统计':>14}{'kNN上界':>12}")
    for arm in ["tf_ext_sup", "tf_mlp_sup", "tf_lstm_sup", "tf_ext_unsup"]:
        if arm not in stats:
            continue
        s = stats[arm]
        print(f"  {arm:<14}{s['auc'][0]:>8.4f}±{s['auc'][1]:<6.4f}"
              f"{s['same_fun'][0]:>14.4f}{s['pure_stat'][0]:>14.4f}{s['knn'][0]:>12.4f}")

    if "tf_ext_sup" in stats and "tf_mlp_sup" in stats:
        a, b = stats["tf_ext_sup"], stats["tf_mlp_sup"]
        t, df = welch(a["auc"][0], a["auc"][1], a["auc"][2],
                      b["auc"][0], b["auc"][1], b["auc"][2])
        print(f"\n  · 混沌 vs 纯 MLP：「打平」是否成立？")
        print(f"      {a['auc'][0]:.4f}±{a['auc'][1]:.4f} vs {b['auc'][0]:.4f}±{b['auc'][1]:.4f}｜"
              f"差 {a['auc'][0] - b['auc'][0]:+.4f}")
        print(f"      t={t:.2f}, df={df:.1f} → {verdict_word(t, df)} "
              f"⇒ {'**「打平」有统计支持**（无差异是真的）' if abs(t) <= 3.5 else '存在差异'}")

    if "tf_ext_sup" in stats:
        a = stats["tf_ext_sup"]
        gap = a["auc"][0] - a["same_fun"][0]
        print(f"\n  · 混沌信号 vs 同泛函上限：{a['auc'][0]:.4f} vs {a['same_fun'][0]:.4f}"
              f"｜差 {gap:+.4f}")
        if a["auc"][1] > 0:
            print(f"      以种子 sd={a['auc'][1]:.4f} 计，差值是 **{gap / a['auc'][1]:.1f}× sd** "
                  f"⇒ 种子误差**解释不了**（但注意同泛函是单点基线，无 sd，此检验不完整）")

    print("\n  ⚠ L4 域误差：**未测**。E1 目前只有代码语料一个域。")
    print("     项目历史上 ens_chaos 正是「单环境 0.72 / 跨环境三方向」而倒的。")
    print("     ⇒ 这是**当前最大的未知**，也是 P0 存在的唯一理由。")


if __name__ == "__main__":
    audit_k2()
    audit_e1()
