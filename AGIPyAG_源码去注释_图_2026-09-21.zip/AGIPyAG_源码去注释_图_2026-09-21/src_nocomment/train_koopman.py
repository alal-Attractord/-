#!/usr/bin/env python3













import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wm_v2 as W
import koopman_core as KC

ROOT = os.path.dirname(os.path.abspath(__file__))
OUTDIR = os.path.join(ROOT, "data", "koopman")
T, KTR = 16, 8
BATCH = 32


def train(model, xn_tr, steps, seed=0):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)
    model.train()
    t0, loss = time.time(), None
    for _ in range(steps):
        s, t = W.sample_windows(xn_tr, BATCH, T, KTR, rng)
        opt.zero_grad()
        loss = F.mse_loss(model.forward_roll(s, KTR), t)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        opt.step()
    model.eval()
    return float(loss.item()), time.time() - t0


@torch.no_grad()
def spectral_summary(model, x_probe):
    



    K = model.raw_K(x_probe)
    lam = torch.linalg.eigvals(K.cpu()).numpy().reshape(-1, K.shape[-1])
    r = np.abs(lam)
    top = np.argsort(-r, axis=1)[:, :5]
    return {
        "n_states": int(len(r)),
        "rho_mean": float(r.max(1).mean()),
        "rho_std": float(r.max(1).std()),
        "unitdist_mean": float(np.abs(r - 1.0).min(1).mean()),
        "top5_modulus_mean": [float(r[np.arange(len(r))[:, None], top[:, :5]].mean(0)[j])
                              for j in range(5)],
        "imag_frac": float((np.abs(lam.imag) > 1e-6 * np.maximum(np.abs(lam.real), 1e-12)).mean()),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="Lorenz")
    ap.add_argument("--steps", type=int, default=1500)
    ap.add_argument("--dim", type=int, default=96)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    print(f"DEV {W.DEV} | torch {torch.__version__}", flush=True)
    env = W.get_env(a.env)
    raw, xn = W.build_env_data(env, n=6000, burn=4000, seed=a.seed)
    ntr = int(len(xn) * 0.8)
    xn_tr, xn_te = xn[:ntr], xn[ntr:]
    print(f"env={a.env} 数据 {xn.shape}｜span "
          f"{float(np.linalg.norm(np.asarray(env.hi) - np.asarray(env.lo))):.1f}", flush=True)

    meta = {"version": "koopman_v1", "env": a.env, "device": W.DEV,
            "torch": torch.__version__, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "protocol": {"T": T, "K_train": KTR, "batch": BATCH, "steps": a.steps},
            "mu": np.asarray(env.mu, dtype=np.float64).tolist(),
            "sd": np.asarray(env.sd, dtype=np.float64).tolist(),
            "lo": np.asarray(env.lo, dtype=np.float64).tolist(),
            "hi": np.asarray(env.hi, dtype=np.float64).tolist(),
            "parts": {}}
    x_probe = torch.tensor(xn_te[::37][:256], device=W.DEV)

    for tag, adaptive, nb in (("koopman_fix", False, 0), ("koopman_adapt", True, 8)):
        m = KC.KoopmanWM(env, dim=a.dim, adaptive=adaptive, n_basis=nb).to(W.DEV)
        loss, dt = train(m, xn_tr, a.steps, seed=0)
        p = KC.param_count(m)
        r20, v20 = W.evaluate(m, xn_te, K=20, T=T, n_win=128, seed=11)
        r160, v160 = W.evaluate(m, xn_te, K=160, T=T, n_win=128, seed=11)
        spec = spectral_summary(m, x_probe)
        path = os.path.join(OUTDIR, f"{tag}.pt")
        torch.save({"kind": tag, "env_name": env.name,
                    "cfg": {"dim": a.dim, "adaptive": adaptive, "n_basis": nb},
                    "state_dict": m.state_dict(), "params": p,
                    "metrics": {"rmse@1": float(r20[0]), "rmse@5": float(r20[4]),
                                "rmse@20": float(r20[19]), "VPT20": int(v20),
                                "rmse@160": float(r160[159]), "VPT160": int(v160),
                                "final_loss": loss, "train_s": round(dt, 1)},
                    "spectrum": spec}, path)
        meta["parts"][tag] = {"params": p, "path": os.path.basename(path),
                              **{k: v for k, v in meta["protocol"].items()},
                              "metrics": {"rmse@1": float(r20[0]), "rmse@5": float(r20[4]),
                                          "rmse@20": float(r20[19]), "VPT20": int(v20),
                                          "rmse@160": float(r160[159]), "VPT160": int(v160)},
                              "spectrum": spec}
        print(f"  {tag:<15} P={p:>7} loss={loss:.5f} | @1 {r20[0]:.4f} @5 {r20[4]:.4f} "
              f"@20 {r20[19]:.4f} (VPT {v20}) | @160 {r160[159]:.4f} (VPT {v160}) | "
              f"谱半径 {spec['rho_mean']:.4f}±{spec['rho_std']:.4f} "
              f"复模态占比 {spec['imag_frac']:.3f} | {dt:.0f}s", flush=True)

    with open(os.path.join(OUTDIR, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    print("完成 →", OUTDIR, flush=True)


if __name__ == "__main__":
    main()
