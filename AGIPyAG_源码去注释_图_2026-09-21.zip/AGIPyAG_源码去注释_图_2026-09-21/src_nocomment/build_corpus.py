#!/usr/bin/env python3


import io
import json
import random
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
random.seed(7)
CACHE = r"data/hc3_cache/datasets--Hello-SimpleAI--HC3-Chinese/snapshots/09a687b8dc164b89e7df95abf15df3b216bc31c2"


def load(path, budget, qmax=20, amin=4, amax=40):
    out = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            try:
                d = json.loads(line)
                q = d.get("question")
                q = q.strip() if isinstance(q, str) else ""
                ans = d.get("human_answers") or d.get("chatgpt_answers") or []
                a = next((x.strip() for x in ans if isinstance(x, str) and x.strip()), "")
            except Exception:
                continue
            if not q or not a or len(q) > qmax:
                continue

            first = a.split("。")[0].split("！")[0].split("？")[0].strip()
            if not (amin <= len(first) <= amax):
                continue
            out.append((q, first + "。"))
            if len(out) >= budget:
                break
    return out


chaos = [l.strip() for l in open("data/chaos_qa.txt", encoding="utf-8").read().splitlines() if l.strip()]
pairs = [(chaos[i], chaos[i + 1]) for i in range(0, len(chaos) - 1, 2)]
hc = []
hc += load(f"{CACHE}/open_qa.jsonl", 400)
hc += load(f"{CACHE}/psychology.jsonl", 250)
hc += load(f"{CACHE}/medicine.jsonl", 150)
random.shuffle(hc)
total = pairs + hc
mlen = max(len(q) + 2 + len(a) for q, a in total)
print("混沌:", len(pairs), "| HC3:", len(hc), "| 合计:", len(total), "| 最长 q?a。:", mlen)
with open("data/chaos_qa_med.txt", "w", encoding="utf-8") as f:
    for q, a in total:
        f.write(q + "\n" + a + "\n")
print("已写 data/chaos_qa_med.txt")
