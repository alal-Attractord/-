
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        void: '#050510',
        deep: '#0a0a1e',
        panel: '#0f0f2a',
        accent: '#a78bfa',
        cyan: '#22d3ee',
        warn: '#f59e0b',
        danger: '#ef4444',
        success: '#10b981',
        muted: '#6b6880',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'spin-slow': 'spin 24s linear infinite',
      },
    },
  },
  plugins: [],
};
