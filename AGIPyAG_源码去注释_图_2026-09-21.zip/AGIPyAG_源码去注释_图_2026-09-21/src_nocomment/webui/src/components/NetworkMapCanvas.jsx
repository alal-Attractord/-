import React, { useEffect, useRef, useState, useCallback } from 'react';













const NODE_COLORS = {
  server: '#4ade80',
  client: '#60a5fa',
  ai_service: '#f472b6',
  data_source: '#fbbf24',
  cdn: '#22d3ee',
  cloud: '#a78bfa',
  unknown: '#6a6a76',
};


const ACTION_COLORS = {
  api_call: '#4ade80',
  ai_inference: '#f472b6',
  data_download: '#fbbf24',
  web_scrape: '#22d3ee',
  training_fetch: '#a78bfa',
  internal: '#6a6a76',
};


function lonToTileX(lon, zoom) {
  return ((lon + 180) / 360) * Math.pow(2, zoom);
}

function latToTileY(lat, zoom) {
  const latRad = (lat * Math.PI) / 180;
  return ((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * Math.pow(2, zoom);
}

function tileXToLon(x, zoom) {
  return (x / Math.pow(2, zoom)) * 360 - 180;
}

function tileYToLat(y, zoom) {
  const n = Math.PI - (2 * Math.PI * y) / Math.pow(2, zoom);
  return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
}


function greatCirclePoints(lat1, lon1, lat2, lon2, segments = 50) {
  const points = [];
  const lat1Rad = (lat1 * Math.PI) / 180;
  const lat2Rad = (lat2 * Math.PI) / 180;
  const lon1Rad = (lon1 * Math.PI) / 180;
  const lon2Rad = (lon2 * Math.PI) / 180;
  
  const d = Math.acos(
    Math.sin(lat1Rad) * Math.sin(lat2Rad) +
    Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.cos(lon2Rad - lon1Rad)
  );
  
  for (let i = 0; i <= segments; i++) {
    const f = i / segments;
    const A = Math.sin((1 - f) * d) / Math.sin(d);
    const B = Math.sin(f * d) / Math.sin(d);
    
    const x = A * Math.cos(lat1Rad) * Math.cos(lon1Rad) + B * Math.cos(lat2Rad) * Math.cos(lon2Rad);
    const y = A * Math.cos(lat1Rad) * Math.sin(lon1Rad) + B * Math.cos(lat2Rad) * Math.sin(lon2Rad);
    const z = A * Math.sin(lat1Rad) + B * Math.sin(lat2Rad);
    
    const lat = (Math.atan2(z, Math.sqrt(x * x + y * y)) * 180) / Math.PI;
    const lon = (Math.atan2(y, x) * 180) / Math.PI;
    points.push({ lat, lon });
  }
  return points;
}

export default function NetworkMapCanvas({ 
  nodes = {}, 
  connections = [], 
  records = [], 
  onNodeClick,
  mapTileUrl = (z, x, y) => `/api/map/tile/${z}/${x}/${y}`,
  offlineMode = false,
}) {
  const canvasRef = useRef(null);
  const tileCacheRef = useRef(new Map()); 
  const [zoom, setZoom] = useState(3);
  const [centerLat, setCenterLat] = useState(30);
  const [centerLon, setCenterLon] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [hoveredNode, setHoveredNode] = useState(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [packets, setPackets] = useState([]);
  const [tileStats, setTileStats] = useState({ loading: 0, loaded: 0, errors: 0 });
  const animRef = useRef(null);
  const packetIdRef = useRef(0);
  const lastDragRef = useRef({ x: 0, y: 0 });

  const width = 1200;
  const height = 700;
  const tileSize = 256;

  
  const geoToScreen = useCallback((lat, lon) => {
    const x = lonToTileX(lon, zoom);
    const y = latToTileY(lat, zoom);
    const centerX = lonToTileX(centerLon, zoom);
    const centerY = latToTileY(centerLat, zoom);
    return [
      width / 2 + (x - centerX) * tileSize,
      height / 2 + (y - centerY) * tileSize,
    ];
  }, [zoom, centerLat, centerLon]);

  
  const screenToGeo = useCallback((sx, sy) => {
    const centerX = lonToTileX(centerLon, zoom);
    const centerY = latToTileY(centerLat, zoom);
    const x = centerX + (sx - width / 2) / tileSize;
    const y = centerY + (sy - height / 2) / tileSize;
    return [tileYToLat(y, zoom), tileXToLon(x, zoom)];
  }, [zoom, centerLat, centerLon]);

  
  const loadTile = useCallback((z, x, y) => {
    const cacheKey = `${z}/${x}/${y}`;
    const cache = tileCacheRef.current;
    
    if (cache.has(cacheKey)) {
      return cache.get(cacheKey);
    }
    
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = mapTileUrl(z, x, y);
    
    setTileStats(prev => ({ ...prev, loading: prev.loading + 1 }));
    
    img.onload = () => {
      cache.set(cacheKey, img);
      setTileStats(prev => ({ ...prev, loading: prev.loading - 1, loaded: prev.loaded + 1 }));
    };
    
    img.onerror = () => {
      cache.set(cacheKey, 'error');
      setTileStats(prev => ({ ...prev, loading: prev.loading - 1, errors: prev.errors + 1 }));
    };
    
    cache.set(cacheKey, null); 
    return null;
  }, [mapTileUrl]);

  
  useEffect(() => {
    const interval = setInterval(() => {
      if (records && records.length > 0) {
        const recent = records.slice(-10);
        const newPackets = recent.map((r) => {
          const sourceNode = nodes[r.source] || nodes['local_server'] || nodes['beijing'];
          const targetNode = nodes[r.target_node] || nodes['unknown'];
          if (!sourceNode || !targetNode) return null;
          
          const path = greatCirclePoints(
            sourceNode.lat, sourceNode.lon,
            targetNode.lat, targetNode.lon, 30
          );
          
          return {
            id: packetIdRef.current++,
            path,
            progress: 0,
            speed: 0.008 + Math.random() * 0.012,
            color: ACTION_COLORS[r.action] || '#fff',
            size: r.bytes_in > 10000 ? 4 : r.bytes_in > 1000 ? 3 : 2,
          };
        }).filter(Boolean);
        setPackets((prev) => [...prev.slice(-30), ...newPackets]);
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [records, nodes]);

  
  useEffect(() => {
    const animate = () => {
      setPackets((prev) =>
        prev
          .map((p) => ({ ...p, progress: p.progress + p.speed }))
          .filter((p) => p.progress < 1)
      );
      animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current);
  }, []);

  
  const handleWheel = useCallback((e) => {
    e.preventDefault();
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const mx = (e.clientX - rect.left) * (width / rect.width);
    const my = (e.clientY - rect.top) * (height / rect.height);
    
    
    const [lat, lon] = screenToGeo(mx, my);
    
    const delta = e.deltaY > 0 ? 0.8 : 1.25;
    const newZoom = Math.max(1, Math.min(18, zoom * delta));
    
    
    if (newZoom !== zoom) {
      setZoom(newZoom);
      setCenterLat(lat);
      setCenterLon(lon);
    }
  }, [zoom, screenToGeo]);

  const handleMouseDown = useCallback((e) => {
    setDragging(true);
    lastDragRef.current = { x: e.clientX, y: e.clientY };
  }, []);

  const handleMouseMove = useCallback((e) => {
    if (dragging) {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      
      const dx = e.clientX - lastDragRef.current.x;
      const dy = e.clientY - lastDragRef.current.y;
      lastDragRef.current = { x: e.clientX, y: e.clientY };
      
      
      const dLon = -(dx / tileSize) * (360 / Math.pow(2, zoom));
      const dLat = (dy / tileSize) * (360 / Math.pow(2, zoom));
      
      setCenterLon(prev => prev + dLon);
      setCenterLat(prev => prev + dLat);
    }
    
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mx = (e.clientX - rect.left) * (width / rect.width);
    const my = (e.clientY - rect.top) * (height / rect.height);
    
    let found = null;
    Object.entries(nodes).forEach(([key, node]) => {
      const [nx, ny] = geoToScreen(node.lat, node.lon);
      const dist = Math.hypot(mx - nx, my - ny);
      if (dist < 12) found = { key, ...node };
    });
    setHoveredNode(found);
  }, [dragging, nodes, geoToScreen, zoom]);

  const handleMouseUp = useCallback(() => {
    setDragging(false);
  }, []);

  const handleClick = useCallback((e) => {
    if (hoveredNode) {
      setSelectedNode(hoveredNode);
      onNodeClick?.(hoveredNode);
    } else {
      setSelectedNode(null);
    }
  }, [hoveredNode, onNodeClick]);

  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    
    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0, 0, width, height);

    
    const centerX = lonToTileX(centerLon, zoom);
    const centerY = latToTileY(centerLat, zoom);
    
    const tilesX = Math.ceil(width / tileSize) + 2;
    const tilesY = Math.ceil(height / tileSize) + 2;
    
    const startTileX = Math.floor(centerX - tilesX / 2);
    const startTileY = Math.floor(centerY - tilesY / 2);
    
    
    for (let tx = 0; tx < tilesX; tx++) {
      for (let ty = 0; ty < tilesY; ty++) {
        const x = startTileX + tx;
        const y = startTileY + ty;
        
        
        const maxTile = Math.pow(2, zoom);
        if (x < 0 || x >= maxTile || y < 0 || y >= maxTile) continue;
        
        const img = loadTile(zoom, x, y);
        const screenX = width / 2 + (x - centerX) * tileSize;
        const screenY = height / 2 + (y - centerY) * tileSize;
        
        if (img && img !== 'error') {
          ctx.drawImage(img, screenX, screenY, tileSize, tileSize);
        } else {
          
          ctx.fillStyle = img === 'error' ? '#1a1a2e' : '#12121a';
          ctx.fillRect(screenX, screenY, tileSize, tileSize);
          
          
          ctx.strokeStyle = 'rgba(255,255,255,0.05)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(screenX, screenY, tileSize, tileSize);
          
          if (img === 'error') {
            ctx.fillStyle = 'rgba(255,100,100,0.3)';
            ctx.font = '10px monospace';
            ctx.fillText('×', screenX + tileSize / 2 - 3, screenY + tileSize / 2 + 3);
          }
        }
      }
    }

    
    ctx.fillStyle = 'rgba(10, 10, 15, 0.3)';
    ctx.fillRect(0, 0, width, height);

    
    if (connections) {
      connections.forEach((conn) => {
        const sourceNode = nodes[conn.source];
        const targetNode = nodes[conn.target];
        if (!sourceNode || !targetNode) return;
        
        const path = greatCirclePoints(sourceNode.lat, sourceNode.lon, targetNode.lat, targetNode.lon, 30);
        
        ctx.beginPath();
        path.forEach((pt, i) => {
          const [x, y] = geoToScreen(pt.lat, pt.lon);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.strokeStyle = 'rgba(139,142,240,0.2)';
        ctx.lineWidth = 1;
        ctx.stroke();
      });
    }

    
    packets.forEach((p) => {
      const idx = Math.floor(p.progress * (p.path.length - 1));
      const pt = p.path[Math.min(idx, p.path.length - 1)];
      const [x, y] = geoToScreen(pt.lat, pt.lon);
      
      
      const glow = ctx.createRadialGradient(x, y, 0, x, y, p.size * 5);
      glow.addColorStop(0, p.color + '80');
      glow.addColorStop(0.5, p.color + '30');
      glow.addColorStop(1, p.color + '00');
      ctx.beginPath();
      ctx.arc(x, y, p.size * 5, 0, Math.PI * 2);
      ctx.fillStyle = glow;
      ctx.fill();
      
      
      ctx.beginPath();
      ctx.arc(x, y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.fill();
    });

    
    Object.entries(nodes).forEach(([key, node]) => {
      const [x, y] = geoToScreen(node.lat, node.lon);
      const color = NODE_COLORS[node.type] || NODE_COLORS.unknown;
      const isHovered = hoveredNode?.key === key;
      const isSelected = selectedNode?.key === key;
      const radius = isHovered || isSelected ? 8 : 5;

      
      if (isHovered || isSelected) {
        const pulse = ctx.createRadialGradient(x, y, 0, x, y, radius * 4);
        pulse.addColorStop(0, color + '40');
        pulse.addColorStop(0.5, color + '15');
        pulse.addColorStop(1, color + '00');
        ctx.beginPath();
        ctx.arc(x, y, radius * 4, 0, Math.PI * 2);
        ctx.fillStyle = pulse;
        ctx.fill();
      }

      
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = isHovered || isSelected ? '#fff' : color + '80';
      ctx.lineWidth = isHovered || isSelected ? 2 : 1;
      ctx.stroke();

      
      if (zoom >= 3 || isHovered || isSelected) {
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.font = 'bold 11px "JetBrains Mono", monospace';
        ctx.fillText(node.label, x + radius + 5, y + 4);
        
        if (zoom >= 5) {
          ctx.fillStyle = 'rgba(255,255,255,0.5)';
          ctx.font = '9px "JetBrains Mono", monospace';
          ctx.fillText(node.region, x + radius + 5, y + 16);
        }
      }
    });

    
    if (selectedNode) {
      const [x, y] = geoToScreen(selectedNode.lat, selectedNode.lon);
      const boxW = 220;
      const boxH = 90;
      const boxX = Math.min(x + 20, width - boxW - 10);
      const boxY = Math.max(y - boxH - 10, 10);
      
      ctx.fillStyle = 'rgba(11,12,20,0.95)';
      ctx.strokeStyle = 'rgba(139,142,240,0.5)';
      ctx.lineWidth = 1;
      roundRect(ctx, boxX, boxY, boxW, boxH, 8);
      ctx.fill();
      ctx.stroke();
      
      ctx.fillStyle = '#f0f0f5';
      ctx.font = 'bold 13px "JetBrains Mono", monospace';
      ctx.fillText(selectedNode.label, boxX + 12, boxY + 24);
      ctx.fillStyle = '#a8a8b4';
      ctx.font = '11px "JetBrains Mono", monospace';
      ctx.fillText(`类型: ${selectedNode.type}`, boxX + 12, boxY + 44);
      ctx.fillText(`区域: ${selectedNode.region}`, boxX + 12, boxY + 60);
      ctx.fillText(`坐标: ${selectedNode.lat.toFixed(3)}, ${selectedNode.lon.toFixed(3)}`, boxX + 12, boxY + 76);
    }

    
    if (offlineMode) {
      ctx.fillStyle = 'rgba(200, 150, 50, 0.9)';
      ctx.font = 'bold 12px monospace';
      ctx.fillText('⚠ 离线模式', 10, height - 10);
    }
  }, [nodes, connections, packets, zoom, centerLat, centerLon, hoveredNode, selectedNode, geoToScreen, loadTile, offlineMode]);

  return (
    <div className="relative w-full overflow-hidden rounded-[18px]" style={{ height: 520 }}>
      <canvas
        ref={canvasRef}
        style={{ 
          width: '100%', 
          height: '100%', 
          cursor: dragging ? 'grabbing' : hoveredNode ? 'pointer' : 'grab',
          imageRendering: 'pixelated',
        }}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={handleClick}
      />
      
      {}
      <div className="absolute bottom-4 right-4 flex flex-col gap-1">
        <button
          className="w-8 h-8 rounded-lg liquid-glass flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
          onClick={() => setZoom(z => Math.min(18, z * 1.3))}
        >+</button>
        <button
          className="w-8 h-8 rounded-lg liquid-glass flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
          onClick={() => setZoom(z => Math.max(1, z / 1.3))}
        >-</button>
        <button
          className="w-8 h-8 rounded-lg liquid-glass flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
          onClick={() => { setZoom(3); setCenterLat(30); setCenterLon(0); }}
        >⌖</button>
      </div>
      
      {}
      <div className="absolute bottom-4 left-4 liquid-glass rounded-lg px-3 py-1.5">
        <span className="text-[11px] mono text-[var(--text-secondary)]">z={zoom.toFixed(1)}</span>
      </div>
      
      {}
      <div className="absolute top-4 right-4 liquid-glass rounded-xl p-3 text-right">
        <div className="text-[10px] text-[var(--text-tertiary)]">瓦片状态</div>
        <div className="flex items-center gap-3 mt-1">
          <div className="text-[10px]">
            <span className="text-[var(--mint)]">●</span> {tileStats.loaded}
          </div>
          <div className="text-[10px]">
            <span className="text-[var(--amber)]">◌</span> {tileStats.loading}
          </div>
          <div className="text-[10px]">
            <span className="text-[var(--danger)]">×</span> {tileStats.errors}
          </div>
        </div>
      </div>
      
      {}
      <div className="absolute top-4 left-4 liquid-glass rounded-xl p-3">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--text-tertiary)] mb-2">节点类型</div>
        {Object.entries(NODE_COLORS).map(([type, color]) => (
          <div key={type} className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
            <span className="text-[10px] text-[var(--text-secondary)]">{type}</span>
          </div>
        ))}
      </div>
      
      {}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 liquid-glass rounded-xl px-4 py-2">
        <div className="text-[10px] text-[var(--text-tertiary)] text-center">活跃数据包</div>
        <div className="text-[16px] font-bold mono text-[var(--accent)] text-center">{packets.length}</div>
      </div>
    </div>
  );
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}
