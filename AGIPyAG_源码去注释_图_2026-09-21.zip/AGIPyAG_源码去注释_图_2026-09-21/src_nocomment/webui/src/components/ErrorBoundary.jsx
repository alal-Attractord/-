import React from 'react';


export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, info: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    this.setState({ error, info });
    
    console.error('[ErrorBoundary]', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="h-screen w-screen flex items-center justify-center bg-[#020203] text-[var(--text-primary)] p-6">
          <div className="panel max-w-[560px] w-full p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-2.5 h-2.5 rounded-full bg-[var(--rose)]" />
              <h1 className="text-[16px] font-bold">界面渲染异常</h1>
            </div>
            <p className="text-[12px] text-[var(--text-secondary)] leading-relaxed">
              React 组件在渲染时发生错误。请尝试刷新页面，或切换到其他页面。
            </p>
            <div className="bg-[rgba(0,0,0,0.35)] rounded-[10px] p-3 overflow-auto max-h-[240px]">
              <pre className="mono text-[11px] text-[var(--rose)] whitespace-pre-wrap break-all">
                {this.state.error?.message || 'Unknown error'}
              </pre>
              <pre className="mono text-[10px] text-[var(--text-tertiary)] mt-2 whitespace-pre-wrap break-all">
                {this.state.info?.componentStack || ''}
              </pre>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => window.location.reload()}
                className="btn btn-primary flex-1"
              >
                刷新页面
              </button>
              <button
                onClick={() => {
                  localStorage.clear();
                  window.location.reload();
                }}
                className="btn btn-danger flex-1"
              >
                清除缓存并刷新
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
