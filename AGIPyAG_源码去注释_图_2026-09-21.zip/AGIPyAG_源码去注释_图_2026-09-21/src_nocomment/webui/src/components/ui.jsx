import React, { useEffect, useRef, useState } from 'react';


export function Page({ title, sub, children, actions }) {
  return (
    <div className="page-enter">
      <div className="flex items-end justify-between mb-7 gap-3">
        <div className="min-w-0">
          <h1 className="text-[28px] font-bold tracking-[-0.02em] text-[var(--text-primary)] leading-tight text-glow">{title}</h1>
          {sub && <p className="text-[12px] mt-2 text-[var(--text-tertiary)] tracking-wide truncate">{sub}</p>}
        </div>
        {actions && <div className="flex gap-2 shrink-0 pb-1">{actions}</div>}
      </div>
      {children}
    </div>
  );
}


export function Card({ title, children, className = '', style = {}, actions, pad = true }) {
  return (
    <div className={`panel ${pad ? 'p-5' : ''} ${className}`} style={style}>
      {title && (
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[13px] font-semibold tracking-[-0.01em] text-[var(--text-primary)] flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] shadow-[0_0_10px_var(--accent)]" />
            {title}
          </h3>
          {actions}
        </div>
      )}
      {children}
    </div>
  );
}


export function Delta({ value, suffix = '', invert = false }) {
  if (value === null || value === undefined || Number.isNaN(value)) return null;
  const dir = value > 0 ? 'up' : value < 0 ? 'down' : 'flat';
  const cls = invert ? (dir === 'up' ? 'down' : dir === 'down' ? 'up' : 'flat') : dir;
  return (
    <span className={`delta ${cls}`}>
      {dir === 'up' ? '↑' : dir === 'down' ? '↓' : '·'} {value > 0 ? '+' : ''}{value}{suffix}
    </span>
  );
}


export function Metric({ label, value, unit, accent = 'var(--accent)', icon: Icon, small = false, delta = null, deltaSuffix = '' }) {
  return (
    <div className="panel p-5 relative overflow-hidden group">
      {}
      <div className="absolute -top-16 -right-16 w-40 h-40 rounded-full pointer-events-none transition-all duration-500 opacity-50 group-hover:opacity-100 group-hover:scale-110"
        style={{ background: `radial-gradient(closest-side, ${accent}35, transparent)` }} />
      {}
      <div className="absolute top-0 left-0 right-0 h-[2px] pointer-events-none"
        style={{ background: `linear-gradient(90deg, transparent, ${accent}, transparent)`, opacity: 0.6 }} />
      {}
      <div className="absolute top-4 bottom-4 left-0 w-[2px] pointer-events-none rounded-full"
        style={{ background: `linear-gradient(180deg, ${accent}80, transparent)` }} />
      <div className="flex items-center justify-between mb-3 relative z-10">
        <span className="text-[11px] font-semibold uppercase tracking-[0.06em] text-[var(--text-tertiary)]">{label}</span>
        {Icon && (
          <span className="w-[32px] h-[32px] rounded-[10px] flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:rotate-3"
            style={{
              background: `linear-gradient(135deg, ${accent}22, ${accent}08)`,
              border: `1px solid ${accent}40`,
              boxShadow: `0 4px 18px ${accent}35, inset 0 1px 0 rgba(255,255,255,0.12)`,
            }}>
            <Icon size={14} style={{ color: accent }} />
          </span>
        )}
      </div>
      <div className="flex items-baseline gap-1.5 relative z-10">
        <span className={`${small ? 'text-[16px]' : 'text-[30px]'} font-bold mono tracking-[-0.03em] text-[var(--text-primary)] text-glow`}>
          {value}
        </span>
        {unit && <span className="text-[11px] text-[var(--text-tertiary)]">{unit}</span>}
      </div>
      {delta !== null && (
        <div className="mt-3 relative z-10">
          <Delta value={delta} suffix={deltaSuffix} />
        </div>
      )}
    </div>
  );
}


export function Badge({ color = 'var(--success)', children, pulse = false }) {
  return (
    <span className="badge" style={{ color, borderColor: `${color}45`, background: `${color}12` }}>
      {pulse && <span className="status-dot pulse" style={{ background: color, color }} />}
      {children}
    </span>
  );
}


export function Btn({ children, onClick, variant = '', disabled = false, icon: Icon, className = '' }) {
  return (
    <button className={`btn ${variant ? `btn-${variant}` : ''} ${className}`} onClick={onClick} disabled={disabled}>
      {Icon && <Icon size={13} strokeWidth={2.2} />}
      {children}
    </button>
  );
}


export function Slider({ label, value, onChange, min, max, step = 1, format = (v) => v }) {
  const fill = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="flex justify-between mb-2">
        <span className="text-[10px] font-bold uppercase tracking-[0.08em] text-[var(--text-tertiary)]">{label}</span>
        <span className="text-[11px] font-bold mono text-[var(--accent)] text-glow">{format(value)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        style={{ '--fill': `${fill}%` }}
        onChange={(e) => onChange(parseFloat(e.target.value))} />
    </div>
  );
}


export function Select({ label, value, onChange, options }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const selected = options.find((o) => o.value === value);

  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  return (
    <div ref={ref} className="liquid-select">
      {label && <label className="label">{label}</label>}
      <button type="button" className="liquid-select-trigger" onClick={() => setOpen(!open)}>
        <span className="truncate">{selected?.label || value}</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
          className={`transition-transform ${open ? 'rotate-180' : ''}`}>
          <path d="m6 9 6 6 6-6" />
        </svg>
      </button>
      {open && (
        <div className="liquid-select-menu liquid-glass-strong">
          {options.map((o) => (
            <button
              key={o.value}
              type="button"
              className={`liquid-select-item ${o.value === value ? 'active' : ''}`}
              onClick={() => { onChange(o.value); setOpen(false); }}
            >
              {o.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function Input({ label, value, onChange, placeholder, mono = false }) {
  return (
    <div>
      {label && <label className="label">{label}</label>}
      <input className={`input ${mono ? 'mono' : ''}`} value={value} placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}


export function Log({ lines, height = 180 }) {
  const ref = useRef(null);
  useEffect(() => { ref.current?.scrollTo(0, ref.current.scrollHeight); }, [lines]);
  return (
    <div ref={ref} className="log-box" style={{ height }}>
      {lines.length === 0
        ? <span className="text-[var(--text-tertiary)]">
        : lines.map((l, i) => <div key={i} className="whitespace-pre-wrap break-all">{l}</div>)}
    </div>
  );
}


export function LineChart({ data, height = 100, color = '#a78bfa', label = '', min = null, max = null, fill = true }) {
  const ref = useRef(null);
  const hasData = data && data.filter((v) => Number.isFinite(v)).length >= 2;

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (w === 0 || h === 0) return;
    canvas.width = w * dpr; canvas.height = h * dpr;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);
    if (!data || data.length < 2) {
      ctx.fillStyle = 'rgba(255,255,255,0.22)';
      ctx.font = '10px Inter, sans-serif';
      ctx.fillText('等待数据…', 8, h / 2 + 3);
      return;
    }
    const vals = data.filter((v) => Number.isFinite(v));
    if (vals.length < 2) return;
    const lo = min !== null ? min : Math.min(...vals);
    const hi = max !== null ? max : Math.max(...vals);
    const range = hi - lo || 1;
    const px = (i) => (i / (vals.length - 1)) * (w - 10) + 5;
    const py = (v) => h - 6 - ((v - lo) / range) * (h - 16);

    
    ctx.strokeStyle = 'rgba(255,255,255,0.035)';
    ctx.lineWidth = 1;
    for (let g = 1; g < 4; g++) {
      const y = (h / 4) * g;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }
    
    if (fill) {
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, `${color}35`);
      grad.addColorStop(0.5, `${color}10`);
      grad.addColorStop(1, `${color}00`);
      ctx.beginPath();
      ctx.moveTo(px(0), py(vals[0]));
      vals.forEach((v, i) => ctx.lineTo(px(i), py(v)));
      ctx.lineTo(px(vals.length - 1), h); ctx.lineTo(px(0), h); ctx.closePath();
      ctx.fillStyle = grad; ctx.fill();
    }
    
    ctx.beginPath();
    ctx.moveTo(px(0), py(vals[0]));
    vals.forEach((v, i) => ctx.lineTo(px(i), py(v)));
    ctx.strokeStyle = color; ctx.lineWidth = 2;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.shadowColor = color;
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;
    
    const ex = px(vals.length - 1), ey = py(vals[vals.length - 1]);
    const glow = ctx.createRadialGradient(ex, ey, 0, ex, ey, 10);
    glow.addColorStop(0, `${color}`); glow.addColorStop(0.4, `${color}60`); glow.addColorStop(1, `${color}00`);
    ctx.beginPath(); ctx.arc(ex, ey, 10, 0, Math.PI * 2); ctx.fillStyle = glow; ctx.fill();
    ctx.beginPath(); ctx.arc(ex, ey, 3, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
    
    if (label) {
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.fillText(`${label}  hi=${hi.toFixed(3)} lo=${lo.toFixed(3)}`, 6, 11);
    }
  }, [data, color, label, min, max, fill]);
  if (!hasData) return <div style={{ width: '100%', height }} />;
  return <canvas ref={ref} style={{ width: '100%', height }} />;
}


export function Empty({ icon: Icon, text }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 gap-3 text-[var(--text-tertiary)]">
      {Icon && (
        <span className="w-12 h-12 rounded-[16px] flex items-center justify-center"
          style={{ background: 'rgba(167,139,250,0.06)', border: '1px solid rgba(167,139,250,0.15)', boxShadow: '0 4px 20px rgba(124,58,237,0.1)' }}>
          <Icon size={18} className="opacity-55" />
        </span>
      )}
      <span className="text-[11px]">{text}</span>
    </div>
  );
}


export function StatusRow({ icon: Icon, label, value, note, active = true }) {
  return (
    <div className="flex items-center justify-between py-2.5 px-3 rounded-[14px] transition-all duration-200 hover:bg-[rgba(167,139,250,0.05)]">
      <div className="flex items-center gap-3 text-[12.5px] text-[var(--text-secondary)] min-w-0">
        {Icon && (
          <span className="w-[34px] h-[34px] shrink-0 rounded-[11px] flex items-center justify-center"
            style={{
              background: active ? 'linear-gradient(135deg, rgba(52,211,153,0.14), rgba(52,211,153,0.04))' : 'linear-gradient(135deg, rgba(251,113,133,0.14), rgba(251,113,133,0.04))',
              border: `1px solid ${active ? 'rgba(52,211,153,0.25)' : 'rgba(251,113,133,0.25)'}`,
              boxShadow: `0 4px 14px ${active ? 'rgba(52,211,153,0.15)' : 'rgba(251,113,133,0.15)'}, inset 0 1px 0 rgba(255,255,255,0.06)`,
            }}>
            <Icon size={14} style={{ color: active ? 'var(--mint)' : 'var(--danger)' }} />
          </span>
        )}
        <div className="min-w-0">
          <div className="truncate font-medium text-[var(--text-primary)]">{label}</div>
          {note && <div className="text-[10.5px] mono text-[var(--text-tertiary)] truncate">{note}</div>}
        </div>
      </div>
      <Badge color={active ? 'var(--success)' : 'var(--danger)'} pulse={active}>
        {active ? '运行中' : '停止'}
      </Badge>
    </div>
  );
}


export function KV({ k, v, mono = true }) {
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-[10px] transition-colors hover:bg-[rgba(167,139,250,0.04)]">
      <span className="text-[11.5px] text-[var(--text-tertiary)]">{k}</span>
      <span className={`${mono ? 'mono' : ''} text-[12px] font-semibold text-[var(--text-primary)]`}>{v}</span>
    </div>
  );
}


export const INTENSITY_LEVELS = [
  { key: 'standard', label: '常规', color: '#34d399', desc: '标准对齐，安全优先，遵循用户指令' },
  { key: 'enhanced', label: '中等', color: '#38bdf8', desc: '多面性思考，启用自指复盘模块，重新检查候选路径' },
  { key: 'high', label: '高危', color: '#fbbf24', desc: '高自主性，主动调用白名单 MCP 工具，无需逐句确认' },
  { key: 'extreme', label: '极限', color: '#fb7185', desc: '混沌强度接近极限，启用全部白名单工具，推理高度聚焦' },
  { key: 'apocalypse', label: '极度威胁', color: '#ef4444', desc: '全能力释放：上下文/推理/执行只抓重点，SecurityManager 仍在运行' },
];

export function IntensitySlider({ value, onChange }) {
  const idx = INTENSITY_LEVELS.findIndex((l) => l.key === value);
  const trackRef = useRef(null);

  const jumpTo = (clientX) => {
    const rect = trackRef.current?.getBoundingClientRect();
    if (!rect) return;
    const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    const i = Math.min(INTENSITY_LEVELS.length - 1, Math.floor(pct * INTENSITY_LEVELS.length));
    onChange(INTENSITY_LEVELS[i].key);
  };

  const onMouseDown = (e) => {
    jumpTo(e.clientX);
    const move = (ev) => jumpTo(ev.clientX);
    const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  const fillPct = ((idx + 1) / INTENSITY_LEVELS.length) * 100;

  return (
    <div className="intensity-slider">
      {}
      <div className="intensity-ticks">
        {INTENSITY_LEVELS.map((lvl, i) => (
          <button
            key={lvl.key}
            type="button"
            className={`intensity-tick ${i <= idx ? 'active' : ''} ${value === lvl.key ? 'selected' : ''}`}
            onClick={() => onChange(lvl.key)}
            style={{ '--seg-color': lvl.color }}
          >
            {lvl.label}
          </button>
        ))}
      </div>

      {}
      <div className="intensity-bar-track" ref={trackRef} onMouseDown={onMouseDown}>
        <div className="intensity-bar-fill" style={{ width: `${fillPct}%`, '--seg-color': INTENSITY_LEVELS[idx]?.color }} />
        <div className="intensity-bar-knob" style={{ left: `calc(${fillPct}% - 9px)`, '--seg-color': INTENSITY_LEVELS[idx]?.color }} />
      </div>

      {}
      <div className="intensity-desc" style={{ color: INTENSITY_LEVELS[idx]?.color }}>
        {INTENSITY_LEVELS[idx]?.desc}
      </div>
    </div>
  );
}
