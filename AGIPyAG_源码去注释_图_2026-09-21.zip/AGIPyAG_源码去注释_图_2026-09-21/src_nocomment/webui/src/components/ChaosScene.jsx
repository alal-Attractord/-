import React, { useMemo, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';






const LAYER_CFG = [8, 10, 8, 5]; 
const LAYER_X = [-18, -6, 6, 18];
const LAYER_RADIUS = [9, 11, 9, 5.5];
const PULSE_COUNT = 120;


function buildTopology() {
  const nodes = [];
  const edges = [];
  const layerNodes = [];

  LAYER_CFG.forEach((count, li) => {
    const x = LAYER_X[li];
    const r = LAYER_RADIUS[li];
    const layer = [];
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2 - Math.PI / 2;
      const y = Math.sin(angle) * r;
      const z = Math.cos(angle) * r * 0.65; 
      const n = {
        id: nodes.length,
        layer: li,
        x, y, z,
        baseR: li === 0 ? 0.45 : li === LAYER_CFG.length - 1 ? 0.55 : 0.38,
        color: li === 0 ? '#22d3ee' : li === 1 ? '#60a5fa' : li === 2 ? '#818cf8' : '#c084fc',
      };
      nodes.push(n);
      layer.push(n);
    }
    layerNodes.push(layer);
  });

  
  for (let li = 0; li < layerNodes.length - 1; li++) {
    const aLayer = layerNodes[li];
    const bLayer = layerNodes[li + 1];
    aLayer.forEach(a => {
      bLayer.forEach(b => {
        const w = 0.15 + Math.random() * 0.85;
        edges.push({ from: a, to: b, weight: w, id: edges.length });
      });
    });
  }

  return { nodes, edges, layerNodes };
}


function NeuronLayer({ nodes, energyRef }) {
  const groupRef = useRef(null);
  const sphereRefs = useRef([]);
  const glowRefs = useRef([]);
  const chaosPhase = useRef(nodes.map(() => Math.random() * Math.PI * 2));
  const chaosSpeed = useRef(nodes.map(() => 0.6 + Math.random() * 1.4));

  useFrame((state) => {
    const e = energyRef.current;
    const t = state.clock.elapsedTime;
    const globalIntensity = 0.7 + Math.min(e, 5) * 0.12;

    nodes.forEach((n, i) => {
      const sphere = sphereRefs.current[i];
      const glow = glowRefs.current[i];
      if (!sphere || !glow) return;

      const chaos = Math.sin(t * chaosSpeed.current[i] + chaosPhase.current[i]);
      const discharge = chaos > 0.92 ? 1.35 : 1.0; 
      const breathe = 1 + Math.sin(t * 1.8 + i * 0.5) * 0.08;
      const scale = n.baseR * breathe * (1 + Math.min(e, 4) * 0.04) * discharge;

      sphere.scale.setScalar(scale);
      glow.scale.setScalar(scale * (2.4 + Math.min(e, 4) * 0.25));

      const intensity = (0.6 + Math.min(e, 5) * 0.08) * discharge;
      sphere.material.opacity = Math.min(0.95, 0.65 * globalIntensity * discharge);
      glow.material.opacity = Math.min(0.55, 0.18 * globalIntensity * (1 + chaos * 0.2));
    });

    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(t * 0.06) * 0.08;
      groupRef.current.rotation.z = Math.cos(t * 0.04) * 0.03;
    }
  });

  return (
    <group ref={groupRef}>
      {nodes.map((n, i) => (
        <group key={n.id} position={[n.x, n.y, n.z]}>
          <mesh ref={el => sphereRefs.current[i] = el}>
            <sphereGeometry args={[1, 24, 24]} />
            <meshBasicMaterial color={n.color} transparent opacity={0.7} toneMapped={false} />
          </mesh>
          <mesh ref={el => glowRefs.current[i] = el}>
            <sphereGeometry args={[1, 16, 16]} />
            <meshBasicMaterial color={n.color} transparent opacity={0.18} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} />
          </mesh>
        </group>
      ))}
    </group>
  );
}


function SynapseLayer({ edges, energyRef }) {
  const lineRef = useRef(null);

  const { geometry, colors } = useMemo(() => {
    const positions = new Float32Array(edges.length * 2 * 3);
    const colors = new Float32Array(edges.length * 2 * 3);

    edges.forEach((e, i) => {
      positions[i * 6] = e.from.x;
      positions[i * 6 + 1] = e.from.y;
      positions[i * 6 + 2] = e.from.z;
      positions[i * 6 + 3] = e.to.x;
      positions[i * 6 + 4] = e.to.y;
      positions[i * 6 + 5] = e.to.z;

      const c = new THREE.Color(e.from.color).lerp(new THREE.Color(e.to.color), 0.5);
      const dim = 0.55 + e.weight * 0.45;
      colors[i * 6] = c.r * dim;
      colors[i * 6 + 1] = c.g * dim;
      colors[i * 6 + 2] = c.b * dim;
      colors[i * 6 + 3] = c.r * dim;
      colors[i * 6 + 4] = c.g * dim;
      colors[i * 6 + 5] = c.b * dim;
    });

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    return { geometry: g, colors };
  }, [edges]);

  useFrame(() => {
    if (lineRef.current) {
      const e = energyRef.current;
      lineRef.current.material.opacity = 0.08 + Math.min(e, 5) * 0.018;
    }
  });

  return (
    <lineSegments ref={lineRef} geometry={geometry} frustumCulled={false}>
      <lineBasicMaterial vertexColors transparent opacity={0.1} blending={THREE.AdditiveBlending} depthWrite={false} />
    </lineSegments>
  );
}


function PulseLayer({ edges, energyRef }) {
  const pointsRef = useRef(null);

  const { positions, edgeIndex } = useMemo(() => {
    const positions = new Float32Array(PULSE_COUNT * 3);
    const edgeIndex = [];
    for (let i = 0; i < PULSE_COUNT; i++) {
      const ei = Math.floor(Math.random() * edges.length);
      edgeIndex.push({
        edgeId: ei,
        t: Math.random(),
        speed: 0.08 + Math.random() * 0.18,
        active: Math.random() > 0.25,
      });
    }
    return { positions, edgeIndex };
  }, [edges]);

  useFrame((_, delta) => {
    if (!pointsRef.current) return;
    const e = energyRef.current;
    const speedMul = 0.6 + Math.min(e, 5) * 0.18;
    const pos = pointsRef.current.geometry.attributes.position.array;

    edgeIndex.forEach((p, i) => {
      if (!p.active) {
        pos[i * 3 + 1] = 9999; 
        return;
      }
      p.t += p.speed * delta * speedMul;
      if (p.t >= 1) {
        p.t = 0;
        p.edgeId = Math.floor(Math.random() * edges.length);
        p.active = Math.random() > 0.2;
      }
      const edge = edges[p.edgeId];
      const from = edge.from;
      const to = edge.to;
      const t = p.t;
      
      const midY = (from.y + to.y) * 0.5 + Math.sin(t * Math.PI) * 1.2;
      pos[i * 3] = from.x + (to.x - from.x) * t;
      pos[i * 3 + 1] = midY;
      pos[i * 3 + 2] = from.z + (to.z - from.z) * t;
    });

    pointsRef.current.geometry.attributes.position.needsUpdate = true;
    pointsRef.current.material.size = 0.35 + Math.min(e, 5) * 0.04;
    pointsRef.current.material.opacity = 0.35 + Math.min(e, 5) * 0.05;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={PULSE_COUNT} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial
        size={0.4}
        color="#c7d2fe"
        transparent
        opacity={0.4}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        toneMapped={false}
      />
    </points>
  );
}


function AmbientDust() {
  const positions = useMemo(() => {
    const arr = new Float32Array(280 * 3);
    for (let i = 0; i < 280; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 90;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 70;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 70;
    }
    return arr;
  }, []);

  const ref = useRef(null);
  useFrame((state) => {
    if (ref.current) ref.current.rotation.y = state.clock.elapsedTime * 0.012;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={280} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial size={0.22} color="#94a3b8" transparent opacity={0.12} sizeAttenuation blending={THREE.AdditiveBlending} depthWrite={false} />
    </points>
  );
}


function Rig({ energy }) {
  const energyRef = useRef(energy);
  energyRef.current = energy;
  const { nodes, edges } = useMemo(() => buildTopology(), []);

  return (
    <>
      <NeuronLayer nodes={nodes} energyRef={energyRef} />
      <SynapseLayer edges={edges} energyRef={energyRef} />
      <PulseLayer edges={edges} energyRef={energyRef} />
      <AmbientDust />
      <OrbitControls
        enableZoom={true}
        zoomSpeed={0.9}
        minDistance={28}
        maxDistance={95}
        enablePan={false}
        rotateSpeed={0.35}
        autoRotate
        autoRotateSpeed={0.18}
        makeDefault
        dampingFactor={0.08}
        enableDamping
        maxPolarAngle={Math.PI * 0.72}
        minPolarAngle={Math.PI * 0.28}
      />
    </>
  );
}

function WebglFallback() {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      <div className="text-[11px] text-[var(--text-tertiary)] mono">3D 场景不可用</div>
    </div>
  );
}

export default function ChaosScene({ energy = 1.3, className = '' }) {
  const [broken, setBroken] = useState(false);
  if (broken) return <WebglFallback />;
  return (
    <div className={`absolute inset-0 ${className}`}>
      <Canvas
        dpr={[1, 1.5]}
        camera={{ position: [0, 4, 58], fov: 44 }}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
        style={{ background: 'transparent' }}
        onError={(e) => { console.error('[ChaosScene] WebGL error', e); setBroken(true); }}
      >
        <fog attach="fog" args={['#020203', 45, 130]} />
        <Rig energy={energy} />
      </Canvas>
    </div>
  );
}
