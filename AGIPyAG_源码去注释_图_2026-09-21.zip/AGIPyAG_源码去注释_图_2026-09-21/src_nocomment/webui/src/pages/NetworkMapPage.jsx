import React, { useEffect, useRef, useState } from 'react';
import { Globe, Activity, Shield, Download, RefreshCw, Filter, Clock, Server, Zap, Database, MapPin, Trash2 } from 'lucide-react';
import { Page, Card, Metric, Btn, Badge } from '../components/ui';
import { api } from '../api';
import NetworkMapCanvas from '../components/NetworkMapCanvas';

const ACTION_LABELS = {
  api_call: 'API调用',
  ai_inference: 'AI推理',
  data_download: '数据下载',
  web_scrape: '网页抓取',
  training_fetch: '训练获取',
  internal: '内部通信',
};

const ACTION_COLORS = {
  api_call: 'var(--mint)',
  ai_inference: 'var(--pink)',
  data_download: 'var(--amber)',
  web_scrape: 'var(--cyan)',
  training_fetch: 'var(--violet)',
  internal: 'var(--text-tertiary)',
};

export default function NetworkMapPage() {
  const [stats, setStats] = useState(null);
  const [mapStats, setMapStats] = useState(null);
  const [records, setRecords] = useState([]);
  const [connections, setConnections] = useState([]);
  const [nodes, setNodes] = useState({});
  const [loading, setLoading] = useState(false);
  const [mapLoading, setMapLoading] = useState(false);
  const [filterAction, setFilterAction] = useState('');
  const [sinceMinutes, setSinceMinutes] = useState(60);
  const [selectedNode, setSelectedNode] = useState(null);
  const [offlineMode, setOfflineMode] = useState(false);
  const timerRef = useRef(null);

  const refresh = async () => {
    setLoading(true);
    try {
      const [s, r, c, n, ms] = await Promise.all([
        api.networkStats(),
        api.networkRecords(200, filterAction || undefined, sinceMinutes),
        api.networkConnections(),
        api.mapNodes(),
        api.mapStats(),
      ]);
      setStats(s);
      setRecords(r.records || []);
      setConnections(c.connections || []);
      setNodes(n.nodes || {});
      setMapStats(ms);
    } catch (e) {
      console.error('网络追踪数据获取失败:', e);
      setOfflineMode(true);
    }
    setLoading(false);
  };

  const downloadRegion = async () => {
    setMapLoading(true);
    try {
      
      const result = await api.mapDownload({
        lat_min: -60,
        lon_min: -180,
        lat_max: 75,
        lon_max: 180,
        zoom_levels: [1, 2, 3, 4],
      });
      alert(`瓦片下载完成: 请求${result.requested}个, 下载${result.downloaded}个, 缓存${result.cached}个, 错误${result.errors}个`);
      const ms = await api.mapStats();
      setMapStats(ms);
    } catch (e) {
      console.error('瓦片下载失败:', e);
      alert('瓦片下载失败: ' + e.message);
    }
    setMapLoading(false);
  };

  const clearCache = async () => {
    if (!confirm('确定要清空地图瓦片缓存吗？')) return;
    try {
      const result = await api.mapClear();
      alert(`已清除 ${result.removed_files} 个缓存文件`);
      setMapStats(prev => prev ? { ...prev, cache_files: 0, cache_size_mb: 0 } : null);
    } catch (e) {
      console.error('清空缓存失败:', e);
    }
  };

  useEffect(() => {
    refresh();
    timerRef.current = setInterval(refresh, 5000);
    return () => clearInterval(timerRef.current);
  }, [filterAction, sinceMinutes]);

  const filteredRecords = filterAction
    ? records.filter((r) => r.action === filterAction)
    : records;

  const nodeRecords = selectedNode
    ? records.filter((r) => r.target_node === selectedNode.key || r.source === selectedNode.key)
    : [];

  const formatBytes = (bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Page
      title="全球网络地图"
      sub="真实离线地图 · OpenStreetMap 瓦片缓存 · 全链路网络追踪"
      actions={
        <div className="flex items-center gap-2">
          <Btn icon={Download} onClick={downloadRegion} disabled={mapLoading}>
            {mapLoading ? '下载中...' : '下载瓦片'}
          </Btn>
          <Btn icon={Trash2} variant="ghost" onClick={clearCache}>
            清空缓存
          </Btn>
          <Btn icon={RefreshCw} onClick={refresh} disabled={loading}>
            {loading ? '刷新中...' : '刷新'}
          </Btn>
        </div>
      }
    >
      {}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-5">
        <Metric
          label="总请求数"
          value={stats?.total_requests ?? '-'}
          accent="var(--accent)"
          icon={Activity}
        />
        <Metric
          label="活跃连接"
          value={stats?.active_connections ?? '-'}
          accent="var(--cyan)"
          icon={Server}
        />
        <Metric
          label="数据流量"
          value={formatBytes((stats?.total_bytes_in || 0) + (stats?.total_bytes_out || 0))}
          accent="var(--violet)"
          icon={Database}
        />
        <Metric
          label="阻断次数"
          value={stats?.blocked_count ?? 0}
          accent={stats?.blocked_count > 0 ? 'var(--danger)' : 'var(--mint)'}
          icon={Shield}
        />
        <Metric
          label="瓦片缓存"
          value={`${mapStats?.cache_size_mb?.toFixed(1) ?? '-'} MB`}
          accent="var(--amber)"
          icon={MapPin}
        />
      </div>

      {}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-5">
        {}
        <Card className="lg:col-span-2" pad={false}>
          <NetworkMapCanvas
            nodes={nodes}
            connections={connections}
            records={records}
            onNodeClick={setSelectedNode}
            offlineMode={offlineMode}
          />
        </Card>

        {}
        <div className="space-y-4">
          {}
          {selectedNode && (
            <Card title={`节点: ${selectedNode.label}`}>
              <div className="space-y-2 text-[12px]">
                <div className="flex justify-between">
                  <span className="text-[var(--text-tertiary)]">类型</span>
                  <Badge color={ACTION_COLORS[selectedNode.type] || 'var(--text-secondary)'}>
                    {selectedNode.type}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-tertiary)]">区域</span>
                  <span className="text-[var(--text-primary)]">{selectedNode.region}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-tertiary)]">坐标</span>
                  <span className="mono text-[var(--text-secondary)]">
                    {selectedNode.lat.toFixed(3)}, {selectedNode.lon.toFixed(3)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-tertiary)]">相关记录</span>
                  <span className="mono text-[var(--accent)]">{nodeRecords.length}</span>
                </div>
              </div>
              <Btn variant="ghost" className="mt-3 w-full" onClick={() => setSelectedNode(null)}>
                清除选择
              </Btn>
            </Card>
          )}

          {}
          <Card title="地图缓存状态">
            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">缓存目录</span>
                <span className="mono text-[var(--text-secondary)] truncate max-w-[150px]">
                  {mapStats?.cache_dir || '-'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">缓存文件数</span>
                <span className="mono text-[var(--text-primary)]">{mapStats?.cache_files ?? '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">缓存大小</span>
                <span className="mono text-[var(--accent)]">{mapStats?.cache_size_mb?.toFixed(1) ?? '-'} MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">最大缓存</span>
                <span className="mono text-[var(--text-secondary)]">{mapStats?.max_cache_mb ?? '-'} MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">总请求</span>
                <span className="mono text-[var(--text-secondary)]">{mapStats?.total_requests ?? '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">缓存命中</span>
                <span className="mono text-[var(--mint)]">{mapStats?.cache_hits ?? '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">下载次数</span>
                <span className="mono text-[var(--cyan)]">{mapStats?.downloads ?? '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-tertiary)]">下载错误</span>
                <span className="mono text-[var(--danger)]">{mapStats?.download_errors ?? '-'}</span>
              </div>
            </div>
          </Card>

          {}
          <Card title="动作分布">
            <div className="space-y-2">
              {stats?.action_breakdown &&
                Object.entries(stats.action_breakdown).map(([action, count]) => (
                  <div key={action} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ background: ACTION_COLORS[action] || '#fff' }}
                      />
                      <span className="text-[11px] text-[var(--text-secondary)]">
                        {ACTION_LABELS[action] || action}
                      </span>
                    </div>
                    <span className="text-[11px] mono text-[var(--text-primary)]">{count}</span>
                  </div>
                ))}
            </div>
          </Card>

          {}
          <Card title="区域分布">
            <div className="space-y-1 max-h-[200px] overflow-y-auto">
              {stats?.region_breakdown &&
                Object.entries(stats.region_breakdown)
                  .sort((a, b) => b[1] - a[1])
                  .map(([region, count]) => (
                    <div key={region} className="flex items-center justify-between py-1">
                      <span className="text-[11px] text-[var(--text-secondary)]">{region}</span>
                      <span className="text-[11px] mono text-[var(--text-primary)]">{count}</span>
                    </div>
                  ))}
            </div>
          </Card>
        </div>
      </div>

      {}
      <Card
        title="网络追踪日志"
        actions={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              <Filter size={12} className="text-[var(--text-tertiary)]" />
              <select
                className="input text-[11px] h-7 py-0 px-2"
                value={filterAction}
                onChange={(e) => setFilterAction(e.target.value)}
              >
                <option value="">全部动作</option>
                {Object.entries(ACTION_LABELS).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-1">
              <Clock size={12} className="text-[var(--text-tertiary)]" />
              <select
                className="input text-[11px] h-7 py-0 px-2"
                value={sinceMinutes}
                onChange={(e) => setSinceMinutes(Number(e.target.value))}
              >
                <option value={5}>最近5分钟</option>
                <option value={15}>最近15分钟</option>
                <option value={60}>最近1小时</option>
                <option value={360}>最近6小时</option>
                <option value={1440}>最近24小时</option>
              </select>
            </div>
          </div>
        }
      >
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>时间</th>
                <th>动作</th>
                <th>来源</th>
                <th>目标</th>
                <th>区域</th>
                <th>状态</th>
                <th>授权</th>
                <th>数据量</th>
                <th>耗时</th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.length === 0 && (
                <tr>
                  <td colSpan={9} className="text-center py-8 text-[var(--text-tertiary)]">
                    暂无网络活动记录
                  </td>
                </tr>
              )}
              {filteredRecords.map((r) => (
                <tr key={r.id} className="group">
                  <td className="mono text-[10px]">{r.timestamp?.slice(11, 23)}</td>
                  <td>
                    <Badge color={ACTION_COLORS[r.action] || 'var(--text-secondary)'}>
                      {ACTION_LABELS[r.action] || r.action}
                    </Badge>
                  </td>
                  <td className="mono text-[10px] text-[var(--text-secondary)]">{r.source}</td>
                  <td className="text-[11px] text-[var(--text-primary)] truncate max-w-[120px]">
                    {r.target}
                  </td>
                  <td className="text-[10px] text-[var(--text-tertiary)]">{r.target_region}</td>
                  <td>
                    {r.status_code ? (
                      <span
                        className="text-[10px] mono"
                        style={{
                          color:
                            r.status_code < 300
                              ? 'var(--mint)'
                              : r.status_code < 400
                              ? 'var(--amber)'
                              : 'var(--danger)',
                        }}
                      >
                        {r.status_code}
                      </span>
                    ) : (
                      <span className="text-[10px] text-[var(--text-tertiary)]">-</span>
                    )}
                  </td>
                  <td>
                    <span
                      className="text-[10px]"
                      style={{
                        color:
                          r.auth_type === 'blocked'
                            ? 'var(--danger)'
                            : r.auth_type === 'none'
                            ? 'var(--amber)'
                            : 'var(--mint)',
                      }}
                    >
                      {r.auth_type}
                    </span>
                  </td>
                  <td className="mono text-[10px] text-[var(--text-secondary)]">
                    {formatBytes(r.bytes_in + r.bytes_out)}
                  </td>
                  <td className="mono text-[10px] text-[var(--text-tertiary)]">
                    {r.duration_ms ? `${r.duration_ms.toFixed(0)}ms` : '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </Page>
  );
}
