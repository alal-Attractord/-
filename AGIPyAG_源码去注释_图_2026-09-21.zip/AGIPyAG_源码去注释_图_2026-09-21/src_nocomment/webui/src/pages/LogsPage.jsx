import React, { useEffect, useRef, useState } from 'react';
import { ScrollText, RefreshCw, Download } from 'lucide-react';
import { Page, Card, Btn, Log } from '../components/ui';
import { api } from '../api';

export default function LogsPage() {
  const [lines, setLines] = useState([]);
  const timer = useRef(null);

  const refresh = async () => {
    try {
      const r = await api.logs(200);
      setLines(r.logs || []);
    } catch {  }
  };

  useEffect(() => {
    refresh();
    timer.current = setInterval(refresh, 2000);
    return () => clearInterval(timer.current);
  }, []);

  const download = () => {
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'agipyag-engine.log';
    a.click(); URL.revokeObjectURL(url);
  };

  return (
    <Page title="系统日志" sub="后端引擎实时日志 · 每 2 秒刷新"
      actions={<>
        <Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>
        <Btn icon={Download} onClick={download}>下载</Btn>
      </>}>
      <Card title={`引擎日志（最近 ${lines.length} 条）`}>
        <Log lines={lines} height={520} />
      </Card>
    </Page>
  );
}
