import React, { useEffect, useRef, useState } from 'react';
import { Files, RefreshCw, Hammer, FileText, Binary } from 'lucide-react';
import { Page, Card, Btn, Metric, Badge, KV } from '../components/ui';
import { api } from '../api';

export default function CorpusPage() {
  const [stats, setStats] = useState(null);
  const [rebuildInfo, setRebuildInfo] = useState(null);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const timer = useRef(null);

  const refresh = async () => {
    try { setStats(await api.corpusStats()); } catch {  }
  };

  useEffect(() => {
    refresh();
    timer.current = setInterval(refresh, 5000);
    return () => clearInterval(timer.current);
  }, []);

  const rebuild = async () => {
    setBusy(true);
    setMsg('');
    try {
      const r = await api.corpusRebuild();
      setRebuildInfo(r);
      setMsg(r.rebuilt ? `已重建，${r.chars.toLocaleString()} 字符` : '语料已是最新');
      refresh();
    } catch (e) { setMsg(`重建失败: ${e.message}`); }
    setBusy(false);
  };

  const pathParts = stats?.path?.split(/[\\/]/) || [];
  const fileName = pathParts.length ? pathParts[pathParts.length - 1] : '-';

  return (
    <Page title="语料库" sub="项目真实 .md / .py 文本聚合 · 训练语料实时统计"
      actions={<Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Metric label="Token 数" value={stats?.tokens?.toLocaleString() ?? '-'} accent="var(--accent)" icon={Binary} />
        <Metric label="语料文件" value={fileName} accent="var(--cyan)" icon={FileText} small />
        <Metric label="字符数" value={rebuildInfo ? rebuildInfo.chars.toLocaleString() : '-'} accent="var(--violet)" icon={Files} />
        <Metric label="状态" value={rebuildInfo?.rebuilt ? '已重建' : '就绪'} accent={rebuildInfo?.rebuilt ? 'var(--success)' : 'var(--text-tertiary)'} icon={RefreshCw} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="语料管理" className="space-y-5">
          <div className="panel p-3 text-[11px] leading-relaxed text-[var(--text-secondary)]">
            语料库从项目内全部 Markdown 文档与 Python 注释/Docstring 中提取，并注入 AGI 领域种子文本。
            重建后会自动重新 tokenize。
          </div>
          <Btn variant="primary" icon={Hammer} onClick={rebuild} disabled={busy}>
            {busy ? '重建中…' : '强制重建语料库'}
          </Btn>
          {msg && (
            <div className="flex items-center gap-2 text-[11px] mono text-[var(--text-tertiary)]">
              {rebuildInfo?.rebuilt ? <Badge color="var(--success)">OK</Badge> : null}
              {msg}
            </div>
          )}
        </Card>

        <Card title="语料详情" className="lg:col-span-2">
          <div className="space-y-2">
            <KV k="语料路径" v={stats?.path ?? '-'} />
            <KV k="Token 总数" v={stats?.tokens?.toLocaleString() ?? '-'} />
            <KV k="字符总数" v={rebuildInfo ? rebuildInfo.chars.toLocaleString() : (stats?.tokens ? '重建后可见' : '-')} />
            <KV k="最近重建" v={rebuildInfo?.rebuilt ? '刚刚' : '启动后未重建'} />
          </div>
        </Card>
      </div>
    </Page>
  );
}
