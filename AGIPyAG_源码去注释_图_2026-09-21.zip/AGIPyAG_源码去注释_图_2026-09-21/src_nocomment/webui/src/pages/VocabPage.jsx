import React, { useEffect, useRef, useState } from 'react';
import { Hammer, BookOpenText, RefreshCw } from 'lucide-react';
import { Page, Card, Btn, Slider, Select, Badge, Metric } from '../components/ui';
import { api } from '../api';

export default function VocabPage() {
  const [stats, setStats] = useState(null);
  const [size, setSize] = useState(8000);
  const [type, setType] = useState('bpe');
  const [msg, setMsg] = useState('');
  const timer = useRef(null);

  const refresh = async () => {
    try { setStats(await api.vocabStats()); } catch {  }
  };

  useEffect(() => {
    refresh();
    timer.current = setInterval(refresh, 2000);
    return () => clearInterval(timer.current);
  }, []);

  const build = async () => {
    try {
      const r = await api.vocabBuild({ vocab_size: size, model_type: type });
      setMsg(r.message);
    } catch (e) { setMsg(e.message); }
  };

  const b = stats?.builder;

  return (
    <Page title="词表构建器" sub="SentencePiece 真实 BPE/Unigram 训练 · 当前生产词表 32200"
      actions={<Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Metric label="当前词表" value={stats?.vocab_size ?? '-'} accent="var(--accent)" icon={BookOpenText} />
        <Metric label="算法" value={stats?.active_model ?? '-'} accent="var(--accent)" small />
        <Metric label="语料大小" value={stats ? (stats.corpus_chars / 1024).toFixed(0) : '-'} unit="KB" accent="var(--accent)" />
        <Metric label="特殊 ID" value={stats ? `${stats.pad_id}/${stats.unk_id}/${stats.bos_id}/${stats.eos_id}` : '-'} accent="var(--accent)" small />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="训练新词表" className="space-y-5">
          <Slider label="词表大小" value={size} onChange={setSize} min={1000} max={32000} step={1000} />
          <Select label="算法" value={type} onChange={setType} options={[
            { value: 'bpe', label: 'BPE（字节对编码）' },
            { value: 'unigram', label: 'Unigram（一元语言模型）' },
          ]} />
          <Btn variant="primary" icon={Hammer} onClick={build} disabled={b?.running}>
            {b?.running ? '构建中…' : '开始真实构建'}
          </Btn>
          {msg && <div className="text-[11px] mono text-[var(--text-tertiary)]">{msg}</div>}
          {b && b.message !== 'idle' && (
            <div className="panel p-3 text-[11px] mono space-y-1">
              <div>status: <b style={{ color: b.running ? 'var(--warning)' : 'var(--success)' }}>{b.message}</b></div>
              {b.result && (
                <>
                  <div className="break-all">path: {b.result.model_path}</div>
                  <div>pieces: <b className="text-[var(--text-primary)]">{b.result.vocab_size}</b></div>
                </>
              )}
            </div>
          )}
          <div className="panel p-3 text-[11px] leading-relaxed text-[var(--text-tertiary)]" style={{ background: 'rgba(245,158,11,0.06)', borderColor: 'rgba(245,158,11,0.18)' }}>
            新词表基于项目真实语料训练，不会替换线上 32200 词表，可安全实验。
          </div>
        </Card>

        <Card title="当前词表采样" className="lg:col-span-2">
          <div className="flex flex-wrap gap-1.5">
            {(stats?.sample_tokens || []).map((t, i) => (
              <span key={i} className="mono text-[11px] px-2 py-1 rounded"
                style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: i < 4 ? 'var(--text-primary)' : 'var(--text-secondary)' }}>
                {t === ' ' ? '␣' : t}
              </span>
            ))}
          </div>
          {b?.result?.sample_tokens && (
            <>
              <div className="label mt-5">新构建词表采样（前 40 pieces）</div>
              <div className="flex flex-wrap gap-1.5">
                {b.result.sample_tokens.map((t, i) => (
                  <span key={i} className="mono text-[11px] px-2 py-1 rounded"
                    style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-secondary)' }}>
                    {t}
                  </span>
                ))}
              </div>
            </>
          )}
        </Card>
      </div>
    </Page>
  );
}
