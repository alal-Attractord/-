import React, { useEffect, useState } from 'react';
import { Wrench, RefreshCw, Send, Terminal, ShieldCheck } from 'lucide-react';
import { Page, Card, Btn, Badge, Empty } from '../components/ui';
import { api } from '../api';

function ToolCard({ tool, selected, onClick }) {
  const schema = tool.inputSchema || {};
  const props = schema.properties || {};
  const required = new Set(schema.required || []);
  return (
    <div
      onClick={onClick}
      className={`panel p-3 cursor-pointer transition-all ${selected ? 'ring-1 ring-[var(--accent)]' : ''}`}
    >
      <div className="flex items-center justify-between mb-1.5">
        <span className="mono text-[12px] font-semibold text-[var(--text-primary)]">{tool.name}</span>
        {selected && <Badge color="var(--accent)">SELECTED</Badge>}
      </div>
      <div className="text-[10.5px] text-[var(--text-secondary)] leading-relaxed mb-2">{tool.description}</div>
      <div className="flex flex-wrap gap-1">
        {Object.entries(props).map(([k, v]) => (
          <span key={k} className="mono text-[9px] px-1.5 py-0.5 rounded"
            style={{ background: 'var(--bg-input)', border: '1px solid var(--glass-border)', color: required.has(k) ? 'var(--text-primary)' : 'var(--text-tertiary)' }}>
            {k}: {v.type}{required.has(k) ? '*' : ''}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function MCPPage() {
  const [tools, setTools] = useState([]);
  const [selected, setSelected] = useState(null);
  const [args, setArgs] = useState('{}');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(false);

  const loadTools = async () => {
    setLoading(true);
    try {
      const r = await api.mcpTools();
      setTools(r.tools || []);
      setError('');
    } catch (e) {
      setError(`MCP 不可用: ${e.message}`);
      setTools([]);
    }
    setLoading(false);
  };

  useEffect(() => { loadTools(); }, []);

  const selectTool = (tool) => {
    setSelected(tool);
    const schema = tool.inputSchema || {};
    const props = schema.properties || {};
    const required = schema.required || [];
    const defaults = {};
    Object.entries(props).forEach(([k, v]) => {
      if (required.includes(k)) {
        if (v.type === 'string') defaults[k] = '';
        else if (v.type === 'number') defaults[k] = 0;
        else if (v.type === 'integer') defaults[k] = 0;
        else if (v.type === 'boolean') defaults[k] = false;
        else if (v.type === 'array') defaults[k] = [];
        else if (v.type === 'object') defaults[k] = {};
      }
    });
    setArgs(JSON.stringify(defaults, null, 2));
    setResult(null);
  };

  const call = async () => {
    if (!selected) return;
    setBusy(true);
    setError('');
    setResult(null);
    try {
      let parsed = {};
      try { parsed = JSON.parse(args); } catch { throw new Error('参数 JSON 格式错误'); }
      const r = await api.mcpCall({ name: selected.name, arguments: parsed });
      setResult(r.result);
    } catch (e) { setError(`调用失败: ${e.message}`); }
    setBusy(false);
  };

  const formatResult = (res) => {
    if (res === undefined || res === null) return 'null';
    if (typeof res === 'string') return res;
    if (Array.isArray(res)) return res.map((item, i) => {
      if (item.type === 'text') return item.text;
      return JSON.stringify(item, null, 2);
    }).join('\n---\n');
    return JSON.stringify(res, null, 2);
  };

  return (
    <Page title="MCP 工具" sub="白名单工具列表 · 系统/网络/爬虫工具实时调用"
      actions={<Btn icon={RefreshCw} onClick={loadTools} disabled={loading}>刷新工具</Btn>}>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title={`可用工具 (${tools.length})`} className="lg:col-span-1">
          {loading && tools.length === 0 && <Empty icon={Wrench} text="加载 MCP 工具…" />}
          {!loading && tools.length === 0 && (
            <div className="space-y-2">
              <Empty icon={ShieldCheck} text="暂无可用工具" />
              {error && <div className="text-[11px] text-[var(--danger)] mono text-center">{error}</div>}
            </div>
          )}
          <div className="space-y-2 max-h-[540px] overflow-y-auto pr-1">
            {tools.map((t) => (
              <ToolCard key={t.name} tool={t} selected={selected?.name === t.name} onClick={() => selectTool(t)} />
            ))}
          </div>
        </Card>

        <Card title={selected ? `调用: ${selected.name}` : '调用面板'} className="lg:col-span-2">
          {!selected ? (
            <Empty icon={Terminal} text="从左侧选择一个工具进行调用" />
          ) : (
            <div className="space-y-4">
              <div className="text-[11px] text-[var(--text-secondary)]">{selected.description}</div>
              <div>
                <div className="label">参数 (JSON)</div>
                <textarea
                  className="input mono w-full text-[11px] leading-relaxed"
                  rows={8}
                  value={args}
                  onChange={(e) => setArgs(e.target.value)}
                />
              </div>
              <Btn variant="primary" icon={Send} onClick={call} disabled={busy}>
                {busy ? '调用中…' : '执行工具'}
              </Btn>

              {error && (
                <div className="panel p-3 text-[11px] mono text-[var(--danger)]" style={{ background: 'rgba(248,113,113,0.06)', borderColor: 'rgba(248,113,113,0.18)' }}>
                  {error}
                </div>
              )}

              {result !== null && (
                <div>
                  <div className="label">调用结果</div>
                  <pre className="mono text-[11px] leading-relaxed rounded-md p-4 overflow-auto max-h-[320px]"
                    style={{ background: 'var(--bg-input)', border: '1px solid var(--glass-border)', color: 'var(--text-secondary)' }}>
                    {formatResult(result)}
                  </pre>
                </div>
              )}
            </div>
          )}
        </Card>
      </div>
    </Page>
  );
}
