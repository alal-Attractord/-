import React, { Suspense, lazy, useEffect, useState } from 'react';
import {
  Database, Plus, Search, Trash2, Zap, RefreshCw, BrainCircuit,
  Save, Upload, Sparkles, Activity, Layers,
} from 'lucide-react';
import { Page, Card, Btn, Badge, Metric, Input } from '../components/ui';
import { api } from '../api';


const ChaosScene = lazy(() => import('../components/ChaosScene'));

function ResultItem({ r, i }) {
  const pct = Math.min(100, r.score * 100);
  return (
    <div className="panel p-4 group" style={{ borderRadius: 'var(--radius-md)' }}>
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <span className="badge mono" style={{ color: 'var(--accent)', borderColor: 'rgba(139,142,240,0.25)', background: 'rgba(139,142,240,0.09)' }}>
            #{r.index}
          </span>
          <span className="text-[11px] text-[var(--text-tertiary)] mono">rank {i + 1}</span>
        </div>
        <span className="text-[13px] font-semibold mono text-[var(--accent)]">{r.score.toFixed(3)}</span>
      </div>
      <p className="text-[13px] text-[var(--text-secondary)] leading-relaxed line-clamp-3">{r.text}</p>
      <div className="mt-3 h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${pct}%`,
            background: 'linear-gradient(90deg, var(--accent-deep), var(--accent-hover), var(--cyan))',
            boxShadow: '0 0 12px rgba(139,142,240,0.4)',
          }}
        />
      </div>
    </div>
  );
}

function BankItem({ b, onLoad }) {
  return (
    <div className="panel p-4 flex items-center justify-between gap-3">
      <div className="min-w-0">
        <div className="text-[13px] font-medium text-[var(--text-primary)] truncate mono">{b.name}</div>
        <div className="text-[10.5px] text-[var(--text-tertiary)] mono mt-1">
          {b.error ? b.error : `${b.mem_count} memories · dim ${b.memory_dim} · ${(b.size_bytes / 1024).toFixed(0)} KB`}
        </div>
      </div>
      <Btn icon={Upload} onClick={() => onLoad(b.name)} disabled={!!b.error}>载入</Btn>
    </div>
  );
}

export default function MemoryPage() {
  const [stats, setStats] = useState(null);
  const [dim, setDim] = useState(384);
  const [capacity, setCapacity] = useState(0.6);
  const [maxMem, setMaxMem] = useState(4096);
  const [text, setText] = useState('');
  const [bulkJson, setBulkJson] = useState('');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [msg, setMsg] = useState('');
  const [confirmReset, setConfirmReset] = useState(false);
  const [bankName, setBankName] = useState('my_chaos_db');
  const [banks, setBanks] = useState([]);

  const refresh = async () => {
    try { setStats(await api.memoryStats()); } catch { setStats(null); }
    try { const r = await api.memoryBanks(); setBanks(r.banks || []); } catch {  }
  };

  useEffect(() => { refresh(); }, []);

  const create = async () => {
    try {
      const r = await api.memoryCreate({ memory_dim: dim, capacity, max_memories: maxMem });
      setMsg(`created · ${r.memory_dim}d / ${r.max_memories} cells`);
      refresh();
    } catch (e) { setMsg(e.message); }
  };

  const write = async () => {
    if (!text.trim()) return;
    try {
      const r = await api.memoryWrite({ text });
      setMsg(`written #${r.index}`);
      setText('');
      refresh();
    } catch (e) { setMsg(e.message); }
  };

  const writeBulk = async () => {
    try {
      const items = JSON.parse(bulkJson);
      const r = await api.memoryWriteBulk({ items });
      setMsg(`bulk written ${r.count} items`);
      setBulkJson('');
      refresh();
    } catch (e) { setMsg(`bulk error: ${e.message}`); }
  };

  const retrieve = async () => {
    if (!query.trim()) return;
    try {
      const r = await api.memoryRetrieveText({ text: query, top_k: 5 });
      setResults(r.results);
    } catch (e) { setMsg(e.message); }
  };

  const decay = async () => {
    try { await api.memoryDecay({ steps: 1 }); setMsg('decayed'); refresh(); } catch (e) { setMsg(e.message); }
  };

  const consolidate = async () => {
    try { await api.memoryConsolidate({ steps: 5 }); setMsg('consolidated'); refresh(); } catch (e) { setMsg(e.message); }
  };

  const reset = async () => {
    if (!confirmReset) { setConfirmReset(true); return; }
    try { await api.memoryReset(); setMsg('reset'); setResults(null); refresh(); setConfirmReset(false); } catch (e) { setMsg(e.message); }
  };

  const saveBank = async () => {
    try {
      const r = await api.memorySave({ name: bankName.trim() || 'my_chaos_db' });
      setMsg(`saved · ${r.name} · ${(r.size_bytes / 1024 / 1024).toFixed(1)} MB`);
      refresh();
    } catch (e) { setMsg(e.message); }
  };

  const loadBank = async (name) => {
    try {
      const r = await api.memoryLoad({ name });
      setMsg(`loaded · ${r.name} · ${r.mem_count} memories`);
      refresh();
    } catch (e) { setMsg(e.message); }
  };

  const exists = stats && stats.status !== 'not_created';
  const capPct = stats ? Math.round((stats.capacity_used ?? 0) * 100) : 0;

  return (
    <Page
      title="混沌记忆库"
      sub="零训练向量记忆 · StarLightEmbedder 384-dim · 真实写入 / 检索 / 持久化"
      actions={
        <div className="flex items-center gap-2">
          {msg && (
            <span className="text-[11px] text-[var(--text-tertiary)] mono max-w-[220px] truncate hidden sm:inline">
              {msg}
            </span>
          )}
          <Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>
        </div>
      }
    >
      {}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-5">
        <div className="panel relative overflow-hidden lg:col-span-1" style={{ height: 240, borderRadius: 'var(--radius-xl)' }}>
          <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
            <Badge color={exists ? 'var(--success)' : 'var(--danger)'} pulse={exists}>
              {exists ? '记忆场在线' : '未创建'}
            </Badge>
            <span className="text-[10px] text-[var(--text-tertiary)] mono hidden sm:inline">混沌雨幕记忆轨迹</span>
          </div>
          <Suspense fallback={
            <div className="absolute inset-0 flex items-center justify-center text-[11px] mono text-[var(--text-tertiary)]">
              初始化 3D 记忆核心…
            </div>
          }>
            <ChaosScene energy={1.2 + (stats?.mean_energy ?? 0) * 2} />
          </Suspense>
          <div className="scene-veil" />
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Metric label="维度" value={stats?.memory_dim ?? dim} accent="var(--violet)" icon={Layers} />
          <Metric label="已存记忆" value={stats?.stored_texts ?? 0} accent="var(--accent)" icon={BrainCircuit} />
          <Metric label="总能量" value={stats?.mean_energy ? stats.mean_energy.toFixed(3) : '0.000'} accent="var(--cyan)" icon={Activity} />
          <Metric label="容量" value={stats ? `${capPct}%` : '-'} accent="var(--pink)" icon={Database} />
        </div>
      </div>

      {}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {}
        <div className="lg:col-span-5 space-y-5">
          <Card title="创建记忆场" actions={exists ? <Badge color="var(--success)">online</Badge> : null}>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <Input label="维度" value={dim} onChange={(v) => setDim(parseInt(v) || 384)} mono />
              <Input label="容量" value={capacity} onChange={(v) => setCapacity(parseFloat(v) || 0.6)} mono />
              <Input label="最大条数" value={maxMem} onChange={(v) => setMaxMem(parseInt(v) || 4096)} mono />
            </div>
            <Btn variant="primary" icon={Sparkles} onClick={create}>创建记忆场</Btn>
          </Card>

          <Card title="写入记忆">
            <Input label="文本" value={text} onChange={setText} placeholder="输入要记忆的内容…" />
            <div className="flex gap-2 mt-4">
              <Btn variant="primary" icon={Plus} onClick={write} disabled={!exists}>写入单条</Btn>
            </div>
          </Card>

          <Card title="批量写入（JSON）">
            <textarea
              className="input mono" rows={3}
              value={bulkJson} onChange={(e) => setBulkJson(e.target.value)}
              placeholder='[{"text":"Python programming"},{"text":"Chaos theory"}]'
            />
            <div className="flex gap-2 mt-4">
              <Btn icon={Plus} onClick={writeBulk} disabled={!exists}>批量写入</Btn>
            </div>
          </Card>

          <Card title="危险操作">
            <div className="flex flex-wrap gap-2">
              <Btn icon={Zap} onClick={decay} disabled={!exists}>衰减</Btn>
              <Btn icon={RefreshCw} onClick={consolidate} disabled={!exists}>巩固</Btn>
              <Btn variant="danger" icon={Trash2} onClick={reset} disabled={!exists}>
                {confirmReset ? '确认清空？' : '清空'}
              </Btn>
            </div>
          </Card>
        </div>

        {}
        <div className="lg:col-span-7 space-y-5">
          <Card title="检索记忆">
            <Input label="查询文本" value={query} onChange={setQuery} placeholder="输入查询…" />
            <div className="flex gap-2 mt-4">
              <Btn variant="primary" icon={Search} onClick={retrieve} disabled={!exists}>检索</Btn>
            </div>
          </Card>

          <Card
            title="检索结果"
            actions={results !== null ? (
              <Badge color="var(--accent)">{results.length} 条</Badge>
            ) : (
              <Badge color="var(--text-tertiary)">waiting</Badge>
            )}
          >
            {results === null ? (
              <div className="text-[11px] text-[var(--text-tertiary)]">输入查询后点击检索</div>
            ) : results.length === 0 ? (
              <div className="text-[11px] text-[var(--text-tertiary)]">无匹配记忆</div>
            ) : (
              <div className="space-y-3">
                {results.map((r, i) => <ResultItem key={r.index} r={r} i={i} />)}
              </div>
            )}
          </Card>

          <Card title="持久化 · 快照">
            <div className="flex items-end gap-2 mb-4">
              <div className="flex-1">
                <Input label="快照名称" value={bankName} onChange={setBankName} placeholder="my_chaos_db" mono />
              </div>
              <Btn variant="primary" icon={Save} onClick={saveBank} disabled={!exists}>保存</Btn>
            </div>
            {banks.length > 0 && (
              <div className="space-y-3">
                {banks.map((b) => <BankItem key={b.name} b={b} onLoad={loadBank} />)}
              </div>
            )}
          </Card>
        </div>
      </div>

      {}
      <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="panel p-4">
          <div className="text-[12px] font-semibold text-[var(--text-primary)] mb-1.5">写入</div>
          <div className="text-[11px] leading-relaxed text-[var(--text-tertiary)]">
            StarLightEmbedder 生成 384 维语义向量，投影进混沌记忆池。
          </div>
        </div>
        <div className="panel p-4">
          <div className="text-[12px] font-semibold text-[var(--text-primary)] mb-1.5">检索</div>
          <div className="text-[11px] leading-relaxed text-[var(--text-tertiary)]">
            余弦相似度 + 混沌共振加权，返回 top-k 及相关能量分数。
          </div>
        </div>
        <div className="panel p-4">
          <div className="text-[12px] font-semibold text-[var(--text-primary)] mb-1.5">Agent 集成</div>
          <div className="text-[11px] leading-relaxed text-[var(--text-tertiary)]">
            当 Agent 置信度不足时，自动调用检索注入上下文记忆。
          </div>
        </div>
      </div>
    </Page>
  );
}
