import React, { useEffect, useState } from 'react';
import { ShieldCheck, KeyRound, RefreshCw, Eye } from 'lucide-react';
import { Page, Card, Btn, Badge, Metric } from '../components/ui';
import { api } from '../api';

export default function SecurityPage() {
  const [sec, setSec] = useState(null);

  const refresh = async () => {
    try { setSec(await api.securityStatus()); } catch {  }
  };

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 5000);
    return () => clearInterval(t);
  }, []);

  const cfg = sec?.config || {};

  return (
    <Page title="安全中心" sub="SecurityManager 实时状态 · Fernet + RSA-2048 + IDS/ADS"
      actions={<Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Metric label="Active Tokens" value={sec?.active_tokens ?? '-'} accent="var(--accent)" icon={KeyRound} />
        <Metric label="Sessions" value={sec?.sessions ?? '-'} accent="var(--accent)" icon={Eye} />
        <Metric label="Key Rotations" value={sec?.key_rotation_count ?? 0} accent="var(--accent)" icon={RefreshCw} />
        <Metric label="Anomalies" value={sec?.anomaly?.chaos_nn_anomaly_count ?? 0} accent={sec?.anomaly?.chaos_nn_anomaly_count > 0 ? 'var(--danger)' : 'var(--success)'} icon={ShieldCheck} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="角色权限矩阵">
          <table className="tbl">
            <thead><tr><th>角色</th><th>权限</th></tr></thead>
            <tbody>
              {Object.entries(sec?.roles || {}).map(([role, perms]) => (
                <tr key={role}>
                  <td className="mono font-semibold text-[var(--text-primary)]">{role}</td>
                  <td>
                    <div className="flex flex-wrap gap-1">
                      {perms.map((p) => (
                        <span key={p} className="mono text-[9.5px] px-1.5 py-0.5 rounded"
                          style={{ background: 'var(--bg-input)', color: 'var(--text-secondary)', border: '1px solid var(--border)' }}>
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card title="防御配置（实时）">
          <div className="space-y-1">
            {Object.entries(cfg).map(([k, v]) => (
              <div key={k} className="flex items-center justify-between py-1.5 px-2.5 rounded hover:bg-[rgba(148,163,184,0.04)]">
                <span className="text-[11.5px] mono text-[var(--text-secondary)]">{k}</span>
                {typeof v === 'boolean'
                  ? <Badge color={v ? 'var(--success)' : 'var(--danger)'}>{v ? 'ON' : 'OFF'}</Badge>
                  : <span className="mono text-[11px] font-semibold text-[var(--text-primary)]">{String(v)}</span>}
              </div>
            ))}
          </div>
        </Card>

        <Card title="安全事件日志">
          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {(sec?.security_log_tail || []).length === 0 && (
              <div className="text-[11px] text-[var(--text-tertiary)]">暂无安全事件 — 系统运行正常</div>
            )}
            {(sec?.security_log_tail || []).slice().reverse().map((e, i) => (
              <div key={i} className="panel p-2.5 text-[10.5px] mono">
                <div className="flex justify-between mb-1">
                  <b className="text-[var(--warning)]">{e.event_type || e.type || 'EVENT'}</b>
                  <span className="text-[var(--text-tertiary)]">{String(e.timestamp || '').slice(11, 19)}</span>
                </div>
                <div className="text-[var(--text-secondary)]">user: {e.user_id || '-'}</div>
                {e.details && <div className="truncate text-[var(--text-tertiary)]">{e.details}</div>}
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-[var(--border)] text-[10.5px] mono space-y-1 text-[var(--text-tertiary)]">
            <div>加密: <b className="text-[var(--success)]">{sec?.encryption?.symmetric}</b> / <b className="text-[var(--success)]">{sec?.encryption?.asymmetric}</b></div>
            <div>IP 白名单: <b className="text-[var(--text-primary)]">{(sec?.ip_whitelist || []).join(', ')}</b></div>
            <div>审计日志总数: <b className="text-[var(--text-primary)]">{sec?.audit_log_count ?? 0}</b></div>
            <div>最近密钥轮换: <b className="text-[var(--text-primary)]">{sec?.last_key_rotation ?? '-'}</b></div>
          </div>
        </Card>
      </div>
    </Page>
  );
}
