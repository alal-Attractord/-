import React, { useEffect, useState } from 'react';
import { Boxes, RefreshCw, Cpu, Download } from 'lucide-react';
import { Page, Card, Btn, Metric, Badge } from '../components/ui';
import { api } from '../api';

export default function ModelsPage() {
  const [info, setInfo] = useState(null);
  const [exporting, setExporting] = useState(null);
  const [exportMsg, setExportMsg] = useState('');

  const refresh = async () => {
    try { setInfo(await api.modelInfo()); } catch {  }
  };
  useEffect(() => { refresh(); }, []);

  const exportOnnx = async (model) => {
    setExporting(model);
    setExportMsg('');
    try {
      const res = await api.exportOnnx({ model });
      const mb = (res.size_bytes / 1024 / 1024).toFixed(2);
      setExportMsg(`${model === 'starlight' ? 'StarLight' : 'ChaosNN'} ONNX 导出成功: ${mb} MB`);
    } catch (e) {
      setExportMsg(`导出失败: ${e.message}`);
    } finally {
      setExporting(null);
    }
  };

  const cfg = info?.config_dict || {};

  return (
    <Page title="模型核心" sub="StarLight 双数种子混沌 Transformer + ChaosNN 架构实况"
      actions={
        <>
          <Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>
          <Btn icon={Download} onClick={() => exportOnnx('starlight')} disabled={exporting === 'starlight'}>
            导出 StarLight ONNX
          </Btn>
          <Btn icon={Download} variant="secondary" onClick={() => exportOnnx('chaos')} disabled={exporting === 'chaos'}>
            导出 ChaosNN ONNX
          </Btn>
        </>
      }>
      {exportMsg && (
        <div className={`mb-4 text-[12px] px-3 py-2 rounded border ${exportMsg.includes('失败') ? 'border-red-500/30 bg-red-500/10 text-red-300' : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'}`}>
          {exportMsg}
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Metric label="StarLight 参数" value={info?.params_m ?? '-'} unit="M" accent="var(--accent)" icon={Boxes} />
        <Metric label="Layers × Heads" value={info ? `${cfg.num_layers} × ${cfg.num_heads}` : '-'} accent="var(--accent)" />
        <Metric label="Hidden / FFN" value={info ? `${cfg.hidden_dim} / ${cfg.ffn_dim}` : '-'} accent="var(--accent)" small />
        <Metric label="Target λ" value={cfg.target_lyap ?? '-'} accent="var(--accent)" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="StarLight 配置（实时读取）" className="lg:col-span-2">
          <pre className="mono text-[11px] leading-[1.75] rounded-md p-4 overflow-auto max-h-[380px]"
            style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: '#93c5fd' }}>
            {info ? JSON.stringify(cfg, null, 2) : '// 加载中…'}
          </pre>
        </Card>

        <div className="space-y-4">
          <Card title="ChaosNN 子网">
            <div className="space-y-1">
              {[
                ['拓扑', info ? `${info.chaos_nn.input} → ${info.chaos_nn.hidden} → ${info.chaos_nn.output}` : '-'],
                ['参数量', info ? info.chaos_nn.params.toLocaleString() : '-'],
                ['已处理样本', info?.chaos_nn.samples_processed ?? 0],
                ['异常输入拦截', info?.chaos_nn.anomaly_count ?? 0],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between py-2 px-2.5 rounded hover:bg-[rgba(148,163,184,0.04)]">
                  <span className="text-[11.5px] text-[var(--text-tertiary)]">{k}</span>
                  <span className="mono text-[12px] font-semibold text-[var(--text-primary)]">{v}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card title="正则与锚点">
            <div className="space-y-1">
              <div className="flex justify-between items-center py-1.5 px-2.5">
                <span className="text-[12px] text-[var(--text-secondary)]">Lyapunov 正则</span>
                <Badge color={cfg.use_lyap_reg ? 'var(--success)' : 'var(--danger)'}>{cfg.use_lyap_reg ? 'ENABLED' : 'OFF'}</Badge>
              </div>
              <div className="flex justify-between items-center py-1.5 px-2.5">
                <span className="text-[12px] text-[var(--text-secondary)]">秩保护锚点</span>
                <Badge color={cfg.use_rank_anchor ? 'var(--success)' : 'var(--danger)'}>{cfg.use_rank_anchor ? 'ENABLED' : 'OFF'}</Badge>
              </div>
              <div className="flex justify-between items-center py-1.5 px-2.5">
                <span className="text-[12px] text-[var(--text-secondary)]">种子初始化</span>
                <span className="mono text-[11px] text-[var(--text-primary)]">{cfg.seed_init_mode || '-'}</span>
              </div>
            </div>
          </Card>

          <Card title="检查点">
            <div className="mono text-[10.5px] break-all leading-relaxed text-[var(--text-tertiary)]">
              {info?.checkpoint || 'none'}
              <div className="mt-2">累计训练步数: <b className="text-[var(--text-primary)]">{info?.train_steps_total ?? 0}</b></div>
              <div className="mt-1 flex items-center gap-1.5">
                <Cpu size={11} className="text-[var(--accent)]" />
                <span className="text-[var(--text-primary)]">{info?.device}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </Page>
  );
}
