import React, { useRef, useState } from 'react';
import { Send, Square, Trash2, Copy } from 'lucide-react';
import { Page, Card, Btn, Slider, LineChart, Badge, Select, IntensitySlider } from '../components/ui';
import { streamPost } from '../api';

export default function InferencePage() {
  const [prompt, setPrompt] = useState('混沌神经网络的核心优势在于');
  const [maxTokens, setMaxTokens] = useState(64);
  const [temp, setTemp] = useState(0.8);
  const [topK, setTopK] = useState(50);
  const [topP, setTopP] = useState(0.9);
  const [model, setModel] = useState('starlight');
  const [intensity, setIntensity] = useState('standard');
  const [out, setOut] = useState('');
  const [temps, setTemps] = useState([]);
  const [cands, setCands] = useState([]);
  const [stats, setStats] = useState(null);
  const [usedModel, setUsedModel] = useState(null);
  const [busy, setBusy] = useState(false);
  const abortRef = useRef(null);

  const run = async () => {
    if (!prompt.trim() || busy) return;
    setBusy(true); setOut(''); setTemps([]); setCands([]); setStats(null); setUsedModel(null);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    const t0 = performance.now();
    let nTok = 0;
    try {
      await streamPost('/generate/stream',
        { text: prompt, max_tokens: maxTokens, temperature: temp, top_k: topK, top_p: topP, model, intensity },
        (ev) => {
          if (ev.type === 'token') {
            nTok += 1;
            setOut((o) => o + (ev.delta || ''));
            setTemps((t) => [...t, ev.adaptive_temp].slice(-128));
            if (ev.candidates && nTok === 1) setCands(ev.candidates);
          } else if (ev.type === 'done') {
            setOut(ev.result ?? '');
            setUsedModel(ev.model);
            setStats({ tokens: ev.tokens, ms: Math.round(performance.now() - t0) });
          } else if (ev.type === 'error') {
            setOut((o) => o + `\n⚠ ${ev.error}`);
          }
        }, ctrl.signal);
    } catch (e) {
      if (e.name !== 'AbortError') setOut((o) => o + `\n⚠ 连接失败: ${e.message}`);
    }
    setBusy(false);
  };

  return (
    <Page title="推理生成" sub="StarLight 种子引导采样 · 逐 token 真实流式输出">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="采样参数" className="space-y-5">
          <Select label="挂载模型" value={model} onChange={setModel} options={[
            { value: 'starlight', label: 'StarLight LM（36.93M 双数种子 Transformer）' },
            { value: 'chaos', label: 'ChaosNN（Lorenz 轨迹预测）' },
            { value: 'full', label: 'Full AGI（StarLight + ChaosNN 融合）' },
            { value: 'chaos_wm_v2', label: '混沌世界模型 v2（感知+双读出内核+MPC决策+记忆链）' },
            { value: 'chaos_llm', label: '纯混沌 LLM（74 QA 精确记忆 + HC3 语义库）' },
            { value: 'chaos_world', label: '世界模型 v1（引擎核 + 中文判断说话）' },
          ]} />

          <div>
            <div className="label mb-2.5">思考强度</div>
            <IntensitySlider value={intensity} onChange={setIntensity} />
          </div>

          <Slider label="Max Tokens" value={maxTokens} onChange={setMaxTokens} min={8} max={256} step={8} />
          <Slider label="Temperature" value={temp} onChange={setTemp} min={0.1} max={1.6} step={0.05} format={(v) => v.toFixed(2)} />
          <Slider label="Top-K" value={topK} onChange={setTopK} min={1} max={200} step={1} />
          <Slider label="Top-P" value={topP} onChange={setTopP} min={0.1} max={1.0} step={0.05} format={(v) => v.toFixed(2)} />
          <div className="flex gap-2 pt-1">
            {busy
              ? <Btn variant="danger" icon={Square} onClick={() => abortRef.current?.abort()}>停止</Btn>
              : <Btn variant="primary" icon={Send} onClick={run}>流式生成</Btn>}
            <Btn icon={Trash2} onClick={() => { setOut(''); setTemps([]); setCands([]); setStats(null); }}>清空</Btn>
          </div>
          {stats && (
            <div className="grid grid-cols-2 gap-2 pt-2">
              <div className="panel p-2.5 text-center">
                <div className="text-[10px] uppercase text-[var(--text-tertiary)]">tokens</div>
                <div className="text-base font-semibold mono text-[var(--text-primary)]">{stats.tokens}</div>
              </div>
              <div className="panel p-2.5 text-center">
                <div className="text-[10px] uppercase text-[var(--text-tertiary)]">耗时</div>
                <div className="text-base font-semibold mono text-[var(--text-primary)]">{stats.ms}ms</div>
              </div>
            </div>
          )}
          <div>
            <div className="label">自适应温度（实时）</div>
            <LineChart data={temps} color="#f472b6" height={90} label="seed-guided temp" />
          </div>
          {cands.length > 0 && (
            <div>
              <div className="label">首步候选 Top-5</div>
              <div className="flex flex-wrap gap-1.5">
                {cands.map((c, i) => {
                  const tk = (c.token || '').replace(/\s/g, '␣').trim();
                  const display = tk === '' || tk === '␣' ? '∅' : tk;
                  return (
                    <span key={i} className="mono text-[10px] px-2 py-1 rounded"
                      style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: display === '∅' ? 'var(--text-tertiary)' : 'var(--text-secondary)' }}>
                      {display} <span className="text-[var(--text-tertiary)]">{(c.prob * 100).toFixed(1)}%</span>
                    </span>
                  );
                })}
              </div>
            </div>
          )}
        </Card>

        <Card title="生成输出" className="lg:col-span-2 flex flex-col"
          actions={stats && <Badge color="var(--success)">{(stats.tokens / (stats.ms / 1000)).toFixed(1)} tok/s</Badge>}>
          {usedModel && (
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] px-1.5 py-0.5 rounded mono uppercase"
                style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid var(--glass-border)', color: 'var(--text-tertiary)' }}>
                {usedModel}
              </span>
            </div>
          )}
          <textarea
            className="input mb-3" rows={3}
            value={prompt} onChange={(e) => setPrompt(e.target.value)}
            placeholder="输入提示词…"
          />
          <div className="flex-1 rounded-md p-4 text-[14px] leading-[1.8] whitespace-pre-wrap overflow-y-auto mono"
            style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', minHeight: 300, color: 'var(--text-primary)' }}>
            {out
              ? <>{out}{busy && <span className="inline-block w-1.5 h-3.5 ml-1 align-middle bg-[var(--accent)] rounded-sm animate-pulse" />}</>
              : <span className="text-[var(--text-tertiary)]">
          </div>
          <div className="flex gap-2 mt-3">
            <Btn icon={Copy} onClick={() => navigator.clipboard.writeText(out)}>复制</Btn>
          </div>
        </Card>
      </div>
    </Page>
  );
}
