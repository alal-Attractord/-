import React, { useEffect, useMemo, useState } from 'react';
import { Atom, Activity, Gauge, Sigma, TrendingUp, AlertTriangle, CheckCircle2, XCircle, Play } from 'lucide-react';
import { api } from '../api';
import { Page, Card, Metric, Badge, Btn, KV, Empty, Input } from '../components/ui';


function SpectrumPlot({ spectrum, size = 260 }) {
  const pts = spectrum?.top5 || [];
  if (!spectrum) {
    return <Empty icon={Sigma} text="运行一次推演以获取谱" />;
  }
  const R = 1.45;                      
  const cx = size / 2, cy = size / 2;
  const sx = (re) => cx + (re / R) * (size / 2 - 14);
  const sy = (im) => cy - (im / R) * (size / 2 - 14);
  const circleR = (1 / R) * (size / 2 - 14);

  return (
    <div className="flex items-center gap-4">
      <svg width={size} height={size} className="shrink-0">
        <line x1={10} y1={cy} x2={size - 10} y2={cy} stroke="rgba(167,139,250,0.18)" strokeWidth="1" />
        <line x1={cx} y1={10} x2={cx} y2={size - 10} stroke="rgba(167,139,250,0.18)" strokeWidth="1" />
        <circle cx={cx} cy={cy} r={circleR} fill="none" stroke="rgba(167,139,250,0.45)"
          strokeWidth="1" strokeDasharray="4 3" />
        <text x={cx + circleR + 3} y={cy - 4} fill="var(--text-tertiary)" fontSize="9"
          fontFamily="var(--font-mono)">|λ|=1</text>
        {pts.map((p, i) => {
          const x = sx(p.real), y = sy(p.imag);
          const near = Math.abs(p.abs - 1) < 0.02;
          return (
            <g key={i}>
              <circle cx={x} cy={y} r={i === 0 ? 5 : 3.6}
                fill={near ? 'var(--accent-hover)' : 'rgba(34,211,238,0.85)'}
                stroke="rgba(255,255,255,0.35)" strokeWidth="0.6" />
              {p.imag < 0 && <circle cx={x} cy={sy(-p.imag)} r={i === 0 ? 5 : 3.6}
                fill={near ? 'var(--accent-hover)' : 'rgba(34,211,238,0.85)'}
                stroke="rgba(255,255,255,0.35)" strokeWidth="0.6" />}
            </g>
          );
        })}
      </svg>
      <div className="flex-1 min-w-0 space-y-2">
        <KV k="谱半径 ρ" v={spectrum.rho?.toFixed(6)} />
        <KV k="单位圆距离" v={spectrum.unit_dist?.toFixed(6)} />
        <KV k="复模态占比" v={spectrum.imag_frac?.toFixed(3)} />
        <div className="pt-1.5 border-t border-[rgba(167,139,250,0.1)]">
          <div className="text-[10px] text-[var(--text-tertiary)] leading-relaxed">
            ρ≈1 表示算子接近**保守流**（保范数、不衰减）；复模态占比高表示以**旋转/振荡**模态为主。
          </div>
        </div>
      </div>
    </div>
  );
}


function HorizonBars({ forecast }) {
  if (!forecast) return <Empty icon={TrendingUp} text="暂无预测" />;
  const hs = Object.keys(forecast.horizons).map(Number).sort((a, b) => a - b);
  const series = hs.map((h) => {
    const v = forecast.horizons[String(h)];
    return { h, norm: Math.sqrt(v.reduce((s, x) => s + x * x, 0)) };
  });
  const mx = Math.max(...series.map((s) => s.norm), 1e-9);
  return (
    <div className="flex items-end gap-3 h-[130px]">
      {series.map((s) => (
        <div key={s.h} className="flex-1 flex flex-col items-center gap-1.5">
          <div className="text-[10px] mono text-[var(--text-tertiary)]">{s.norm.toFixed(2)}</div>
          <div className="w-full rounded-t-[4px]"
            style={{
              height: `${Math.max(6, (s.norm / mx) * 84)}px`,
              background: 'linear-gradient(180deg, rgba(167,139,250,0.85), rgba(34,211,238,0.35))',
              boxShadow: '0 0 14px rgba(124,58,237,0.35)',
            }} />
          <div className="text-[10px] mono text-[var(--text-secondary)]">K={s.h}</div>
        </div>
      ))}
    </div>
  );
}


function CapabilityPanel({ cap }) {
  if (!cap) return null;
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
      <div className="space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[var(--success)]">
          <CheckCircle2 size={13} /> 已验证的优势
        </div>
        {cap.verified_wins.map((w, i) => (
          <div key={i} className="p-2.5 rounded-[10px] bg-[rgba(16,185,129,0.07)] border border-[rgba(16,185,129,0.18)]">
            <div className="text-[11px] font-medium text-[var(--text-primary)]">{w.axis}</div>
            <div className="text-[10px] text-[var(--text-tertiary)] mt-0.5">{w.verdict}</div>
          </div>
        ))}
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[var(--danger)]">
          <XCircle size={13} /> 已验证的劣势
        </div>
        {cap.verified_losses.map((w, i) => (
          <div key={i} className="p-2.5 rounded-[10px] bg-[rgba(239,68,68,0.07)] border border-[rgba(239,68,68,0.18)]">
            <div className="text-[11px] font-medium text-[var(--text-primary)]">{w.axis}</div>
            <div className="text-[10px] text-[var(--text-tertiary)] mt-0.5">{w.verdict}</div>
          </div>
        ))}
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[var(--warning, #f59e0b)]">
          <AlertTriangle size={13} /> 不予宣称
        </div>
        <div className="p-2.5 rounded-[10px] bg-[rgba(245,158,11,0.07)] border border-[rgba(245,158,11,0.2)]">
          {cap.not_claimed.map((t, i) => (
            <div key={i} className="text-[11px] text-[var(--text-secondary)] leading-relaxed">· {t}</div>
          ))}
          <div className="text-[10px] text-[var(--text-tertiary)] mt-1.5 leading-relaxed">
            依据：{cap.evidence?.protocol}
          </div>
        </div>
      </div>
    </div>
  );
}


export default function KoopmanPage() {
  const [out, setOut] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const [obs, setObs] = useState('');

  const probe = async (text) => {
    setBusy(true); setErr(null);
    try {
      const r = await api.generate({ text: text ?? (obs ? `obs=${obs}` : ''), model: 'koopman', max_tokens: 48 });
      setOut(r);
    } catch (e) {
      setErr(String(e.message || e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => { probe(''); }, []);

  const wm = out?.wm || {};
  const cap = wm.capability;
  const fc = wm.forecast;
  const sp = wm.spectrum;

  return (
    <Page title="Koopman 主干" sub="自适应线性算子 · 提升空间动力学 · 谱分析">
      <div className="space-y-4">
        {}
        <Card pad>
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[rgba(167,139,250,0.1)] border border-[rgba(167,139,250,0.25)]">
              <Atom size={13} className="text-[var(--accent-hover)]" />
              <span className="text-[11px] font-semibold text-[var(--text-primary)]">动力学演化范式</span>
            </div>
            <span className="text-[11px] mono text-[var(--text-tertiary)]">
              z_{'{'}t+1{'}'} = K(z_{'{'}t{'}'}) · z_{'{'}t{'}'}　—　提升空间内线性演化
            </span>
            <span className="flex-1" />
            <Badge color={out ? 'var(--success)' : 'var(--text-tertiary)'} pulse={!!out}>
              {out ? `${wm.backbone || 'koopman'} 在线` : '未连接'}
            </Badge>
          </div>
        </Card>

        {}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <Metric label="主干" value={wm.backbone || '—'} icon={Atom} small />
          <Metric label="谱半径 ρ" value={sp ? sp.rho.toFixed(4) : '—'} icon={Sigma} />
          <Metric label="复模态占比" value={sp ? (sp.imag_frac * 100).toFixed(1) + '%' : '—'} unit="" icon={Activity}
            accent="var(--accent-hover)" />
          <Metric label="推演耗时" value={out ? out.elapsed_ms : '—'} unit="ms" icon={Gauge} accent="#22d3ee" />
        </div>

        {}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="多视界预测" actions={<span className="text-[10px] text-[var(--text-tertiary)] mono">单次线性递推覆盖全部视界</span>}>
            <HorizonBars forecast={fc} />
          </Card>
          <Card title="谱分析（K 的特征值）">
            <SpectrumPlot spectrum={sp} />
          </Card>
        </div>

        {}
        <Card title="推演控制">
          <div className="flex flex-wrap items-end gap-3">
            <div className="w-[300px]">
              <Input label="观测点（可选，x,y,z）" value={obs} onChange={setObs} placeholder="1.0,2.0,3.0" mono />
            </div>
            <Btn onClick={() => probe()} disabled={busy} icon={Play}>
              {busy ? '推演中…' : '推演'}
            </Btn>
            {err && <span className="text-[11px] text-[var(--danger)]">{err}</span>}
          </div>
          {out?.result && (
            <div className="mt-3 p-3 rounded-[10px] bg-[rgba(167,139,250,0.06)] border border-[rgba(167,139,250,0.14)]">
              <div className="text-[12px] text-[var(--text-primary)] leading-relaxed">{out.result}</div>
              <div className="mt-1.5 text-[10px] text-[var(--text-tertiary)]">
                波动判定「{wm.wave}」／{wm.judge}　·　描述性统计，非风险判别器
              </div>
            </div>
          )}
        </Card>

        {}
        <Card title="能力边界（实测，数据驱动）"
          actions={<span className="text-[10px] text-[var(--text-tertiary)]">证据来自 wm_results_koopman.json</span>}>
          <CapabilityPanel cap={cap} />
        </Card>
      </div>
    </Page>
  );
}
