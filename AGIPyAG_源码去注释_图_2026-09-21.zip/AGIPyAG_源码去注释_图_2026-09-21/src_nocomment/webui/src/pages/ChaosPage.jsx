import React, { Suspense, lazy, useEffect, useRef, useState } from 'react';
import { Atom, RefreshCw } from 'lucide-react';
import { Page, Card, Btn, LineChart, Metric, Badge } from '../components/ui';
import { api } from '../api';


const ChaosScene = lazy(() => import('../components/ChaosScene'));

export default function ChaosPage() {
  const [st, setSt] = useState(null);
  const timer = useRef(null);

  const refresh = async () => {
    try { setSt(await api.chaosState(400)); } catch {  }
  };

  useEffect(() => {
    refresh();
    timer.current = setInterval(refresh, 2500);
    return () => clearInterval(timer.current);
  }, []);

  return (
    <Page title="混沌神经网络" sub="实时拓扑可视化 · ChaosNN 内部态历史"
      actions={<Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <Metric label="Engine Steps" value={st?.engine.step_count ?? 0} accent="var(--accent)" icon={Atom} />
        <Metric label="Magnitude" value={st ? st.engine.chaos_magnitude.toFixed(3) : '-'} accent="var(--cyan)" />
        <Metric label="Thoughts" value={st?.engine.trajectory_length ?? 0} accent="var(--violet)" />
        <Metric label="ρ / σ / β" value={st ? `${st.engine.rho}/${st.engine.sigma}/${st.engine.beta.toFixed(2)}` : '-'} accent="var(--pink)" small />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {}
        <div className="panel relative overflow-hidden lg:col-span-2" style={{ height: 520 }}>
          <Suspense fallback={<div className="absolute inset-0 flex items-center justify-center text-[11px] mono text-[var(--text-tertiary)]">初始化神经网络拓扑…</div>}>
            <ChaosScene energy={st?.engine.chaos_magnitude ?? 1.3} />
          </Suspense>
          <div className="scene-veil" />
          <div className="absolute top-4 left-5 flex items-center gap-2 pointer-events-none">
            <span className="text-[12px] font-semibold uppercase tracking-[0.07em] text-[var(--text-secondary)]">ChaosNN 拓扑</span>
            <Badge color="var(--cyan)" pulse>3D LIVE</Badge>
          </div>
          <div className="absolute bottom-4 right-5 text-[10px] mono text-[var(--text-tertiary)] pointer-events-none">
            自动旋转 · 滚轮缩放 · 拖拽交互 · 脉冲随 magnitude 加速
          </div>
        </div>

        <div className="space-y-5">
          <Card title="γ 混沌核态历史">
            <LineChart data={st?.nn_histories.gamma || []} color="#a78bfa" height={126} label="gamma_t" />
          </Card>
          <Card title="ω 收敛判定">
            <LineChart data={st?.nn_histories.convergence || []} color="#f472b6" height={126} label="omega_t" />
          </Card>
          <Card title="算力自适应分配">
            <LineChart data={st?.nn_histories.compute_power || []} color="#fbbf24" height={126} label="p_t" min={0} />
          </Card>
        </div>
      </div>
    </Page>
  );
}
