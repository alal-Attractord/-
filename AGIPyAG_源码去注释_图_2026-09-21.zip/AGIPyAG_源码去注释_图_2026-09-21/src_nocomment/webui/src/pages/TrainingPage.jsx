import React, { useEffect, useRef, useState } from 'react';
import {
  Play, Square, Dna, FolderOpen, Server, Wifi, Zap, Cpu,
} from 'lucide-react';
import { Page, Card, Btn, Slider, Select, LineChart, Badge, Metric } from '../components/ui';
import { api } from '../api';

export default function TrainingPage() {
  const [model, setModel] = useState('starlight');
  const [steps, setSteps] = useState(500);
  const [batch, setBatch] = useState(4);
  const [lr, setLr] = useState(0.0003);
  const [seqLen, setSeqLen] = useState(64);
  const [computeLevel, setComputeLevel] = useState(5);
  const [useCluster, setUseCluster] = useState(false);
  const [useOnlineData, setUseOnlineData] = useState(false);
  const [st, setSt] = useState(null);
  const [msg, setMsg] = useState('');
  const [cluster, setCluster] = useState(null);
  const [onlineSources, setOnlineSources] = useState([]);
  const timer = useRef(null);

  const poll = async () => {
    try {
      const [s, c, o] = await Promise.all([
        api.trainStatus(),
        api.trainCluster().catch(() => null),
        api.trainOnlineSources().catch(() => ({ sources: [] })),
      ]);
      setSt(s);
      if (c) setCluster(c);
      if (o?.sources) setOnlineSources(o.sources);
    } catch {  }
  };

  useEffect(() => {
    poll();
    timer.current = setInterval(poll, 1000);
    return () => clearInterval(timer.current);
  }, []);

  const start = async () => {
    try {
      const r = await api.trainStart({
        model, steps, batch, lr, seq_len: seqLen, phase: 4,
        compute_level: computeLevel, use_cluster: useCluster, use_online_data: useOnlineData,
      });
      setMsg(r.message);
      poll();
    } catch (e) { setMsg(`启动失败: ${e.message}`); }
  };

  const stop = async () => {
    try { const r = await api.trainStop(); setMsg(r.message); } catch (e) { setMsg(e.message); }
  };

  const openFolder = async () => {
    try {
      const r = await api.trainOpenFolder();
      setMsg(r.ok ? `已打开目录: ${r.path}` : `打开失败: ${r.error}`);
    } catch (e) { setMsg(`打开失败: ${e.message}`); }
  };

  const running = st?.running;
  const losses = (st?.loss_history || []).map((d) => d.ema ?? d.loss);
  const lyaps = (st?.lyap_history || []).map((d) => d.lyap);
  const pct = st?.total_steps ? Math.round((st.step / st.total_steps) * 100) : 0;

  const statusText = running ? '运行中' : (st?.message === 'completed' ? '已完成' : '空闲');
  const gpus = cluster?.gpus ?? 0;
  const canCluster = gpus > 1 || cluster?.distributed;

  return (
    <Page title="混沌训练" sub="真实梯度反向传播 · 每秒刷新训练遥测"
      actions={
        <div className="flex items-center gap-2">
          {st?.checkpoint && <Badge color="var(--success)">checkpoint saved</Badge>}
          <Btn variant="ghost" icon={FolderOpen} onClick={openFolder}>打开保存目录</Btn>
        </div>
      }>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Metric label="状态" value={statusText} accent={running ? 'var(--warning)' : 'var(--success)'} icon={Dna} />
        <Metric label="Step" value={`${st?.step ?? 0}/${st?.total_steps ?? 0}`} accent="var(--accent)" />
        <Metric label="Loss (EMA)" value={st?.loss ?? '-'} accent="var(--accent)" />
        <Metric label="Grad Norm" value={st?.grad_norm ?? '-'} accent="var(--accent)" />
      </div>

      {}
      <div className="panel p-3.5 mb-5">
        <div className="flex justify-between text-[11px] mb-2.5">
          <span className="text-[var(--text-tertiary)] truncate">{st?.message || 'idle'} · {msg}</span>
          <span className="mono font-semibold text-[var(--accent)]">{pct}%</span>
        </div>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="训练配置" className="space-y-5">
          <Select label="目标模型" value={model} onChange={setModel} options={[
            { value: 'starlight', label: 'StarLight LM（语料语言模型）' },
            { value: 'chaos', label: 'ChaosNN（Lorenz 轨迹预测）' },
            { value: 'full', label: 'Full AGI（StarLight + ChaosNN）' },
          ]} />
          <Slider label="训练步数" value={steps} onChange={setSteps} min={50} max={5000} step={50} />
          <Slider label="Batch Size" value={batch} onChange={setBatch} min={1} max={16} step={1} />
          <Slider label="学习率 ×1e-4" value={lr * 1e4} onChange={(v) => setLr(v * 1e-4)} min={0.5} max={20} step={0.5} format={(v) => (v * 1e-4).toExponential(1)} />
          {model !== 'chaos' && (
            <Slider label="序列长度" value={seqLen} onChange={setSeqLen} min={32} max={128} step={16} />
          )}

          {}
          <Slider
            label={<span className="flex items-center gap-1.5"><Zap size={12} /> 算力等级</span>}
            value={computeLevel} onChange={setComputeLevel} min={1} max={10} step={1}
            format={(v) => `${v}/10`}
          />
          <div className="text-[10px] text-[var(--text-tertiary)] -mt-3">
            等级越高，实际 batch 越大、迭代越快；低等级更稳定。
          </div>

          {}
          <div className="flex items-center justify-between panel p-3">
            <div className="flex items-center gap-2 text-[12px] text-[var(--text-secondary)]">
              <Server size={14} className={canCluster ? 'text-[var(--success)]' : 'text-[var(--text-tertiary)]'} />
              <span>使用集群 / 多 GPU</span>
            </div>
            <button
              onClick={() => canCluster && setUseCluster((v) => !v)}
              className={`w-10 h-5 rounded-full relative transition-colors ${useCluster && canCluster ? 'bg-[var(--success)]' : 'bg-[rgba(255,255,255,0.12)]'}`}
              disabled={!canCluster}
            >
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${useCluster && canCluster ? 'translate-x-5' : ''}`} />
            </button>
          </div>
          {cluster && (
            <div className="text-[10px] text-[var(--text-tertiary)] leading-relaxed">
              GPU: {gpus} {cluster.gpu_names.map((g) => g.split(' ').pop()).join(', ') || '无'}
              {cluster.distributed && ` · 分布式 rank=${cluster.rank}/${cluster.world_size}`}
            </div>
          )}

          {}
          <div className="flex items-center justify-between panel p-3">
            <div className="flex items-center gap-2 text-[12px] text-[var(--text-secondary)]">
              <Wifi size={14} className={onlineSources.length ? 'text-[var(--accent)]' : 'text-[var(--text-tertiary)]'} />
              <span>联网训练语料</span>
            </div>
            <button
              onClick={() => onlineSources.length && setUseOnlineData((v) => !v)}
              className={`w-10 h-5 rounded-full relative transition-colors ${useOnlineData && onlineSources.length ? 'bg-[var(--accent)]' : 'bg-[rgba(255,255,255,0.12)]'}`}
              disabled={!onlineSources.length}
            >
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${useOnlineData && onlineSources.length ? 'translate-x-5' : ''}`} />
            </button>
          </div>
          {useOnlineData && onlineSources.length > 0 && (
            <div className="text-[10px] text-[var(--text-tertiary)] leading-relaxed">
              将拉取 {onlineSources.length} 个白名单数据源并合并到本地语料库。
            </div>
          )}

          <div className="flex gap-2 pt-1">
            {running
              ? <Btn variant="danger" icon={Square} onClick={stop}>停止训练</Btn>
              : <Btn variant="primary" icon={Play} onClick={start}>启动真实训练</Btn>}
          </div>
          <div className="panel p-3 text-[11px] leading-relaxed text-[var(--text-tertiary)]">
            StarLight：从项目语料采样窗口做真实 LM 训练（AdamW + BF16 + 梯度裁剪 + Lyapunov/秩锚点正则），结束自动保存检查点。<br /><br />
            ChaosNN：用 Lorenz 吸引子真实轨迹做下一状态预测，混沌核在线演化权重。
          </div>
        </Card>

        <Card title="损失曲线（EMA）" className="lg:col-span-2">
          <LineChart data={losses} color="#f472b6" height={220} label="train loss ema" />
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div>
              <div className="label">Lyapunov / 收敛指数</div>
              <LineChart data={lyaps} color="#a78bfa" height={90} label="lyapunov λ" />
            </div>
            <div className="panel p-4">
              <div className="label">运行信息</div>
              <div className="space-y-1.5 mono text-[11px] text-[var(--text-secondary)]">
                <div>model: <b className="text-[var(--text-primary)]">{st?.model ?? '-'}</b></div>
                <div>lr: <b className="text-[var(--text-primary)]">{st?.lr ?? '-'}</b></div>
                <div>elapsed: <b className="text-[var(--text-primary)]">{st?.elapsed ?? 0}s</b></div>
                <div>started: <b className="text-[var(--text-primary)]">{st?.started_at ?? '-'}</b></div>
                <div>batch: <b className="text-[var(--text-primary)]">{st?.batch ?? batch}</b> · accum: <b className="text-[var(--text-primary)]">{st?.grad_accum ?? 1}</b></div>
                <div>gpus: <b className="text-[var(--text-primary)]">{st?.gpus_used ?? 1}</b></div>
                <div className="truncate">ckpt: <b className="text-[var(--success)]">{st?.checkpoint ? st.checkpoint.split(/[\\/]/).pop() : 'none'}</b></div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </Page>
  );
}
