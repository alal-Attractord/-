import React, { useEffect, useRef, useState } from 'react';
import { Send, BrainCircuit, Eye, Atom, Scale, Wand2, ShieldCheck, User, Square, Database, Wrench } from 'lucide-react';
import { Page, Card, Btn, Badge, LineChart, Empty, Select, IntensitySlider } from '../components/ui';
import { streamPost } from '../api';

const PHASES = {
  perceive: { icon: Eye, color: '#60a5fa', label: '感知' },
  chaos: { icon: Atom, color: '#a78bfa', label: '混沌激发' },
  deliberate: { icon: Scale, color: '#fbbf24', label: '权衡' },
  recall: { icon: Database, color: '#22d3ee', label: '记忆检索' },
  tool_call: { icon: Wrench, color: '#f97316', label: '工具调用' },
  synthesize: { icon: Wand2, color: '#f472b6', label: '合成' },
  reflect: { icon: ShieldCheck, color: '#22c55e', label: '反思' },
};

function ThoughtCard({ t }) {
  const p = PHASES[t.phase] || PHASES.perceive;
  return (
    <div className="panel p-2.5 mb-2" style={{ borderLeft: `2px solid ${p.color}` }}>
      <div className="flex items-center gap-2 mb-1">
        <p.icon size={12} style={{ color: p.color }} />
        <span className="text-[11px] font-semibold" style={{ color: p.color }}>{t.title}</span>
        <span className="text-[9px] px-1 py-0.5 rounded mono uppercase"
          style={{ background: `${p.color}15`, color: p.color, border: `1px solid ${p.color}30` }}>{t.phase}</span>
      </div>
      <div className="text-[11px] leading-relaxed text-[var(--text-secondary)]">{t.detail}</div>
      {t.trajectory && (
        <div className="mt-1.5">
          <LineChart data={t.trajectory} color={p.color} height={42} fill label="lorenz magnitude" />
        </div>
      )}
      {t.candidates && (
        <div className="flex flex-wrap gap-1 mt-1.5">
          {t.candidates.map((c, i) => {
            const tk = (c.token || '').replace(/\s/g, '␣').trim();
            const display = tk === '' || tk === '␣' ? '∅' : tk;
            return (
              <span key={i} className="mono text-[10px] px-1.5 py-0.5 rounded"
                style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: display === '∅' ? 'var(--text-tertiary)' : 'var(--text-secondary)' }}>
                {display} <span className="text-[var(--text-tertiary)]">{(c.prob * 100).toFixed(1)}%</span>
              </span>
            );
          })}
        </div>
      )}
      {t.results && (
        <div className="mt-1.5 space-y-1">
          {t.results.map((r, i) => (
            <div key={i} className="text-[10px] px-1.5 py-1 rounded"
              style={{ background: 'var(--bg-input)', border: '1px solid var(--border)' }}>
              <span className="mono text-[var(--accent)]">{r.score?.toFixed(2)}</span>{' '}
              <span className="text-[var(--text-secondary)]">{r.text}</span>
            </div>
          ))}
        </div>
      )}
      {t.result && (
        <div className="mt-1.5 text-[10px] px-1.5 py-1 rounded mono break-all"
          style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-secondary)' }}>
          {t.result}
        </div>
      )}
      {t.temperature_history && (
        <div className="mt-1.5">
          <LineChart data={t.temperature_history} color={p.color} height={42} fill label="adaptive temperature" />
        </div>
      )}
    </div>
  );
}

export default function AgentPage() {
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [model, setModel] = useState('starlight');
  const [intensity, setIntensity] = useState('standard');
  const scrollRef = useRef(null);
  const abortRef = useRef(null);

  useEffect(() => { scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight); }, [msgs]);

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput('');
    setBusy(true);
    setMsgs((m) => [...m, { role: 'user', text }, { role: 'ai', thoughts: [], text: '', streaming: true }]);

    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      await streamPost('/agent/think/stream', { text, max_tokens: 96, model, intensity }, (ev) => {
        setMsgs((m) => {
          const out = [...m];
          const last = { ...out[out.length - 1] };
          if (ev.type === 'thought') {
            last.thoughts = [...last.thoughts, ev];
          } else if (ev.type === 'token') {
            last.text = (last.text || '') + (ev.delta || '');
          } else if (ev.type === 'done') {
            last.text = ev.result ?? last.text;
            last.streaming = false;
            last.usedModel = ev.model;
          } else if (ev.type === 'error') {
            last.text = `⚠ ${ev.error}`;
            last.streaming = false;
          }
          out[out.length - 1] = last;
          return out;
        });
      });
    } catch (e) {
      if (e.name !== 'AbortError') {
        setMsgs((m) => {
          const out = [...m];
          out[out.length - 1] = { ...out[out.length - 1], text: `⚠ 后端连接失败: ${e.message}`, streaming: false };
          return out;
        });
      }
    }
    setMsgs((m) => {
      const out = [...m];
      if (out.length) out[out.length - 1] = { ...out[out.length - 1], streaming: false };
      return out;
    });
    setBusy(false);
  };

  const stop = () => { abortRef.current?.abort(); setBusy(false); };

  return (
    <Page title="Agent 深度思考" sub="真实混沌推理链：感知 → 混沌激发 → 权衡 → 记忆检索 → 工具调用 → 合成 → 反思">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 h-[calc(100%-56px)]">
        {}
        <Card title="对话" className="xl:col-span-2 flex flex-col" pad={false}>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3" style={{ minHeight: 300 }}>
            {msgs.length === 0 && <Empty icon={BrainCircuit} text="向混沌 Agent 提问，观察它的真实思考过程" />}
            {msgs.map((m, i) => (
              <div key={i}>
                {m.role === 'user' ? (
                  <div className="flex justify-end gap-2">
                    <div className="max-w-[75%] px-3 py-2 text-[12px] leading-relaxed msg-user">
                      {m.text}
                    </div>
                    <div className="w-6 h-6 rounded shrink-0 flex items-center justify-center bg-[var(--accent-soft)] border border-[rgba(94,106,210,0.25)]">
                      <User size={12} className="text-[var(--accent)]" />
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <div className="w-6 h-6 rounded shrink-0 flex items-center justify-center bg-[var(--bg-surface)] border border-[var(--border)]">
                      <BrainCircuit size={12} className="text-[var(--text-secondary)]" />
                    </div>
                    <div className="flex-1 min-w-0 space-y-1.5">
                      {m.thoughts?.length > 0 && (
                        <div className="space-y-1">
                          <div className="text-[10px] font-semibold uppercase tracking-wide flex items-center gap-1.5 text-[var(--text-tertiary)]">
                            <span className={`w-1.5 h-1.5 rounded-full ${m.streaming ? 'pulse' : ''}`} style={{ background: 'var(--accent)' }} />
                            思考链 · {m.thoughts.length} 步 {m.streaming && '· 进行中'}
                          </div>
                          {m.thoughts.map((t, j) => <ThoughtCard key={j} t={t} />)}
                        </div>
                      )}
                      {(m.text || m.streaming) && (
                        <div className="space-y-1.5">
                          {m.usedModel && (
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] px-1.5 py-0.5 rounded mono uppercase"
                                style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid var(--glass-border)', color: 'var(--text-tertiary)' }}>
                                {m.usedModel}
                              </span>
                            </div>
                          )}
                          <div className="px-3 py-2 text-[12px] leading-[1.7] whitespace-pre-wrap msg-ai">
                            {m.text}
                            {m.streaming && <span className="inline-block w-1.5 h-3 ml-1 align-middle bg-[var(--accent)] rounded-sm animate-pulse" />}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="p-2.5 border-t border-[var(--border)] flex gap-2">
            <input
              className="input flex-1"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              placeholder="例如：混沌神经网络的核心优势是什么？"
              disabled={busy}
            />
            {busy
              ? <Btn variant="danger" icon={Square} onClick={stop}>停止</Btn>
              : <Btn variant="primary" icon={Send} onClick={send}>思考</Btn>}
          </div>
        </Card>

        {}
        <Card title="模型与强度" className="space-y-5">
          <Select label="挂载模型" value={model} onChange={setModel} options={[
            { value: 'starlight', label: 'StarLight LM（36.93M 双数种子 Transformer）' },
            { value: 'chaos', label: 'ChaosNN（Lorenz 轨迹预测）' },
            { value: 'full', label: 'Full AGI（StarLight + ChaosNN 融合）' },
            { value: 'chaos_wm_v2', label: '混沌世界模型 v2（感知+双读出内核+MPC决策+记忆链）' },
            { value: 'chaos_llm', label: '纯混沌 LLM（74 QA 精确记忆 + HC3 语义库）' },
            { value: 'chaos_world', label: '世界模型 v1（引擎核 + 中文判断说话）' },
          ]} />

          <div>
            <div className="label mb-2.5">思考强度</div>
            <IntensitySlider value={intensity} onChange={setIntensity} />
          </div>

          <div className="panel p-3 text-[10.5px] leading-relaxed text-[var(--text-tertiary)]">
            当前强度会改变采样温度与 Lorenz 混沌步数。
            <span className="text-[var(--rose)]">SecurityManager 始终运行，不会执行越权或非法操作。</span>
          </div>

          <div className="space-y-2.5 text-[11px] leading-relaxed text-[var(--text-secondary)]">
            {[
              ['感知', 'SentencePiece 32200 词表真实分词。', '#60a5fa'],
              ['混沌激发', 'Lorenz 吸引子被 prompt 扰动，强度随等级增加。', '#a78bfa'],
              ['权衡', '首步 logits 的 top-5 候选 token 及概率。', '#fbbf24'],
              ['记忆检索', '置信度不足时自动查询混沌记忆库。', '#22d3ee'],
              ['工具调用', '关键词触发白名单 MCP 工具。', '#f97316'],
              ['合成', 'SeedGuidedSampler 自适应温度逐 token 调整。', '#f472b6'],
              ['反思', '行为监控与审计计数。', '#22c55e'],
            ].map(([k, v, c]) => (
              <div key={k} className="flex gap-2.5">
                <span className="w-1 rounded-full shrink-0" style={{ background: c }} />
                <div><b style={{ color: c }}>{k}</b><br />{v}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </Page>
  );
}
