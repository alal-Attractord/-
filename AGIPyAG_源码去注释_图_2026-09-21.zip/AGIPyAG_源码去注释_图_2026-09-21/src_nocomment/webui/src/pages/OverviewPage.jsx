import React, { Suspense, lazy, useEffect, useRef, useState } from 'react';
import { Cpu, Database, Gauge, Layers, Zap, Server, RefreshCw, ArrowUpRight } from 'lucide-react';
import { Page, Card, Metric, Badge, Btn, LineChart, StatusRow } from '../components/ui';
import { api } from '../api';


const ChaosScene = lazy(() => import('../components/ChaosScene'));


function HudChip({ label, value, accent = 'var(--accent)' }) {
  return (
    <div className="rounded-[14px] px-4 py-3 min-w-[118px] liquid-glass"
      style={{ boxShadow: '0 10px 32px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.08)' }}>
      <div className="text-[9px] font-semibold uppercase tracking-[0.12em] text-[var(--text-tertiary)] mb-1">{label}</div>
      <div className="mono text-[17px] font-semibold leading-none" style={{ color: accent }}>{value}</div>
    </div>
  );
}

export default function OverviewPage() {
  const [health, setHealth] = useState(null);
  const [info, setInfo] = useState(null);
  const [chaos, setChaos] = useState(null);
  const [magHist, setMagHist] = useState([]);
  const [deltas, setDeltas] = useState({ steps: null, gens: null });
  const prevRef = useRef(null);
  const timer = useRef(null);

  const refresh = async () => {
    try {
      const [h, i, c] = await Promise.all([api.health(), api.modelInfo(), api.chaosState(120)]);
      if (prevRef.current) {
        setDeltas({
          steps: h.train_steps_total - prevRef.current.train_steps_total,
          gens: h.generations_total - prevRef.current.generations_total,
        });
      }
      prevRef.current = h;
      setHealth(h); setInfo(i); setChaos(c);
      setMagHist((m) => [...m, c.engine.chaos_magnitude].slice(-80));
    } catch {  }
  };

  useEffect(() => {
    refresh();
    timer.current = setInterval(refresh, 3000);
    return () => clearInterval(timer.current);
  }, []);

  const online = !!health;
  const eng = chaos?.engine;

  return (
    <Page title="系统总览" sub="后端遥测 · 每 3 秒真实轮询"
      actions={<Btn icon={RefreshCw} onClick={refresh}>刷新</Btn>}>

      {}
      <div className="panel overflow-hidden mb-5 relative" style={{ height: 440 }}>
        <Suspense fallback={<div className="absolute inset-0 flex items-center justify-center text-[11px] mono text-[var(--text-tertiary)]">初始化 3D 混沌核心…</div>}>
          <ChaosScene energy={eng?.chaos_magnitude ?? 1.3} />
        </Suspense>
        <div className="scene-veil" />

        {}
        <div className="absolute top-5 left-6 right-6 flex items-start justify-between pointer-events-none">
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="text-[16px] font-semibold tracking-[-0.01em] text-[var(--text-primary)]">混沌神经网络核心</span>
              <Badge color="var(--cyan)" pulse>LIVE</Badge>
            </div>
            <div className="text-[11px] mono text-[var(--text-tertiary)]">
              分层神经元节点 · 突触连接脉冲 · 随 chaos_magnitude 放电呼吸 · 滚轮缩放 · 拖拽旋转
            </div>
          </div>
          <div className="text-[10px] mono text-[var(--text-tertiary)] hidden md:block mt-1">自动旋转中</div>
        </div>

        {}
        <div className="absolute bottom-5 left-6 right-6 flex flex-wrap gap-3 pointer-events-none">
          <HudChip label="Engine Steps" value={eng?.step_count ?? 0} accent="var(--accent)" />
          <HudChip label="Magnitude" value={eng ? eng.chaos_magnitude.toFixed(3) : '-'} accent="var(--cyan)" />
          <HudChip label="Trajectory" value={eng?.trajectory_length ?? 0} accent="var(--violet)" />
          <HudChip label="ρ / σ / β" value={eng ? `${eng.rho} / ${eng.sigma} / ${eng.beta.toFixed(2)}` : '-'} accent="var(--pink)" />
        </div>
      </div>

      {}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <Metric label="Engine 状态" value={online ? '在线' : '离线'}
          accent={online ? 'var(--mint)' : 'var(--danger)'} icon={Server} small />
        <Metric label="参数规模" value={info ? info.params_m : '-'} unit="M"
          accent="var(--accent)" icon={Layers} />
        <Metric label="训练步数" value={health ? health.train_steps_total : '-'}
          accent="var(--cyan)" icon={Zap} delta={deltas.steps} />
        <Metric label="语料词元" value={health ? (health.corpus_tokens / 1000).toFixed(1) : '-'} unit="K"
          accent="var(--violet)" icon={Database} />
      </div>

      {}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card title="混沌幅值" className="lg:col-span-2"
          actions={<div className="flex items-center gap-2">
            <span className="text-[10px] text-[var(--text-tertiary)]">实时</span>
            <Badge color="var(--violet)">{eng ? eng.chaos_magnitude.toFixed(3) : '-'}</Badge>
          </div>}>
          <LineChart data={magHist} color="#a78bfa" height={190} label="chaos magnitude" />
          <div className="grid grid-cols-3 gap-3 mt-5">
            {[
              ['engine steps', eng?.step_count ?? 0, 'var(--accent)'],
              ['magnitude', eng ? eng.chaos_magnitude.toFixed(3) : '-', 'var(--cyan)'],
              ['trajectory', eng?.trajectory_length ?? 0, 'var(--violet)'],
            ].map(([k, v, c]) => (
              <div key={k} className="rounded-[14px] p-4 text-center liquid-glass"
                style={{ boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.05)' }}>
                <div className="text-[9px] uppercase tracking-[0.1em] text-[var(--text-tertiary)] mb-1.5">{k}</div>
                <div className="text-[18px] font-semibold mono" style={{ color: c }}>{v}</div>
              </div>
            ))}
          </div>
        </Card>

        <Card title="子系统状态" actions={<ArrowUpRight size={14} className="text-[var(--text-tertiary)]" />}>
          <div className="space-y-1">
            <StatusRow icon={Zap} label="StarLight 混沌 Transformer" active={online}
              note={info ? `${info.config_dict?.num_layers}L / ${info.config_dict?.hidden_dim}D / ${info.config_dict?.num_heads}H` : ''} />
            <StatusRow icon={Cpu} label="ChaosNN 混沌神经网络" active={online}
              note={info ? `${(info.chaos_nn.params / 1000).toFixed(1)}K params` : ''} />
            <StatusRow icon={Database} label="SPM 词表" active={online}
              note={health ? `vocab ${health.vocab_size}` : ''} />
            <StatusRow icon={Gauge} label="SecurityManager" active={online}
              note="Fernet + RSA-2048" />
            <StatusRow icon={Server} label="API Server :8768" active={online}
              note={online ? `uptime ${Math.round(health.uptime_s)}s` : 'offline'} />
          </div>
        </Card>
      </div>
    </Page>
  );
}
