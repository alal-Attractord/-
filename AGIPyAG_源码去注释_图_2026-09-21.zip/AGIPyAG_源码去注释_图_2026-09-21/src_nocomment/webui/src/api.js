
const API = '/api';



export const TOKEN =
  (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_CHAOS_API_TOKEN) ||
  (typeof localStorage !== 'undefined' && localStorage.getItem('chaos_api_token')) ||
  'chaos_agi_2026';

const headers = { 'Content-Type': 'application/json', 'X-API-Token': TOKEN };

async function req(path, options = {}) {
  const r = await fetch(`${API}${path}`, { headers, ...options });
  if (!r.ok) {
    const t = await r.text().catch(() => '');
    throw new Error(`HTTP ${r.status}: ${t.slice(0, 200)}`);
  }
  return r.json();
}

export const api = {
  health: () => req('/health'),
  modelInfo: () => req('/model/info'),
  exportOnnx: (body) => req('/model/export/onnx', { method: 'POST', body: JSON.stringify(body) }),
  logs: (n = 100) => req(`/logs?n=${n}`),
  generate: (body) => req('/generate', { method: 'POST', body: JSON.stringify(body) }),
  think: (body) => req('/agent/think', { method: 'POST', body: JSON.stringify(body) }),
  trainStart: (body) => req('/train', { method: 'POST', body: JSON.stringify(body) }),
  trainStatus: () => req('/train/status'),
  trainStop: () => req('/train/stop', { method: 'POST', body: '{}' }),
  trainOpenFolder: () => req('/train/open-folder', { method: 'POST', body: '{}' }),
  trainCluster: () => req('/train/cluster'),
  trainOnlineSources: () => req('/train/online/sources'),
  vocabStats: () => req('/vocab/stats'),
  vocabBuild: (body) => req('/vocab/build', { method: 'POST', body: JSON.stringify(body) }),
  vocabBuildStatus: () => req('/vocab/build/status'),
  securityStatus: () => req('/security/status'),
  chaosState: (steps = 200) => req(`/chaos/state?steps=${steps}`),

  
  memoryCreate: (body) => req('/memory/create', { method: 'POST', body: JSON.stringify(body) }),
  memoryStats: () => req('/memory/stats'),
  memoryWrite: (body) => req('/memory/write', { method: 'POST', body: JSON.stringify(body) }),
  memoryWriteBulk: (body) => req('/memory/write/bulk', { method: 'POST', body: JSON.stringify(body) }),
  memoryRetrieve: (body) => req('/memory/retrieve', { method: 'POST', body: JSON.stringify(body) }),
  memoryRetrieveText: (body) => req('/memory/retrieve/text', { method: 'POST', body: JSON.stringify(body) }),
  memoryDecay: (body) => req('/memory/decay', { method: 'POST', body: JSON.stringify(body) }),
  memoryConsolidate: (body) => req('/memory/consolidate', { method: 'POST', body: JSON.stringify(body) }),
  memoryReset: () => req('/memory', { method: 'DELETE' }),
  memorySave: (body) => req('/memory/save', { method: 'POST', body: JSON.stringify(body) }),
  memoryLoad: (body) => req('/memory/load', { method: 'POST', body: JSON.stringify(body) }),
  memoryBanks: () => req('/memory/banks'),

  
  mcpTools: () => req('/mcp/tools'),
  mcpCall: (body) => req('/mcp/call', { method: 'POST', body: JSON.stringify(body) }),

  
  corpusStats: () => req('/corpus/stats'),
  corpusRebuild: () => req('/corpus/rebuild', { method: 'POST', body: '{}' }),

  
  networkStats: () => req('/network/stats'),
  networkRecords: (limit = 500, action, since) => {
    const params = new URLSearchParams();
    params.append('limit', limit);
    if (action) params.append('action', action);
    if (since) params.append('since', since);
    return req(`/network/records?${params.toString()}`);
  },
  networkConnections: () => req('/network/connections'),
  networkNodes: () => req('/network/nodes'),

  
  mapTileUrl: (z, x, y) => `${API}/map/tile/${z}/${x}/${y}`,
  mapStats: () => req('/map/stats'),
  mapDownload: (body) => req('/map/download', { method: 'POST', body: JSON.stringify(body) }),
  mapClear: () => req('/map/clear', { method: 'POST', body: '{}' }),
  mapNodes: () => req('/map/nodes'),
};





export async function streamPost(path, body, onEvent, signal) {
  const r = await fetch(`${API}${path}`, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal,
  });
  if (!r.ok || !r.body) throw new Error(`HTTP ${r.status}`);
  const reader = r.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buf.indexOf('\n\n')) >= 0) {
      const raw = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 2);
      if (!raw.startsWith('data:')) continue;
      const payload = raw.slice(5).trim();
      if (payload === '[DONE]') return;
      try { onEvent(JSON.parse(payload)); } catch {  }
    }
  }
}
