import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Orbit, BrainCircuit, Sparkles, Dna, BookOpenText, Atom, ShieldCheck, Boxes,
  ScrollText, Database, Search, CornerDownLeft, Command, Activity, Files, Wrench,
  Globe, Sigma,
} from 'lucide-react';
import { api } from './api';
import OverviewPage from './pages/OverviewPage';
import AgentPage from './pages/AgentPage';
import InferencePage from './pages/InferencePage';
import TrainingPage from './pages/TrainingPage';
import VocabPage from './pages/VocabPage';
import ChaosPage from './pages/ChaosPage';
import SecurityPage from './pages/SecurityPage';
import ModelsPage from './pages/ModelsPage';
import LogsPage from './pages/LogsPage';
import MemoryPage from './pages/MemoryPage';
import CorpusPage from './pages/CorpusPage';
import MCPPage from './pages/MCPPage';
import NetworkMapPage from './pages/NetworkMapPage';
import KoopmanPage from './pages/KoopmanPage';

const NAV_GROUPS = [
  {
    label: '核心',
    items: [
      { id: 'overview', label: '系统总览', icon: Orbit, hint: '遥测 · 子系统' },
      { id: 'koopman', label: 'Koopman 主干', icon: Sigma, hint: '自适应线性算子 · 谱分析' },
      { id: 'agent', label: 'Agent 思考', icon: BrainCircuit, hint: '混沌推理链 SSE' },
      { id: 'inference', label: '推理生成', icon: Sparkles, hint: '逐 token 流式' },
    ],
  },
  {
    label: '训练与记忆',
    items: [
      { id: 'training', label: '混沌训练', icon: Dna, hint: '真实梯度回传' },
      { id: 'memory', label: '混沌记忆库', icon: Database, hint: '零训练向量记忆' },
      { id: 'vocab', label: '词表构建', icon: BookOpenText, hint: 'SPM BPE 训练' },
      { id: 'corpus', label: '语料库', icon: Files, hint: '项目语料统计与重建' },
    ],
  },
  {
    label: '系统',
    items: [
      { id: 'network', label: '网络地图', icon: Globe, hint: '全球网络追踪' },
      { id: 'chaos', label: '混沌动力', icon: Atom, hint: 'Lorenz 吸引子' },
      { id: 'models', label: '模型核心', icon: Boxes, hint: 'StarLight 架构' },
      { id: 'security', label: '安全中心', icon: ShieldCheck, hint: 'Fernet + RSA' },
      { id: 'logs', label: '系统日志', icon: ScrollText, hint: '引擎实时日志' },
      { id: 'mcp', label: 'MCP 工具', icon: Wrench, hint: '白名单工具调用' },
    ],
  },
];

const FLAT_NAV = NAV_GROUPS.flatMap((g) => g.items);

const PAGES = {
  overview: OverviewPage, agent: AgentPage, memory: MemoryPage, inference: InferencePage,
  training: TrainingPage, vocab: VocabPage, corpus: CorpusPage, chaos: ChaosPage,
  models: ModelsPage, security: SecurityPage, logs: LogsPage, mcp: MCPPage,
  network: NetworkMapPage, koopman: KoopmanPage,
};


function CommandPalette({ open, onClose, onNav }) {
  const [query, setQuery] = useState('');
  const [sel, setSel] = useState(0);
  const inputRef = useRef(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return FLAT_NAV;
    return FLAT_NAV.filter((n) =>
      n.label.toLowerCase().includes(q) || n.id.includes(q) || n.hint.toLowerCase().includes(q));
  }, [query]);

  useEffect(() => {
    if (open) {
      setQuery(''); setSel(0);
      setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  useEffect(() => { setSel(0); }, [query]);

  if (!open) return null;

  const keyDown = (e) => {
    if (e.key === 'Escape') onClose();
    else if (e.key === 'ArrowDown') { e.preventDefault(); setSel((s) => Math.min(s + 1, filtered.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
    else if (e.key === 'Enter' && filtered[sel]) { onNav(filtered[sel].id); onClose(); }
  };

  return (
    <div className="cmdk-overlay" onClick={onClose}>
      <div className="cmdk-panel liquid-glass-strong" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2.5 px-5 h-[52px] border-b border-[rgba(255,255,255,0.05)]">
          <Search size={15} className="text-[var(--text-tertiary)]" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={keyDown}
            placeholder="跳转页面…"
            className="flex-1 bg-transparent outline-none text-[14px] text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)]"
          />
          <span className="kbd">esc</span>
        </div>
        <div className="overflow-y-auto py-2">
          {filtered.length === 0 && (
            <div className="px-5 py-8 text-center text-[12px] text-[var(--text-tertiary)]">无匹配页面</div>
          )}
          {filtered.map((n, i) => (
            <div
              key={n.id}
              className={`cmdk-item ${i === sel ? 'selected' : ''}`}
              onMouseEnter={() => setSel(i)}
              onClick={() => { onNav(n.id); onClose(); }}
            >
              <n.icon size={15} className={i === sel ? 'text-[var(--accent)]' : 'text-[var(--text-tertiary)]'} />
              <span className="flex-1">{n.label}</span>
              <span className="text-[10px] text-[var(--text-tertiary)]">{n.hint}</span>
              {i === sel && <CornerDownLeft size={12} className="text-[var(--text-tertiary)]" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


function TopHud({ health, online }) {
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-40 flex items-center gap-3 px-5 py-2.5 liquid-glass rounded-full"
      style={{ boxShadow: 'var(--glass-shadow), 0 0 40px rgba(124, 58, 237, 0.12)' }}>
      <div className="flex items-center gap-2">
        <span className={`status-dot ${online ? 'pulse' : ''}`}
          style={{ background: online ? 'var(--success)' : 'var(--danger)', color: online ? 'var(--success)' : 'var(--danger)' }} />
        <span className="text-[11px] font-bold text-[var(--text-primary)] tracking-wide">
          {online ? 'Engine Online' : 'Engine Offline'}
        </span>
      </div>
      {online && (
        <>
          <span className="w-px h-3 bg-[rgba(167,139,250,0.15)]" />
          <div className="flex items-center gap-4 text-[10px] mono text-[var(--text-tertiary)]">
            <span>steps <b className="text-[var(--text-primary)]">{health?.train_steps_total ?? 0}</b></span>
            <span>gens <b className="text-[var(--text-primary)]">{health?.generations_total ?? 0}</b></span>
            <span>uptime <b className="text-[var(--text-primary)]">{Math.round(health?.uptime_s ?? 0)}s</b></span>
          </div>
        </>
      )}
    </div>
  );
}


function DockNav({ page, setPage }) {
  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 flex items-center gap-1 p-1.5 liquid-glass rounded-2xl"
      style={{ boxShadow: 'var(--glass-shadow), 0 0 40px rgba(124, 58, 237, 0.15)' }}>
      {FLAT_NAV.map((n) => {
        const active = page === n.id;
        return (
          <button
            key={n.id}
            onClick={() => setPage(n.id)}
            className={`dock-item ${active ? 'active' : ''}`}
            title={n.hint}
          >
            <n.icon size={15} strokeWidth={active ? 2.2 : 1.8} />
            <span className="dock-label">{n.label}</span>
          </button>
        );
      })}
    </div>
  );
}


export default function App() {
  const [page, setPage] = useState('overview');
  const [health, setHealth] = useState(null);
  const [online, setOnline] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);

  useEffect(() => {
    let alive = true;
    const ping = async () => {
      try {
        const h = await api.health();
        if (alive) { setHealth(h); setOnline(true); }
      } catch {
        if (alive) setOnline(false);
      }
    };
    ping();
    const t = setInterval(ping, 5000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((o) => !o);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const PageComp = PAGES[page];
  const current = FLAT_NAV.find((n) => n.id === page);

  return (
    <div className="h-full flex flex-col relative overflow-hidden">
      {}
      <div aria-hidden className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: 0 }}>
        <div className="aurora" style={{
          width: 1200, height: 680, top: -240, left: -200,
          background: 'radial-gradient(closest-side, rgba(124,58,237,0.22), transparent)',
          animation: 'drift1 38s ease-in-out infinite',
        }} />
        <div className="aurora" style={{
          width: 1000, height: 580, top: -160, right: -220,
          background: 'radial-gradient(closest-side, rgba(34,211,238,0.12), transparent)',
          animation: 'drift2 46s ease-in-out infinite',
        }} />
        <div className="aurora" style={{
          width: 900, height: 620, bottom: -260, right: 60,
          background: 'radial-gradient(closest-side, rgba(167,139,250,0.1), transparent)',
          animation: 'drift3 54s ease-in-out infinite',
        }} />
        <div className="aurora" style={{
          width: 720, height: 520, bottom: -200, left: 100,
          background: 'radial-gradient(closest-side, rgba(56,189,248,0.08), transparent)',
          animation: 'drift1 44s ease-in-out infinite reverse',
        }} />
      </div>

      {}
      <TopHud health={health} online={online} />

      {}
      <div className="fixed top-4 left-5 z-40 flex items-center gap-3">
        <div className="w-[38px] h-[38px] rounded-[14px] flex items-center justify-center liquid-glass relative"
          style={{ boxShadow: '0 4px 24px rgba(124,58,237,0.4), 0 0 20px rgba(167,139,250,0.25)' }}>
          <Orbit size={19} className="text-[var(--accent-hover)]" />
          <div className="absolute inset-0 rounded-[14px]"
            style={{ boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.15)', pointerEvents: 'none' }} />
        </div>
        <div>
          <div className="text-[14px] font-bold text-[var(--text-primary)] leading-tight tracking-tight text-glow">AGIPyAG</div>
          <div className="text-[9px] mono uppercase tracking-[0.16em] text-[var(--text-tertiary)]">{current?.label}</div>
        </div>
      </div>

      {}
      <button
        onClick={() => setPaletteOpen(true)}
        className="fixed top-4 right-5 z-40 flex items-center gap-2 h-[38px] pl-3.5 pr-2.5 rounded-full text-[11px] font-semibold text-[var(--text-tertiary)] liquid-glass transition-all hover:text-[var(--text-primary)]"
        style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.3), 0 0 16px rgba(124,58,237,0.1)' }}
      >
        <Command size={12} />
        <span className="hidden sm:inline">命令</span>
        <span className="kbd">⌘K</span>
      </button>

      {}
      <main className="flex-1 min-h-0 relative z-10 overflow-y-auto px-6 pt-20 pb-24">
        <div className="max-w-[1400px] mx-auto w-full">
          <PageComp key={page} />
        </div>
      </main>

      {}
      <DockNav page={page} setPage={setPage} />

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} onNav={setPage} />
    </div>
  );
}
