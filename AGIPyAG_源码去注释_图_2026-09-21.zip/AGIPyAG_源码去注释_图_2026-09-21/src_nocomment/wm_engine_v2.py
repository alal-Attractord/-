#!/usr/bin/env python3



















import json
import os
import sys
import threading
import time

import numpy as np
import torch

sys_ = os.path.dirname(os.path.abspath(__file__))
if sys_ not in sys.path:
    sys.path.insert(0, sys_)

import wm_v2 as W

DEV = W.DEV
CKPT_DIR = os.path.join(sys_, "data", "wm_v2")
K_DEFAULT = 20
K_WAVE = 60
NB_BRANCH = 8
BRANCH_NOISE = 0.02
MPC_STEPS = 60
MPC_CAND = 96













WAVE_VALIDATED = False
WAVE_BASIS = "free_rollout_displacement"






MPC_H = 40

_LOCK = threading.RLock()
_SUITE = None



class WorldModelV2:
    

    def __init__(self, ckpt_dir=CKPT_DIR, nb_branch=NB_BRANCH, branch_noise=BRANCH_NOISE):
        self.ckpt_dir = ckpt_dir
        self.nb_branch = int(nb_branch)
        self.branch_noise = float(branch_noise)
        self.ready = False
        self.missing = []
        self.env = self.env_d = None
        self.chaos = self.vision = self.decision = None
        self.ridge = None
        self.meta = {}
        self.tgt = None
        self.u_max, self.sub, self.t_seed = 300.0, 8, 12
        self.kp, self.lam_u = 6.0, 0.01
        self.r_thr = (0.35, 0.75)
        self.r_dist = None


    @torch.no_grad()
    def calibrate_describe(self, n=96, seed=3, K=None):
        






        if self.env is None or self.chaos is None:
            return None
        K = K_WAVE if K is None else int(K)
        rng = np.random.default_rng(seed)
        rs = []
        for _ in range(int(n)):
            _, xn = self.seed_window(T=16, seed=int(rng.integers(0, 10 ** 6)))
            p = self.imagine(xn, K=K, M=1, path="code")
            if p is None:
                break
            pr = self.env.denormalize(p)
            rs.append(float(np.linalg.norm(pr[-1] - pr[0])))
        if len(rs) < 8:
            return None
        span = float(np.linalg.norm(np.asarray(self.env.hi) - np.asarray(self.env.lo)))
        ratio = np.asarray(rs) / max(span, 1e-6)
        q = np.quantile(ratio, [0.55, 0.90])
        self.r_thr = (float(q[0]), float(q[1]))
        self.r_dist = {"n": int(len(rs)), "p55": float(q[0]), "p90": float(q[1]),
                       "mean": float(ratio.mean()), "max": float(ratio.max()),
                       "min": float(ratio.min()), "span": span, "K_wave": K, "path": "code"}
        return self.r_dist


    @staticmethod
    def _load_file(path):
        if not os.path.exists(path):
            return None
        try:
            return torch.load(path, map_location="cpu", weights_only=False)
        except Exception:
            return None

    @staticmethod
    def _env_from(ck):
        env = W.get_env(ck["env_name"])
        env.mu = np.asarray(ck["mu"], dtype=np.float64)
        env.sd = np.asarray(ck["sd"], dtype=np.float64)
        env.lo_t = torch.tensor(env.lo, dtype=torch.float32)
        env.hi_t = torch.tensor(env.hi, dtype=torch.float32)
        return env

    def load(self):
        with _LOCK:
            if self.ready:
                return self
            self.missing = []
            mp = os.path.join(self.ckpt_dir, "meta.json")
            if os.path.exists(mp):
                with open(mp, encoding="utf-8") as f:
                    self.meta = json.load(f)

            ck = self._load_file(os.path.join(self.ckpt_dir, "chaos_resid.pt"))
            if ck is not None:
                self.env = self._env_from(ck)
                kw = {k: ck["cfg"][k] for k in ("cont_std", "nb", "resid") if k in ck["cfg"]}
                self.chaos = W.ChaosWM(self.env, **kw).to(DEV)
                self.chaos.load_state_dict(ck["state_dict"])
                self.chaos.eval()

                self.ridge = W.RidgeReadout.load(os.path.join(self.ckpt_dir, "ridge_readout.npz"))
                if self.ridge is not None:
                    self.chaos.ridge = self.ridge
            else:
                self.missing.append("chaos_resid.pt")

            ck = self._load_file(os.path.join(self.ckpt_dir, "vision_full.pt"))
            if ck is not None:
                if self.env is None:
                    self.env = self._env_from(ck)
                kw = {k: ck["cfg"][k] for k in ("inten_const", "ch") if k in ck["cfg"]}
                self.vision = W.VisionWM(self.env, **kw).to(DEV)
                self.vision.load_state_dict(ck["state_dict"])
                self.vision.eval()
            else:
                self.missing.append("vision_full.pt")

            ck = self._load_file(os.path.join(self.ckpt_dir, "lstm_decision.pt"))
            if ck is not None:
                self.env_d = self._env_from(ck)
                kw = {k: ck["cfg"][k] for k in ("h", "layers", "use_action", "u_dim") if k in ck["cfg"]}
                self.decision = W.LSTMWM(self.env_d, **kw).to(DEV)
                self.decision.load_state_dict(ck["state_dict"])
                self.decision.eval()
                ex = ck.get("extra", {})
                if ex.get("TGT") is not None:
                    self.tgt = np.asarray(ex["TGT"], dtype=np.float64)
                self.u_max = float(ex.get("U_MAX", self.u_max))
                self.sub = int(ex.get("SUB", self.sub))
                self.t_seed = int(ex.get("T_SEED", self.t_seed))
                self.kp = float(ex.get("KP", self.kp))
                self.lam_u = float(ex.get("LAM_U", self.lam_u))
            else:
                self.missing.append("lstm_decision.pt")

            self.ready = True
            try:
                self.calibrate_describe()
            except Exception:
                pass
            return self


    def status(self):
        return {
            "ready": self.ready,
            "device": DEV,
            "missing": list(self.missing),
            "chaos_resid": W.param_count(self.chaos) if self.chaos is not None else 0,
            "vision_full": W.param_count(self.vision) if self.vision is not None else 0,
            "lstm_decision": W.param_count(self.decision) if self.decision is not None else 0,
            "parts": list(self.meta.get("parts", {}).keys()),
            "ridge_readout": ({"K_max": self.ridge.K_max, "crossover": self.ridge.crossover,
                               "T_fit": self.ridge.T_fit, "lam": self.ridge.lam}
                              if self.ridge is not None else None),
            "r_thr": [round(float(x), 4) for x in self.r_thr],
            "r_dist": self.r_dist,
        }


    def seed_window(self, T=16, burn=4000, seed=42, obs=None):
        







        env = self.env
        if obs is not None:
            s = np.asarray(obs, dtype=np.float64).reshape(-1)[:env.obs_dim]
            if s.size < env.obs_dim:
                s = np.pad(s, (0, env.obs_dim - s.size), constant_values=1.0)
            xs = [s.copy()]
            cur = s.copy()
            for _ in range(T - 1):
                cur = cur - env.dt * env.deriv(cur)
                xs.append(cur.copy())
            raw = np.asarray(xs[::-1], dtype=np.float32)
            return raw, env.normalize(raw).astype(np.float32)


        rng = np.random.default_rng(int(seed))
        s = env.lo + rng.random(env.obs_dim) * (env.hi - env.lo) * 0.3 + 0.1
        for _ in range(burn):
            s = env.step(s)
        xs = []
        for _ in range(T):
            s = env.step(s)
            xs.append(s.copy())
        raw = np.asarray(xs, dtype=np.float32)
        return raw, env.normalize(raw).astype(np.float32)


    @torch.no_grad()
    def imagine(self, xn_seed, K=K_DEFAULT, M=None, path="vision"):
        




        M = self.nb_branch if M is None else int(M)
        model = self.vision if (path == "vision" and self.vision is not None) else self.chaos
        if model is None:
            return None
        dual = (path != "vision") and getattr(model, "ridge", None) is not None
        s = torch.tensor(np.asarray(xn_seed)[None], device=DEV, dtype=torch.float32)

        def _one(noise):
            return (model.rollout_dual(s, K, init_noise=noise) if dual
                    else model.forward_roll(s, K, init_noise=noise))

        if M <= 1:
            p = _one(0.0)
        else:
            acc = None
            for _ in range(M):
                r = _one(self.branch_noise)
                acc = r if acc is None else acc + r
            p = acc / M
        return p[0].cpu().numpy()

    @torch.no_grad()
    def encode_vision(self, xn_seed):
        
        if self.vision is None:
            return None
        s = torch.tensor(np.asarray(xn_seed)[None], device=DEV, dtype=torch.float32)
        z = self.vision.encode(s.reshape(-1, self.env.obs_dim))
        return {"z_norm": float(z.norm(dim=-1).mean().item()), "z_dim": int(z.shape[-1])}


    @torch.no_grad()
    def mpc_episode(self, steps=MPC_STEPS, seed=0):
        
        if self.decision is None or self.tgt is None:
            return None
        env, wm = self.env_d, self.decision
        rng = np.random.default_rng(seed)
        s = np.array([1.0, 1.0, 1.0], dtype=np.float64)
        for _ in range(4000):
            s = env.step(s)
        tgt_n = env.normalize(self.tgt).astype(np.float32)
        xs, us, errs, cost = [], [], [], 0.0
        for _ in range(steps):
            n = len(xs)
            if n == 0:
                so = env.normalize(s)[None].astype(np.float32)
                sa = np.zeros((1, 3), np.float32)
            else:
                k = min(self.t_seed, n)
                so = np.stack(xs[n - k:]).astype(np.float32)
                sa = np.stack(us[n - k:]).astype(np.float32)
            cand = rng.normal(0, 0.6, (MPC_CAND, MPC_H, 3)).clip(-1, 1)
            cand[0] = 0.0
            cand[1] = np.clip(self.kp * (self.tgt - s) / self.u_max, -1, 1)
            c = torch.tensor(cand, dtype=torch.float32, device=DEV)
            so_t = torch.tensor(so[None], device=DEV)
            sa_t = torch.tensor(sa[None], device=DEV)
            xs_t = torch.tensor(env.normalize(s)[None].astype(np.float32), device=DEV)
            pred = wm.plan_rollout(so_t, sa_t, xs_t, c)
            tn = torch.tensor(tgt_n, device=DEV)
            w_k = torch.linspace(0.5, 1.5, MPC_H, device=DEV).view(1, MPC_H, 1)
            err = ((pred - tn) ** 2).sum(-1, keepdim=True) * w_k
            ctrl = self.lam_u * (c ** 2).sum(-1, keepdim=True)
            J = (err + ctrl).sum(1)[:, 0]
            u = cand[int(J.argmin()), 0] * self.u_max
            xs.append(env.normalize(s).astype(np.float32))
            us.append((u / self.u_max).astype(np.float32))
            for _ in range(self.sub):
                s = env.step(s, u)
            errs.append(float(np.linalg.norm(s - self.tgt)))
            cost += float((u ** 2).sum())
        errs = np.asarray(errs)
        return {"tail": float(errs[-30:].mean()), "mean": float(errs.mean()),
                "final": float(errs[-1]), "ctrl": float(cost / steps),
                "steps": steps, "target": self.tgt.tolist()}


    @staticmethod
    def speak(wave, judge, max_new=60):
        try:
            import importlib
            ac = importlib.import_module("agent_core")
            return ac.ask(wave, judge, max_new=max_new)
        except Exception as e:
            return (f"当前{wave}，预测后续轨迹短期"
                    f"{'难以精确收敛' if '发散' in wave else '会保持在吸引子内'}。"
                    f"判断：{judge}。建议：保持观察，不干预。"
                    f"（语言脑不可用：{str(e)[:60]}）")



def _describe(pred_raw, env, thr=None):
    




    t1, t2 = thr if thr else (0.35, 0.75)
    p = np.asarray(pred_raw)
    disp = float(np.linalg.norm(p[-1] - p[0]))
    span = float(np.linalg.norm(np.asarray(env.hi) - np.asarray(env.lo)))
    r = disp / max(span, 1e-6)
    if r < t1:
        return "波动不大", "系统平稳"
    if r < t2:
        return "波动正在加大", "进入不稳定窗口"
    return "轨迹快速发散", "当前处于敏感区域"


def _parse_obs(text):
    
    if not text:
        return None
    for key in ("obs=", "观测=", "x="):
        if key in text:
            seg = text.split(key, 1)[1].split()[0].split("；")[0].split(";")[0]
            parts = [p for p in seg.replace("，", ",").split(",") if p.strip()]
            try:
                v = [float(p) for p in parts[:3]]
                if len(v) == 3:
                    return np.asarray(v, dtype=np.float64)
            except Exception:
                return None
    return None



def get_suite():
    
    global _SUITE
    with _LOCK:
        if _SUITE is None:
            _SUITE = WorldModelV2().load()
        return _SUITE


def run(text="", K=K_DEFAULT, M=None, with_mpc=True, max_new=60):
    
    t0 = time.time()
    suite = get_suite()
    st = suite.status()
    if suite.env is None:
        return {"ok": False, "error": f"世界模型权重缺失: {suite.missing}（先跑 train_wm_v2.py）",
                "status": st, "elapsed_ms": round((time.time() - t0) * 1000, 1)}

    obs = _parse_obs(text)
    raw, xn = suite.seed_window(obs=obs)


    pred_v = suite.imagine(xn, K=K, M=M, path="vision")
    pred_c = suite.imagine(xn, K=K, M=M, path="code")
    pred = pred_v if pred_v is not None else pred_c
    pred_raw = suite.env.denormalize(pred)


    enc = suite.encode_vision(xn)





    p_long = suite.imagine(xn, K=K_WAVE, M=1, path="code")
    p_long_raw = suite.env.denormalize(p_long) if p_long is not None else pred_raw
    wave, judge = _describe(p_long_raw, suite.env, thr=suite.r_thr)
    speech = suite.speak(wave, judge, max_new=max_new)





    ens_spread = None
    try:
        ch = suite.chaos
        if ch is not None:
            s = torch.tensor(np.asarray(xn)[None], device=DEV, dtype=torch.float32)
            branches = []
            for _ in range(NB_BRANCH):
                with torch.no_grad():
                    if getattr(ch, "ridge", None) is not None:
                        q = ch.rollout_dual(s, K_WAVE, init_noise=BRANCH_NOISE,
                                            noise_after_seed=True)
                    else:
                        q = ch.forward_roll(s, K_WAVE, init_noise=BRANCH_NOISE,
                                            noise_after_seed=True)
                branches.append(q[0].cpu().numpy())
            A = np.stack(branches)
            ref = A.mean(0, keepdims=True)
            span = max(float(np.linalg.norm(suite.env.hi - suite.env.lo)), 1e-6)
            ens_spread = float(np.linalg.norm(A[:, -1] - ref[:, -1], axis=-1).mean() / span)
    except Exception:
        ens_spread = None


    mpc = suite.mpc_episode() if with_mpc else None

    result = speech
    if mpc:
        result += (f" [MPC-LSTM 闭环 {mpc['steps']} 步：末段误差 {mpc['tail']:.2f}，"
                   f"平均 {mpc['mean']:.2f}，控制代价 {mpc['ctrl']:.0f}]")

    return {
        "ok": True, "text": text, "wave": wave, "judge": judge, "result": result,

        "wave_basis": WAVE_BASIS, "wave_validated": WAVE_VALIDATED,
        "ens_spread": ens_spread,
        "signal_audit": {
            "r_free_auc_controlled": 0.406,
            "r_act_zero_auc_crossfunctional": 0.406,
            "ens_chaos_auc_multienv_lyap": [0.473, 0.488],
            "ens_lstm_auc_multienv_lyap": [0.561, 0.637],
            "verdict": "no validated risk detector; see WM_V2_AUDIT_PROBE_AUC_2026-09-10.md",
        },
        "pred_raw": pred_raw.tolist(), "pred_code_raw": suite.env.denormalize(pred_c).tolist() if pred_c is not None else None,
        "divergence": float(np.linalg.norm(pred_raw[-1] - pred_raw[0])),
        "divergence_ratio": float(np.linalg.norm(pred_raw[-1] - pred_raw[0])
                                  / max(float(np.linalg.norm(suite.env.hi - suite.env.lo)), 1e-6)),
        "divergence_long": float(np.linalg.norm(p_long_raw[-1] - p_long_raw[0])),
        "wave_ratio": float(np.linalg.norm(p_long_raw[-1] - p_long_raw[0])
                            / max(float(np.linalg.norm(suite.env.hi - suite.env.lo)), 1e-6)),
        "wave_thr": [float(x) for x in suite.r_thr], "K_wave": K_WAVE,
        "vision_enc": enc, "mpc": mpc, "status": st,
        "branch": {"M": (suite.nb_branch if M is None else M), "noise": suite.branch_noise},
        "elapsed_ms": round((time.time() - t0) * 1000, 1),
    }


def answer(text="", **kw):
    
    r = run(text, **kw)
    return (r.get("result", r.get("error", "")), r)


if __name__ == "__main__":
    s = get_suite()
    print("status:", json.dumps(s.status(), ensure_ascii=False))
    out = run("轨迹快速发散 obs=1.0,2.0,3.0", with_mpc=True)
    print(json.dumps({k: v for k, v in out.items() if k not in ("pred_raw", "pred_code_raw")},
                     ensure_ascii=False, indent=1))
    print("\n文本输出：", out.get("result"))
