#!/usr/bin/env python3
















import glob
import hashlib
import os
import sys
from collections import Counter

ROOT = os.path.dirname(os.path.abspath(__file__))
DST = os.path.join(ROOT, "data", "corpus_docs.txt")
MD_SRC = r"F:/AGI/AGI"
TARGET = 900_000


MIN_UNIQ_RATIO = 0.30
MIN_CHARS = 50_000


def quality(path):
    try:
        t = open(path, encoding="utf-8", errors="replace").read()
    except Exception as e:
        return {"path": path, "error": type(e).__name__}
    lines = [l for l in t.split("\n") if l.strip()]
    uniq = len(set(lines))
    ratio = uniq / max(len(lines), 1)
    return {"path": path, "chars": len(t), "vocab": len(set(t)),
            "lines": len(lines), "uniq_lines": uniq, "ratio": ratio,
            "ok": ratio >= MIN_UNIQ_RATIO and len(t) >= MIN_CHARS}


def build():
    srcs = sorted(glob.glob(os.path.join(MD_SRC, "**", "*.md"), recursive=True))
    seen, chunks, total = set(), [], 0
    for f in srcs:
        try:
            if os.path.getsize(f) < 800:
                continue
            t = open(f, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        h = hashlib.md5(t.encode("utf-8", "replace")).hexdigest()
        if h in seen:
            continue
        seen.add(h)

        keep = [l for l in t.split("\n")
                if len(l) < 400 and not l.startswith("|")]
        t = "\n".join(keep)
        if len(t) < 500:
            continue
        chunks.append(t)
        total += len(t)
        if total >= TARGET:
            break
    text = "\n\n".join(chunks)
    os.makedirs(os.path.dirname(DST), exist_ok=True)
    with open(DST, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"构建 {DST}")
    print(f"  源文件 {len(srcs)} 个 md → 去重后采用 {len(chunks)} 个｜总字符 {len(text):,}")
    return DST


def main():
    if "check" not in sys.argv:
        build()
    print("\n" + "=" * 78)
    print("语料质量门禁")
    print("=" * 78)
    print(f"  {'语料':<22}{'字符':>10}{'vocab':>8}{'行数':>9}{'行去重率':>10}  判定")
    cands = ["corpus_code.txt", "corpus_docs.txt", "chaos_qa_big.txt",
             "chaos_qa_med.txt", "corpus.txt", "corpus_onefile.txt"]
    bad = []
    for name in cands:
        p = os.path.join(ROOT, "data", name)
        if not os.path.exists(p):
            continue
        q = quality(p)
        if "error" in q:
            print(f"  {name:<22}{'—':>10}  ERR {q['error']}")
            continue
        flag = "✅ 可用" if q["ok"] else "❌ **坏语料（重复率过高/过短）**"
        print(f"  {name:<22}{q['chars']:>10,}{q['vocab']:>8}{q['lines']:>9}"
              f"{q['ratio']:>10.3f}  {flag}")
        if not q["ok"]:
            bad.append(name)
    if bad:
        print(f"\n  ⚠ 以下语料**禁止**用于跨域实验：{', '.join(bad)}")
        print(f"     判据：行去重率 ≥ {MIN_UNIQ_RATIO} 且字符数 ≥ {MIN_CHARS:,}")


if __name__ == "__main__":
    main()
