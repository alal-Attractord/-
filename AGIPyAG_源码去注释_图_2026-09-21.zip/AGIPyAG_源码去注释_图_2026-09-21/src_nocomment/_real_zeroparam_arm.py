




















import os
import sys
import json
import numpy as np

sys.path.insert(0, r'F:\ASI')
import _real_param_champion as PC

DS = PC.DS
OUT = r'F:\ASI\_real_zeroparam_arm.json'
SRC = r'F:\ASI\_real_param_champion.json'
FORMS = {
    'persist': lambda L: L[:, 0],
    'diff1': lambda L: 2.0 * L[:, 0] - L[:, 1],
    'diff2': lambda L: 3.0 * L[:, 0] - 3.0 * L[:, 1] + L[:, 2],
}


def main():
    ref = json.load(open(SRC, encoding='utf-8')) if os.path.exists(SRC) else {}
    out = {}
    print('=' * 96)
    print('零参数外推基线 (persist / diff1 / diff2) —— 无拟合, 固定公式, M 在 val 上选')
    print('=' * 96)
    hdr = ('%-12s %5s %4s %10s %10s %10s | %8s %8s %8s'
           % ('图', 'dt', 'ch', 'persist', 'diff1', 'diff2', 'p/kNN', 'd1/kNN', 'd2/kNN'))
    print(hdr)
    print('-' * len(hdr))
    rows = []
    for n, dts in PC.PLAN.items():
        out.setdefault(n, {})
        for dt in dts:
            key = '%g' % dt
            Zs, cols, tr, va, te, stride, T = PC.load_config(n, dt)
            chans = PC.pick_target_channels(Zs, PC.N_CH)
            packs_all = {}
            recs = []
            for c in chans:
                x = Zs[:, int(c)]
                packs = PC.make_packs(x, tr, va, te)
                if not packs:
                    continue
                rec = {'ycol': int(c)}
                for tag, fn in FORMS.items():
                    bv, bt, bm = float('inf'), None, None
                    for m, (A, ya, B, yb, Cc, yc) in packs.items():
                        if m < {'persist': 1, 'diff1': 2, 'diff2': 3}[tag]:
                            continue
                        v = PC.mse(fn(B), yb)
                        if v < bv:
                            bv, bt, bm = v, PC.mse(fn(Cc), yc), m
                    rec[tag] = dict(test=(None if bt is None else float(bt)),
                                    val=float(bv), M=(None if bm is None else int(bm)))

                kk = ((ref.get(n, {}).get(key, {}) or {}).get('channels') or [])
                match = [r0 for r0 in kk if int(r0.get('ycol', -1)) == int(c)]
                rec['knn_loclin_test'] = (match[0].get('knn_loclin', {}) or {}).get('test') \
                    if match else None
                recs.append(rec)
                k = rec['knn_loclin_test']
                print('%-12s %5g %4d %10.4e %10.4e %10.4e | %8s %8s %8s'
                      % (n, dt, int(c), rec['persist']['test'], rec['diff1']['test'],
                         rec['diff2']['test'],
                         ('%.3f' % (rec['persist']['test'] / k)) if k else '—',
                         ('%.3f' % (rec['diff1']['test'] / k)) if k else '—',
                         ('%.3f' % (rec['diff2']['test'] / k)) if k else '—'))
            out[n][key] = dict(name=n, dt_h=float(dt),
                               chans=[int(c) for c in chans], channels=recs)
            for tag in FORMS:
                v = np.array([r[tag]['test'] / r['knn_loclin_test'] for r in recs
                              if r['knn_loclin_test'] and r[tag]['test']])
                if v.size:
                    rows.append((tag, v))
                    print('  -> %s dt=%g  %s 相对冠军: n=%d 中位 %.3f 均值 %.3f 最小 %.3f 最大 %.3f'
                          % (n, dt, tag, v.size, np.median(v), v.mean(), v.min(), v.max()))
            print('-' * len(hdr))
    json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('\n池化 (跨全部 %d 条记录):' % len(rows and rows[0][1]))
    for tag in FORMS:
        v = np.concatenate([a for t, a in rows if t == tag])
        print('  %-8s n=%3d 中位 %.4f 均值 %.4f 最小 %.4f 最大 %.4f  <=1 占比 %.0f%%'
              % (tag, v.size, np.median(v), v.mean(), v.min(), v.max(),
                 100 * (v <= 1).mean()))
    print('saved ->', OUT)


if __name__ == '__main__':
    main()
