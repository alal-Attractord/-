#!/usr/bin/env python3




























import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import koopman_engine as KE
import wm_v2 as W

DEV = KE.DEV


class K3Forecaster:
    

    def __init__(self, backbone="koopman_fix"):
        eng = KE.get_engine()
        eng.load()
        if not eng.ready:
            raise RuntimeError(f"K3 权重缺失：{eng.missing}")
        self.eng = eng
        self.backbone = backbone if backbone in eng.models else eng.active
        self.model = eng.models[self.backbone]["model"]
        self.env = eng.env
        self.mu = torch.tensor(self.env.mu, dtype=torch.float32, device=DEV)
        self.sd = torch.tensor(self.env.sd, dtype=torch.float32, device=DEV)
        self.param_count = sum(p.numel() for p in self.model.parameters())
        self.adapt_log = []


    def _norm(self, raw):
        x = torch.as_tensor(raw, dtype=torch.float32, device=DEV)
        return (x - self.mu) / (self.sd + 1e-8)

    def _denorm(self, xn):
        return xn * (self.sd + 1e-8) + self.mu


    @torch.no_grad()
    def predict(self, x_window, horizons=(1, 5, 20)):
        
        xn = self._norm(x_window)
        if xn.dim() == 2:
            xn = xn[None]
        out = self.model.forward_roll(xn, max(horizons))
        pred = self._denorm(out)[0]
        return {h: pred[h - 1].cpu().numpy() for h in horizons if h <= pred.shape[0]}

    @torch.no_grad()
    def one_step_rmse(self, raw_traj, T=16, stride=4):
        
        xn = self._norm(raw_traj).cpu().numpy() if torch.is_tensor(raw_traj) else \
            self.env.normalize(np.asarray(raw_traj, dtype=np.float64))
        xn = torch.tensor(xn, dtype=torch.float32, device=DEV)
        errs = []
        for i in range(0, len(xn) - T - 1, stride):
            seed = xn[i:i + T][None]
            p = self.model.forward_roll(seed, 1)[0, 0]
            errs.append(float(((p - xn[i + T]) ** 2).mean().sqrt()))
        return float(np.mean(errs)) if errs else float("nan")


    def adapt(self, x_stream, alpha=0.03, window=64, ridge=1e-3):
        




        t0 = time.perf_counter()
        x = torch.as_tensor(np.asarray(x_stream), dtype=torch.float32, device=DEV)
        if x.dim() == 2:
            x = x[None]
        with torch.no_grad():
            Z = self.model._lift(self._norm(x))[0]
            Zc, Zn = Z[:-1][-window:], Z[1:][-window:]
            D = self.model.D
            A = Zc.T @ Zc + ridge * torch.eye(D, device=Zc.device)
            B = Zn.T @ Zc
            K_ls = torch.linalg.solve(A, B.T).T
            before = self.model.K0.detach().clone()



            s = before.norm() / (K_ls.norm() + 1e-9)
            K_ls = K_ls * s
            cos = float((before.flatten() @ K_ls.flatten()) /
                        (before.norm() * K_ls.norm() + 1e-9))
            self.model.K0.data.copy_((1.0 - alpha) * before + alpha * K_ls)
            drift = float((self.model.K0.data - before).norm() /
                          (before.norm() + 1e-9))
        ms = (time.perf_counter() - t0) * 1000.0
        rec = {"update_ms": round(ms, 4), "drift": round(drift, 5),
               "cos_to_before": round(cos, 4), "n_pairs": int(len(Zc))}
        self.adapt_log.append(rec)
        return rec

    def snapshot(self):
        
        return self.model.K0.detach().clone()

    def restore(self, snap):
        with torch.no_grad():
            self.model.K0.data.copy_(snap)


    @torch.no_grad()
    def spectrum(self, x_last):
        





        x = torch.as_tensor(np.asarray(x_last), dtype=torch.float32, device=DEV)
        K = self.model.raw_K(self._norm(x)).cpu().numpy()
        lam = np.linalg.eigvals(K)
        mod, ang = np.abs(lam), np.angle(lam)
        order = np.argsort(-mod)
        return {
            "n_modes": int(len(lam)),
            "rho_mean": round(float(mod.mean()), 6),
            "rho_max": round(float(mod.max()), 6),

            "imag_frac": round(float((np.abs(ang) > 0.1).mean()), 4),
            "top5_modulus": [round(float(v), 4) for v in mod[order[:5]]],
            "top3_freq_rad": [round(float(abs(ang[i])), 4) for i in order[:3]],
            "decay_time_steps": [round(float(-1.0 / np.log(max(m, 1e-9))), 2)
                                 for m in mod[order[:3]]],
        }


    def spec(self):
        ck = self.eng.models[self.backbone]["ckpt"]
        return {
            "product": "K3 Forecaster",
            "backbone": self.backbone,
            "params": self.param_count,
            "size_kb_fp32": round(self.param_count * 4 / 1024, 1),
            "env": self.eng.meta.get("env"),
            "metrics": ck.get("metrics", {}),
            "capabilities": ["短程多视界预测", "在线适应（无重训）", "谱可解释输出"],
        }



def env_with_rho(rho):
    
    e = W.get_env("Lorenz")
    e.rho = float(rho)
    return e


def demo():
    f = K3Forecaster("koopman_fix")
    sp = f.spec()
    print("=" * 74)
    print(f"{sp['product']} · {sp['backbone']}")
    print("=" * 74)
    print(f"  参数量 {sp['params']:,}（{sp['size_kb_fp32']} KB fp32）｜环境 {sp['env']}")
    print(f"  已验证指标：{sp['metrics']}")

    rng = np.random.default_rng(7)
    s0 = np.array([1.0, 1.0, 1.0])


    traj_a = f.env.simulate(900, s0, rng=rng)
    base = f.one_step_rmse(traj_a)
    print(f"\n[阶段 1] 训练分布内（rho=28）      @1 RMSE = {base:.5f}")


    env_drift = env_with_rho(45.0)
    traj_b = env_drift.simulate(900, s0, rng=rng)
    drift_err = f.one_step_rmse(traj_b)
    print(f"[阶段 2] 环境漂移（rho=28→45）    @1 RMSE = {drift_err:.5f}"
          f"   ← 退化 {drift_err / base:.2f}×")


    snap = f.snapshot()
    f.adapt(traj_b[:200])
    t0 = time.perf_counter()
    recs = [f.adapt(traj_b[i:i + 200]) for i in range(0, 900, 90)]
    wall = (time.perf_counter() - t0) * 1000
    adapted = f.one_step_rmse(traj_b)
    print(f"[阶段 3] 在线适应（{len(recs)} 次更新，共 {wall:.1f} ms，"
          f"单次均值 {np.mean([r['update_ms'] for r in recs]):.2f} ms）")
    print(f"         算子漂移 {np.mean([r['drift'] for r in recs]):.4f}"
          f"｜与旧算子余弦相似 {np.mean([r['cos_to_before'] for r in recs]):.4f}")
    print(f"         单轮适应后            @1 RMSE = {adapted:.5f}"
          f"   ← 相对漂移后 {drift_err / adapted:.2f}×")
    for _ in range(6):
        for i in range(0, 900, 150):
            f.adapt(traj_b[i:i + 200], alpha=0.25)
    conv = f.one_step_rmse(traj_b)
    print(f"         多轮收敛后            @1 RMSE = {conv:.5f}"
          f"   ← 相对漂移后 {drift_err / conv:.2f}×")

    print(f"\n  适应效果：{drift_err:.5f} → {adapted:.5f}"
          f"（降 {(1 - adapted / drift_err) * 100:.1f}%）")
    print(f"  适应过程无任何反向传播、无重训；单次更新仅一次 D×D 线性求解")


    print("\n" + "-" * 74)
    print("谱输出（对手没有的机制）")
    print("-" * 74)
    for label, traj in (("漂移前", traj_a), ("适应后", traj_b)):
        s = f.spectrum(traj[-1])
        print(f"  {label}：模态 {s['n_modes']}｜ρ̄={s['rho_mean']:.4f}"
              f"｜振荡模态占比 {s['imag_frac']:.1%}"
              f"｜主模态衰减步数 {s['decay_time_steps']}")

    print(f"\n  ⇒ imag_frac 表示有多少模态是**振荡型**（复共轭对），")
    print(f"     decay_time_steps 直接给出每个模式衰减到 1/e 需要多少步 ——")
    print(f"     这两个量 Transformer 的注意力矩阵**没有对应的物理含义**。")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "demo"
    if mode == "spec":
        print(json.dumps(K3Forecaster().spec(), ensure_ascii=False, indent=1))
    else:
        demo()
