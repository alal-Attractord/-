






























































import math
import time
import numpy as np
import torch
import torch.nn as nn





class SharedBasis(nn.Module):
    

    def __init__(self, n, shear_init=1e-3, seed=0):
        super().__init__()
        self.n = n
        g = torch.Generator().manual_seed(seed)
        A = torch.randn(n, n, generator=g, dtype=torch.float64)
        Q, _ = torch.linalg.qr(A)
        self.register_buffer('Q', Q)
        self.L = nn.Parameter(torch.tril(
            shear_init * torch.randn(n, n, generator=g, dtype=torch.float64), -1))

    def V(self):
        return self.Q @ (torch.eye(self.n, dtype=torch.float64, device=self.L.device) + self.L)

    def invV(self):
        return torch.linalg.inv(self.V())

    def kappa2(self):
        
        with torch.no_grad():
            M = (torch.eye(self.n, dtype=torch.float64, device=self.L.device) + self.L)
            s = torch.linalg.svdvals(M)
            return float(s[0] / s[-1])

    def ftle_bracket_width(self, H):
        
        return math.log(self.kappa2()) / float(H)





class SpectralManifold(nn.Module):
    





    def __init__(self, n, d, m=3, log_lam_scale=0.5, seed=0):
        super().__init__()
        assert n % 2 == 0, 'n 必须是偶数（复共轭成对）'
        self.n, self.d, self.m, self.p = n, d, m, n // 2
        g = torch.Generator().manual_seed(seed + 1)

        self.a0 = nn.Parameter(torch.empty(self.p, dtype=torch.float64)
                               .uniform_(-0.05, 0.0, generator=g))
        self.b0 = nn.Parameter(torch.empty(self.p, dtype=torch.float64)
                               .uniform_(0.0, math.pi / 3.0, generator=g))
        self.ea = nn.Parameter(log_lam_scale * torch.randn(self.m, self.p,
                                                           generator=g, dtype=torch.float64))
        self.eb = nn.Parameter(log_lam_scale * torch.randn(self.m, self.p,
                                                           generator=g, dtype=torch.float64))
        self.w = nn.Parameter(0.5 * torch.randn(self.m, d, generator=g,
                                                dtype=torch.float64))
        self.c = nn.Parameter(torch.zeros(self.m, dtype=torch.float64))

    def gate(self, z):
        return torch.tanh(z @ self.w.T + self.c)

    def log_lam(self, z):
        gz = self.gate(z)
        a = self.a0 + gz @ self.ea
        b = self.b0 + gz @ self.eb
        return a, b

    def blocks(self, z):
        
        a, b = self.log_lam(z)
        r = torch.exp(a)
        ca, sa = torch.cos(b), torch.sin(b)
        z0 = torch.zeros_like(r)
        blk = torch.stack([torch.stack([r * ca, -r * sa], -1),
                           torch.stack([r * sa, r * ca], -1)], -2)
        assert blk.shape[-2:] == (2, 2) and z0.shape == r.shape
        return blk





class SCSO(nn.Module):
    def __init__(self, n, d=2, m=3, hidden=32, shear_init=1e-3, seed=0):
        super().__init__()
        self.n, self.d, self.m = n, d, m
        self.basis = SharedBasis(n, shear_init=shear_init, seed=seed)
        self.spec = SpectralManifold(n, d, m=m, seed=seed)
        g = torch.Generator().manual_seed(seed + 2)

        Wr, _ = torch.linalg.qr(torch.randn(n, d, generator=g, dtype=torch.float64))
        self.Wr = nn.Parameter(Wr.T.contiguous())

        self.Bm = nn.Parameter(0.01 * torch.randn(n, hidden, generator=g,
                                                  dtype=torch.float64))
        self.Cm = nn.Parameter(0.05 * torch.randn(hidden, d, generator=g,
                                                  dtype=torch.float64))
        self.b0 = nn.Parameter(torch.zeros(n, dtype=torch.float64))


    def readout(self, h):
        return torch.tanh(h @ self.Wr.T)


    def forward(self, h):
        
        z = self.readout(h)
        V, Vi = self.basis.V(), self.basis.invV()
        blk = self.spec.blocks(z)

        u = h @ Vi.T
        u = u.view(-1, self.spec.p, 2)
        y = torch.einsum('bpij,bpj->bpi', blk, u).reshape(-1, self.n)
        out = y @ V.T
        out = out + torch.tanh(z @ self.Cm.T) @ self.Bm.T + self.b0
        return out


    @torch.no_grad()
    def spectrum(self, h):
        z = self.readout(h)
        a, b = self.spec.log_lam(z)
        lam = torch.complex(torch.exp(a), torch.zeros_like(a))
        lam = torch.complex(torch.exp(a) * torch.cos(b), torch.exp(a) * torch.sin(b))
        return lam

    def n_params(self):
        return sum(p.numel() for p in self.parameters() if p.requires_grad)





def _dt(x):
    return torch.tensor(np.asarray(x), dtype=torch.float64)


def selfcheck(n=16, d=2, m=3, seed=0, verbose=True):
    torch.manual_seed(seed)
    op = SCSO(n, d=d, m=m, seed=seed)
    out = []

    def log(s):
        out.append(s)
        if verbose:
            print(s)

    log('=' * 92)
    log('SCSO 自检  n=%d d=%d m=%d seed=%d' % (n, d, m, seed))
    log('=' * 92)


    h = torch.randn(8, n, dtype=torch.float64)
    y = op(h)
    log('[1] 前向形状        : %s -> %s   dtype=%s  (实数)' %
        (tuple(h.shape), tuple(y.shape), y.dtype))
    assert y.shape == h.shape and not torch.is_complex(y)


    log('[2] 参数量          : %d   (n=%d, m=%d, d=%d)' % (op.n_params(), n, m, d))
    log('    其中基的剪切自由度 n(n-1)/2 = %d，谱方向 n·m = %d' % (n * (n - 1) // 2, n * m))


    k0 = op.basis.kappa2()
    log('[3] κ₂(V) 初值       : %.6f   （=1 ⇒ 正规；越大 ⇒ ρ 越不可信）' % k0)
    log('    (1/H)logκ₂ 误差条 : H=1 → %.4f, H=100 → %.4f' %
        (op.basis.ftle_bracket_width(1), op.basis.ftle_bracket_width(100)))
    with torch.no_grad():
        op.basis.L.mul_(2000.0)
        k1 = op.basis.kappa2()
        op.basis.L.div_(2000.0)
    log('    放大剪切×2000 后 κ₂: %.6f  (验证 κ₂ 完全由 L 控制, 与 Q 无关)' % k1)
    log('    ⇒ κ₂(I+L) 是"单位下三角"的条件数, 随 ‖L‖ 增长但**不指数级**'
        '（det=1 恒成立）⇒ 可用作显式预算约束')
    assert k1 > k0 * 5




    with torch.no_grad():
        op.basis.L.mul_(400.0)
        V = op.basis.V()
        k2 = op.basis.kappa2()
        z = op.readout(torch.randn(64, n, dtype=torch.float64))
        blk = op.spec.blocks(z[0:1])[0]
        D = torch.zeros(n, n, dtype=torch.float64)
        for i in range(n // 2):
            D[2 * i:2 * i + 2, 2 * i:2 * i + 2] = blk[i]
        K = V @ D @ torch.linalg.inv(V)
        ev = torch.linalg.eigvals(K)
        rho, rmin = float(ev.abs().max()), float(ev.abs().min())
        H = 20
        P = torch.linalg.matrix_power(K, H)
        lo = math.log(rmin) - math.log(k2) / H
        hi = math.log(rho) + math.log(k2) / H
        logg, n_viol_br, n_over_rho = [], 0, 0
        g = torch.Generator().manual_seed(7)
        for _ in range(2000):
            v = torch.randn(n, generator=g, dtype=torch.float64)
            v = v / v.norm()
            per = math.log(float((P @ v).norm())) / H
            logg.append(per)
            if per < lo - 1e-9 or per > hi + 1e-9:
                n_viol_br += 1
            if per > math.log(rho) + 1e-9:
                n_over_rho += 1
        logg = np.array(logg)
        log('[4] ρ 只给下界 —— 数值验证本项目定理（κ₂=%.2f, H=%d）' % (k2, H))
        log('    log ρ = %.6f   (=log|λ|max, ρ 给出的每步增长率)' % math.log(rho))
        log('    log|λ|min = %.6f ; 误差条 (1/H)logκ₂ = %.6f' %
            (math.log(rmin), math.log(k2) / H))
        log('    定理区间 = [%.6f, %.6f]' % (lo, hi))
        log('    实测 2000 个随机 v 的每步增长率: 中位 %.6f  最大 %.6f  最小 %.6f' %
            (np.median(logg), logg.max(), logg.min()))
        log('    ⇒ 越出定理区间次数 = %d / 2000  （应为 0）' % n_viol_br)
        log('    ⇒ ρ 低估真实增长的比例 = %.1f%%  (>0 即证明"ρ 只给下界")'
            % (100.0 * n_over_rho / 2000))
        assert n_viol_br == 0
        assert n_over_rho > 0, 'κ₂ 不够大, 未能展示 ρ 的欠估 —— 增大剪切再试'
        op.basis.L.div_(400.0)


    h0 = torch.randn(400, n, dtype=torch.float64)
    eps = 1e-6
    g = torch.Generator().manual_seed(11)
    dirv = torch.randn(400, n, generator=g, dtype=torch.float64)
    dirv = dirv / dirv.norm(dim=1, keepdim=True)
    with torch.no_grad():
        y0 = op(h0)
        y1 = op(h0 + eps * dirv)
        jump = (y1 - y0).norm(dim=1) / eps
    maxj, medj = float(jump.max()), float(jump.median())
    log('[5] Lipschitz 探针   : 中位 %.3f  最大 %.3f  最大/中位 = %.2f' %
        (medj, maxj, maxj / max(medj, 1e-12)))
    log('    （硬分段算子在分区边界处该比值会爆到 1e3~1e6；本算子处处光滑 ⇒ 应 ~O(1)）')
    assert maxj / max(medj, 1e-12) < 20.0


    op.zero_grad()
    hh = torch.randn(64, n, dtype=torch.float64, requires_grad=False)
    yy = torch.randn(64, n, dtype=torch.float64)
    loss = ((op(hh) - yy) ** 2).mean()
    loss.backward()
    dead = [nm for nm, p in op.named_parameters()
            if p.requires_grad and (p.grad is None or not torch.isfinite(p.grad).all())]
    zero = [nm for nm, p in op.named_parameters()
            if p.requires_grad and p.grad is not None and float(p.grad.abs().max()) == 0.0]
    log('[6] 梯度            : loss=%.6f  非有限/无梯度参数=%s  零梯度参数=%s'
        % (float(loss.detach()), dead or '无', zero or '无'))
    assert not dead


    op_full = SCSO(n, d=d, m=n // 2, seed=seed)
    log('[7] 消融臂 m=n/2     : 参数量 %d（本臂 m=%d 时 %d）'
        % (op_full.n_params(), m, op.n_params()))
    log('    ⇒ 明日实验必须跑这个对照；若 m=n/2 不更差，"谱流形"这一归纳偏置判负。')



    with torch.no_grad():
        hb = torch.randn(1000, n, dtype=torch.float64)
        op(hb[:10])
        t0 = time.perf_counter()
        op(hb)
        ms = (time.perf_counter() - t0) * 1e3
    log('[8] 推理耗时        : %.4f ms / 1000 次预测   （对照: kNN 局部仿射冠军 139.99 ms/1000）' % ms)
    log('    推理是否需要参考数据: 否（参数量固定 %d，不含任何训练样本）' % op.n_params())





    with torch.no_grad():
        op.basis.L.mul_(80.0)
    hb = torch.randn(6, n, dtype=torch.float64, requires_grad=True)
    smax_list, rho_list = [], []
    for i in range(hb.shape[0]):
        h1 = hb[i:i + 1]
        J = torch.autograd.functional.jacobian(lambda v: op(v), h1, vectorize=True)[0]
        smax_list.append(float(torch.linalg.svdvals(J)[0]))
        with torch.no_grad():
            z1 = op.readout(h1)
            a1, _ = op.spec.log_lam(z1)
            rho_list.append(float(torch.exp(a1).max()))
    with torch.no_grad():
        op.basis.L.div_(80.0)
    smax = np.array(smax_list)
    rho_a = np.array(rho_list)
    log('[9] ★铁律 41 自审 —— 约束作用在真实对象上了吗？')
    log('    名义被约束量          : κ₂(V) = %.4f（初值 1.0067）' % op.basis.kappa2())
    log('    真实对象 σ_max(∂h′/∂h) : 中位 %.4f  最大 %.4f' % (np.median(smax), smax.max()))
    log('    名义谱半径 ρ(K)       : 中位 %.4f  最大 %.4f' % (np.median(rho_a), rho_a.max()))
    log('    ⇒ σ_max(J)/ρ : 中位 %.3f  最大 %.3f  %s'
        % (np.median(smax / rho_a), (smax / rho_a).max(),
           '⚠ >1 ⇒ 名义谱半径低估真实局部放大（与本项目历史一致）'
           if (smax / rho_a).max() > 1.0 else '（≤1）'))
    log('    ⇒ 明天报稳定性时必须报 σ_max(J)，不能只报 ρ 或 κ₂(V)。')

    log('=' * 92)
    log('自检全部通过（1–9）。')
    return '\n'.join(out)





def smoke(steps=400, n=16, d=2, m=3, seed=0, lr=3e-3, verbose=True):
    torch.manual_seed(seed)

    dt = 0.05
    T = 8000
    x = np.zeros((T, 3), dtype=np.float64)
    x[0] = [1.0, 1.0, 1.0]
    a, b, c = 0.2, 0.2, 5.7
    for t in range(T - 1):
        p = x[t]
        x[t + 1] = p + dt * np.array([-p[1] - p[2], p[0] + a * p[1], b + p[2] * (p[0] - c)])
    s = x[:, 0]
    s = (s - s.mean()) / (s.std() + 1e-12)
    L = np.stack([s[n - 1 - j: len(s) - 1 - j] for j in range(n)], axis=1)
    y = s[n:]
    ntr = int(0.7 * len(L))
    A, B = _dt(L[:ntr]), _dt(L[ntr:])
    ya, yb = _dt(y[:ntr]), _dt(y[ntr:])

    op = SCSO(n, d=d, m=m, seed=seed)
    opt = torch.optim.AdamW([p for p in op.parameters() if p.requires_grad],
                            lr=lr, weight_decay=1e-6)
    t0 = time.perf_counter()
    hist = []
    for it in range(steps):
        opt.zero_grad()
        pred = op(A)
        loss = ((pred[:, 0] - ya) ** 2).mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_([p for p in op.parameters() if p.requires_grad], 1.0)
        opt.step()
        if it % 50 == 0 or it == steps - 1:
            hist.append((it, float(loss.detach())))
            if verbose:
                print('  step %4d  train MSE %.6e   κ₂=%.4f' % (it, float(loss), op.basis.kappa2()))
    with torch.no_grad():
        te = float(((op(B)[:, 0] - yb) ** 2).mean())
        pers = float(((B[:, 0] - yb) ** 2).mean())
    el = time.perf_counter() - t0
    print('  ---- 冒烟结果 ----')
    print('  train MSE 起 %.4e → 终 %.4e' % (hist[0][1], hist[-1][1]))
    print('  test  MSE @1        = %.6e' % te)
    print('  persist 基线 test   = %.6e   ⇒ 比值 %.4f' % (pers, te / pers))
    print('  κ₂(V)              = %.4f   ⇒ (1/H)logκ₂ = %.5f' %
          (op.basis.kappa2(), op.basis.ftle_bracket_width(100)))
    print('  参数量             = %d' % op.n_params())
    print('  用时               = %.1f s (CPU)' % el)
    print('  ★ 这不是判决实验，只证明算子可训练、可收敛、κ₂ 可控。')
    return dict(test=te, persist=pers, ratio=te / pers, kappa2=op.basis.kappa2(),
                params=op.n_params(), secs=el)


if __name__ == '__main__':
    import sys
    if '--smoke' in sys.argv:
        smoke()
    else:
        selfcheck()
