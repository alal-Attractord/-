



























import os
import sys
import json
import time
import math
import numpy as np

sys.path.insert(0, r'F:\ASI')
import torch
import torch.nn as nn

import realdata as RD
import _real_dyn_scan as DS
import _real_param_champion as PC
from core_operator import SCSO

OUT_H1 = r'F:\ASI\_real_scso_h1.json'
OUT_H2 = r'F:\ASI\_real_scso_h2.json'
LOG = r'F:\ASI\_real_scso.log'
CLOSED = r'F:\ASI\_real_param_champion.json'
GPUJ = r'F:\ASI\_real_param_champion_gpu.json'

DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
N_SEED = 3
EPOCHS = 150
LR = 5e-3
BS = 2048
HIDDEN = 32
KAPPA_CAP = 50.0
LOG_RHO_MAX = math.log(1.05)
COOL_MICRO = 0.15
COOL_EVERY = 8
COOL_DEEP = 8.0
_FH = None


def log(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    if _FH:
        _FH.write(s + '\n')
        _FH.flush()



def pack(x, tr, va, te, m):
    
    L, y, idx = DS.mk_delay(x, m)
    p_tr = np.where(idx <= tr[-1])[0]
    p_va = np.where((idx >= va[0]) & (idx <= va[-1]))[0]
    p_te = np.where(idx >= te[0])[0]
    if len(p_tr) < 300 or len(p_va) < 60 or len(p_te) < 60:
        return None
    return L[p_tr], y[p_tr], L[p_va], y[p_va], L[p_te], y[p_te]


def shift_target(X, y):
    
    H = np.empty_like(X)
    H[:, 0] = y
    if X.shape[1] > 1:
        H[:, 1:] = X[:, :-1]
    return H


def rho_clamp_hits(op, X):
    
    with torch.no_grad():
        z = op.readout(torch.tensor(X[:4096], dtype=torch.float64, device=DEV))
        a, _ = op.spec.log_lam(z)
        return float((a > LOG_RHO_MAX - 1e-12).double().mean())


def project_kappa(op):
    
    k = op.basis.kappa2()
    if k > KAPPA_CAP:
        with torch.no_grad():
            op.basis.L.mul_(KAPPA_CAP / k)
        return True
    return False


def install_rho_cap(op):
    
    orig = op.spec.log_lam

    def capped(z):
        a, b = orig(z)
        return torch.clamp(a, max=LOG_RHO_MAX), b

    op.spec.log_lam = capped



def fit_scso(n, Xtr, ytr, Xva, yva, Xte, yte, seed, mode='op0',
             d=2, m=3, use_kappa=True, epochs=EPOCHS, lr=LR):
    
    torch.manual_seed(seed)
    op = SCSO(n, d=min(d, n), m=max(1, min(m, n // 2)), hidden=HIDDEN, seed=seed).to(DEV)
    install_rho_cap(op)
    if (not use_kappa) and hasattr(op.basis, 'L'):
        pass
    Htr = shift_target(Xtr, ytr)
    Hva = shift_target(Xva, yva)
    Hte = shift_target(Xte, yte)

    t = lambda a: torch.tensor(a, dtype=torch.float64, device=DEV)
    Xa, Ha, Ya = t(Xtr), t(Htr), t(ytr)
    Xv, Hv = t(Xva), t(Hva)
    Xe, Yte = t(Xte), t(yte)
    opt = torch.optim.AdamW(op.parameters(), lr=lr, weight_decay=1e-6)
    lossf = nn.MSELoss()
    N = len(Xa)
    bs = min(BS, N)
    best, bstate, n_kappa_proj = float('inf'), None, 0
    for ep in range(epochs):
        perm = torch.randperm(N, device=DEV)
        for i in range(0, N, bs):
            ii = perm[i:i + bs]
            opt.zero_grad(set_to_none=True)
            out = op(Xa[ii])
            if mode == 'op0':
                loss = lossf(out[:, 0], Ya[ii])
            else:
                loss = lossf(out, Ha[ii])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(op.parameters(), 5.0)
            opt.step()
            if use_kappa and (ep % 10 == 9) and (i // bs) == 0:
                if project_kappa(op):
                    n_kappa_proj += 1
        if ep % 25 == 24 or ep == epochs - 1:
            with torch.no_grad():
                ov = op(Xv)
                v = float(lossf(ov[:, 0], t(yva)))
            if v < best:
                best = v
                bstate = {k: s.detach().clone() for k, s in op.state_dict().items()}
    if bstate:
        op.load_state_dict(bstate)
    with torch.no_grad():
        pr = op(Xe)[:, 0].cpu().numpy()
    te = PC.mse(pr, yte)
    info = dict(test=float(te), val=float(best), n_params=int(op.n_params()),
                kappa2=float(op.basis.kappa2()), d=int(min(d, n)),
                m=int(max(1, min(m, n // 2))), n=int(n), mode=mode,
                use_kappa=bool(use_kappa), n_kappa_proj=int(n_kappa_proj),
                rho_clamp_frac=rho_clamp_hits(op, Xtr))
    with torch.no_grad():
        t0 = time.perf_counter()
        _ = op(Xe)
        ms = (time.perf_counter() - t0) * 1e3
    info['ms_per_1k'] = float(ms / max(len(Xte), 1) * 1000)
    info['bytes'] = int(info['n_params'] * 8)
    try:
        torch.cuda.synchronize()
    except Exception:
        pass
    time.sleep(COOL_MICRO)
    return info


_COOLN = [0]


def cool():
    _COOLN[0] += 1
    if COOL_EVERY > 0 and _COOLN[0] % COOL_EVERY == 0:
        log('      [散热] 已完成 %d 次拟合, 深冷却 %.0fs ...' % (_COOLN[0], COOL_DEEP))
        time.sleep(COOL_DEEP)


def select_dm(n, Xtr, ytr, Xva, yva, seed=0, mode='op0'):
    
    d_grid = sorted({1, 2, 4} & set(range(1, n + 1)))
    m_grid = sorted({1, 2, 3} & set(range(1, n // 2 + 1))) or [1]
    best = (float('inf'), 2, 1)
    for d in d_grid:
        for m in m_grid:
            r = fit_scso(n, Xtr, ytr, Xva, yva, Xtr[:10], ytr[:10], seed,
                         mode=mode, d=d, m=m, epochs=max(60, EPOCHS // 2))
            cool()
            if r['val'] < best[0]:
                best = (r['val'], d, m)
    return best[1], best[2], best[0]



def run_h1(names=None):
    global _FH
    _FH = open(LOG, 'a', encoding='utf-8')
    closed = json.load(open(CLOSED, encoding='utf-8')) if os.path.exists(CLOSED) else {}
    gpu = json.load(open(GPUJ, encoding='utf-8')) if os.path.exists(GPUJ) else {}
    res = json.load(open(OUT_H1, encoding='utf-8')) if os.path.exists(OUT_H1) else {}
    plan = PC.GPU_PLAN
    sel = names or list(plan.keys())
    for n in sel:
        for dt in plan[n]:
            key = '%g' % dt
            blk = res.setdefault(n, {}).setdefault(key, dict(name=n, dt_h=float(dt), channels=[]))
            done = {r['ycol'] for r in blk['channels']}
            if len(blk['channels']) >= PC.N_CH and not os.environ.get('SCSO_FORCE'):
                log('  [H1] skip %s dt=%g (cached)' % (n, dt))
                continue
            Zs, cols, tr, va, te, stride, T = PC.load_config(n, dt)
            chans = PC.pick_target_channels(Zs, PC.N_CH)
            for c in chans:
                if int(c) in done:
                    continue
                x = Zs[:, int(c)]
                pk = PC.make_packs(x, tr, va, te)
                if not pk:
                    continue
                m_star = PC.select_M_arlin(pk)
                A, ya, B, yb, Cc, yc = pk[m_star]
                Af, yf = PC.cap_rows(A, ya, PC.MAX_TR, 7)
                Bf, ybf = PC.cap_rows(B, yb, PC.MAX_VA, 11)
                n_state = int(m_star)
                t0 = time.time()
                d0, m0, v0 = select_dm(n_state, Af, yf, Bf, ybf, mode='op0')
                rec = dict(ycol=int(c), M=int(m_star), d=d0, m_spec=m0,
                           dm_val=float(v0), seeds=[], mode='op0')
                for sd in range(N_SEED):
                    rec['seeds'].append(fit_scso(n_state, Af, yf, Bf, ybf, Cc, yc,
                                                 sd, mode='op0', d=d0, m=m0))
                    cool()
                ts = [s['test'] for s in rec['seeds']]
                rec['test'] = float(np.mean(ts))
                rec['test_sd'] = float(np.std(ts))
                rec['val'] = float(np.mean([s['val'] for s in rec['seeds']]))
                rec['n_params'] = int(rec['seeds'][0]['n_params'])
                rec['kappa2'] = float(rec['seeds'][0]['kappa2'])
                rec['rho_clamp_frac'] = float(np.mean([s['rho_clamp_frac'] for s in rec['seeds']]))
                rec['ms_per_1k'] = float(np.mean([s['ms_per_1k'] for s in rec['seeds']]))
                kt, mt = None, None
                for rc in (closed.get(n, {}).get(key, {}).get('channels') or []):
                    if rc['ycol'] == int(c):
                        kt = rc.get('knn_loclin', {}).get('test')
                        mt = rc.get('ar_lin', {}).get('test')
                for rg in (gpu.get(n, {}).get(key, {}).get('channels') or []):
                    if rg['ycol'] == int(c):
                        rec['mlp_direct'] = rg.get('mlp_direct', {}).get('test')
                        rec['mlp_distill'] = rg.get('mlp_distill', {}).get('test')
                        rec['moe_affine'] = rg.get('moe_affine', {}).get('test')
                rec['knn_loclin'] = kt
                rec['ar_lin'] = mt
                rec['ratio_vs_knn'] = (rec['test'] / kt) if kt else None
                rec['ratio_vs_mlp'] = (rec['test'] / rec['mlp_direct']) if rec.get('mlp_direct') else None
                blk['channels'].append(rec)
                blk['secs'] = round(time.time() - t0, 1)
                json.dump(res, open(OUT_H1, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
                log('      [H1] %-11s dt=%-4g ch=%-4d M=%d SCSO=%.4e (x%.3f vs knn) '
                    '%.4e (x%.3f vs mlp) knn=%.4e mlp=%.4e d=%d m=%d k2=%.2f p=%d'
                    % (n, dt, c, m_star, rec['test'], rec['ratio_vs_knn'] or float('nan'),
                       rec['test'], rec['ratio_vs_mlp'] or float('nan'),
                       kt or float('nan'), rec.get('mlp_direct') or float('nan'),
                       d0, m0, rec['kappa2'], rec['n_params']))
            json.dump(res, open(OUT_H1, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    log('H1 -> %s' % OUT_H1)



H2_CONF = [('traffic', 12.0), ('electricity', 12.0), ('solar_AL', 3.0)]
H2_L = [8, 16, 32, 64, 128, 256]
H2_NCH = 2


def run_h2():
    global _FH
    _FH = open(LOG, 'a', encoding='utf-8')
    res = json.load(open(OUT_H2, encoding='utf-8')) if os.path.exists(OUT_H2) else {}
    for name, dt in H2_CONF:
        key = '%g' % dt
        blk = res.setdefault(name, {}).setdefault(key, dict(name=name, dt_h=float(dt), rows=[]))
        done = {(r['ycol'], r['L']) for r in blk['rows']}
        Zs, cols, tr, va, te, stride, T = PC.load_config(name, dt)
        chans = PC.pick_target_channels(Zs, PC.N_CH)[:H2_NCH]
        for c in chans:
            x = Zs[:, int(c)]
            for L in H2_L:
                if (int(c), L) in done:
                    continue
                pk = pack(x, tr, va, te, L)
                if not pk:
                    log('      [H2] %s dt=%g ch=%d L=%d SKIP (样本不足)' % (name, dt, c, L))
                    continue
                A, ya, B, yb, Cc, yc = pk
                Af, yf = PC.cap_rows(A, ya, PC.MAX_TR, 7)
                Bf, ybf = PC.cap_rows(B, yb, PC.MAX_VA, 11)

                bl, bt, ba = float('inf'), None, None
                for al in PC.ALPHA_GRID:
                    w = DS.ridge_fit(Af, yf, al)
                    v = PC.mse(DS.ridge_pred(Bf, w), ybf)
                    if v < bl:
                        bl, bt, ba = v, PC.mse(DS.ridge_pred(Cc, w), yc), al
                t0 = time.time()
                d0, m0, v0 = select_dm(L, Af, yf, Bf, ybf, mode='op0')
                ss = []
                for sd in range(N_SEED):
                    ss.append(fit_scso(L, Af, yf, Bf, ybf, Cc, yc, sd, mode='op0', d=d0, m=m0))
                    cool()
                ts = [s['test'] for s in ss]
                row = dict(ycol=int(c), L=int(L), d=d0, m_spec=m0,
                           test=float(np.mean(ts)), test_sd=float(np.std(ts)),
                           direct_lin=float(bt), direct_lin_alpha=float(ba),
                           ratio=float(np.mean(ts) / bt) if bt else None,
                           n_params=int(ss[0]['n_params']), kappa2=float(ss[0]['kappa2']),
                           rho_clamp_frac=float(np.mean([s['rho_clamp_frac'] for s in ss])),
                           ms_per_1k=float(np.mean([s['ms_per_1k'] for s in ss])),
                           secs=round(time.time() - t0, 1))
                blk['rows'].append(row)
                json.dump(res, open(OUT_H2, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
                log('      [H2] %-11s dt=%-4g ch=%-4d L=%-4d SCSO=%.4e lin=%.4e ratio=%.3f '
                    'p=%d k2=%.2f' % (name, dt, c, L, row['test'], row['direct_lin'],
                                      row['ratio'] or float('nan'), row['n_params'], row['kappa2']))
        json.dump(res, open(OUT_H2, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    log('H2 -> %s' % OUT_H2)


def smoke():
    global _FH
    _FH = open(LOG, 'a', encoding='utf-8')
    log('=' * 90)
    log('冒烟 (%s, torch %s) —— 不出判决, 只验接线' % (DEV, torch.__version__))
    Zs, cols, tr, va, te, stride, T = PC.load_config('ETTh1', 3.0)
    chans = PC.pick_target_channels(Zs, PC.N_CH)
    c = int(chans[0])
    x = Zs[:, c]
    pk = PC.make_packs(x, tr, va, te)
    m_star = PC.select_M_arlin(pk)
    A, ya, B, yb, Cc, yc = pk[m_star]
    Af, yf = PC.cap_rows(A, ya, PC.MAX_TR, 7)
    Bf, ybf = PC.cap_rows(B, yb, PC.MAX_VA, 11)
    log('  config=ETTh1 dt=3 ch=%d M=%d  train=%d val=%d test=%d' %
        (c, m_star, len(Af), len(Bf), len(Cc)))
    bv, bm = float('inf'), None
    for m in PC.M_GRID:
        if m in pk:
            v = PC.mse(pk[m][2][:, 0], pk[m][3])
            if v < bv:
                bv, bm = v, m
    log('  persist(val) = %.4e  @M=%d' % (bv, bm))
    d0, m0, v0 = select_dm(m_star, Af, yf, Bf, ybf, mode='op0')
    log('  select_dm -> d=%d m=%d val=%.4e' % (d0, m0, v0))
    for sd in range(N_SEED):
        r = fit_scso(m_star, Af, yf, Bf, ybf, Cc, yc, sd, mode='op0', d=d0, m=m0)
        log('  seed=%d val=%.4e test=%.4e p=%d k2=%.2f rho_hit=%.3f ms/1k=%.3f'
            % (sd, r['val'], r['test'], r['n_params'], r['kappa2'],
               r['rho_clamp_frac'], r['ms_per_1k']))
    log('冒烟结束。')


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'smoke'
    if mode == 'smoke':
        smoke()
    elif mode == 'h1':
        run_h1([a for a in sys.argv[2:] if a in PC.GPU_PLAN] or None)
    elif mode == 'h2':
        run_h2()
    else:
        print('usage: python _real_scso.py [smoke|h1|h2]')
