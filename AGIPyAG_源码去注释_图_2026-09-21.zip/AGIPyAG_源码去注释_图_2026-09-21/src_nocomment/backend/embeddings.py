#!/usr/bin/env python3







import math
import hashlib
from typing import List, Optional

import torch


class StarLightEmbedder:
    

    def __init__(self, model, tokenizer, memory_dim: int = 384, device: str = "cpu"):
        self.model = model
        self.tokenizer = tokenizer
        self.memory_dim = memory_dim
        self.device = device

        g = torch.Generator().manual_seed(42)
        self._proj = torch.randn(256, memory_dim, generator=g, dtype=torch.float32)
        self._proj = self._proj / math.sqrt(256.0)
        self._proj = self._proj.to(device)

    @torch.no_grad()
    def embed(self, text: str) -> List[float]:
        
        ids = self.tokenizer.encode(text, add_special_tokens=True)
        if len(ids) == 0:
            ids = [self.tokenizer.bos_id]

        max_len = getattr(self.model.config, "max_seq_len", 128)
        ids = ids[:max_len]
        input_ids = torch.tensor([ids], dtype=torch.long, device=self.device)

        logits, aux = self.model(input_ids)
        state = aux.get("state", None)
        if state is None:

            return HashEmbedder(self.memory_dim).embed(text)

        if state.dim() == 4:
            a = state[0, :, :, 0]
        else:
            a = state[0, :, 0].unsqueeze(0)
        vec = a.mean(dim=0)
        if vec.numel() != 256:

            vec = torch.nn.functional.adaptive_avg_pool1d(vec.unsqueeze(0).unsqueeze(0), 256).squeeze()
        out = vec @ self._proj

        out = out / (out.norm() + 1e-8)
        return out.detach().cpu().tolist()


class HashEmbedder:
    

    def __init__(self, memory_dim: int = 384):
        self.memory_dim = memory_dim

    def embed(self, text: str) -> List[float]:
        text = text.lower().replace("\n", " ")
        vec = [0.0] * self.memory_dim
        n = max(1, len(text) - 2)
        for i in range(n):
            gram = text[i:i + 3]
            h = int(hashlib.md5(gram.encode("utf-8")).hexdigest(), 16)
            idx = h % self.memory_dim
            vec[idx] += 1.0

        total = sum(vec) or 1.0
        vec = [v / total for v in vec]
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]
