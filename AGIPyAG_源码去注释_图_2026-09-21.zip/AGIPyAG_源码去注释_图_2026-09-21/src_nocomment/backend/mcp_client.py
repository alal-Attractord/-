#!/usr/bin/env python3








import json
import os
import subprocess
import sys
import threading
from typing import Any, Dict, List, Optional

MCP_SERVER_PATH = os.path.join("F:/", "AGI", "AGI", "MCP", "server.py")


ALLOWED_TOOLS = {
    "system_overview", "cpu_info", "memory_info", "disk_info", "network_info", "gpu_info",
    "web_scrape", "web_scrape_multiple", "extract_text_only", "extract_code_only",
    "http_request", "dns_lookup", "ping", "port_check",
    "list_processes", "process_info",
}


class MCPClient:
    

    def __init__(self):
        self._proc: Optional[subprocess.Popen] = None
        self._lock = threading.Lock()
        self._tools: List[Dict[str, Any]] = []
        self._connected = False
        self._request_id = 0

    def _ensure_process(self):
        if self._proc is not None and self._proc.poll() is None:
            return
        if not os.path.exists(MCP_SERVER_PATH):
            raise RuntimeError(f"MCP server 不存在: {MCP_SERVER_PATH}")
        cmd = [sys.executable, MCP_SERVER_PATH, "--transport", "stdio"]
        self._proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            bufsize=0,
        )
        self._connected = False

    def _send_raw(self, data: bytes):
        self._proc.stdin.write(data)
        self._proc.stdin.flush()

    def _read_message(self) -> Dict[str, Any]:
        
        headers = {}
        while True:
            line = self._proc.stdout.readline()
            if not line:
                raise RuntimeError("MCP server 关闭连接")
            line = line.strip()
            if not line:
                break
            if b":" in line:
                k, v = line.split(b":", 1)
                headers[k.decode().lower()] = v.decode().strip()
        length = int(headers.get("content-length", "0"))
        if length <= 0:
            raise RuntimeError("无效的 Content-Length")
        body = self._proc.stdout.read(length)
        return json.loads(body.decode("utf-8"))

    def _rpc(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        self._ensure_process()
        self._request_id += 1
        req = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
            "params": params or {},
        }
        body = json.dumps(req, ensure_ascii=False).encode("utf-8")
        header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
        self._send_raw(header + body)
        resp = self._read_message()
        if "error" in resp:
            raise RuntimeError(f"MCP error: {resp['error']}")
        return resp.get("result")

    def _initialize(self):
        
        self._rpc("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "agipyag-backend", "version": "9.0.0"},
        })

        note = {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}
        body = json.dumps(note, ensure_ascii=False).encode("utf-8")
        header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
        self._send_raw(header + body)

    def list_tools(self) -> List[Dict[str, Any]]:
        
        with self._lock:
            if not self._connected:
                self._initialize()
                result = self._rpc("tools/list")
                self._tools = result.get("tools", [])
                self._connected = True
            return [t for t in self._tools if t.get("name") in ALLOWED_TOOLS]

    def call_tool(self, name: str, arguments: Optional[Dict[str, Any]] = None) -> Any:
        
        if name not in ALLOWED_TOOLS:
            raise PermissionError(f"工具 '{name}' 不在白名单内")
        with self._lock:
            if not self._connected:
                self._initialize()
                self._rpc("tools/list")
                self._connected = True
            return self._rpc("tools/call", {"name": name, "arguments": arguments or {}})

    def close(self):
        with self._lock:
            if self._proc is not None:
                try:
                    self._proc.terminate()
                    self._proc.wait(timeout=3)
                except Exception:
                    try:
                        self._proc.kill()
                    except Exception:
                        pass
                self._proc = None
                self._connected = False


_client: Optional[MCPClient] = None


def get_mcp_client() -> MCPClient:
    global _client
    if _client is None:
        _client = MCPClient()
    return _client
