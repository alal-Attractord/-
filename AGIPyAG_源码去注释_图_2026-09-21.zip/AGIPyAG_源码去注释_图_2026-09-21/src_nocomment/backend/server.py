#!/usr/bin/env python3

import json
import os
import queue
import secrets
import threading
import time
from typing import Any, Dict, Generator, List, Optional, Tuple

from fastapi import FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from backend.engine import get_engine, ENGINE_VERSION, MODELS_DIR




_DEFAULT_TOKEN = os.environ.get("CHAOS_API_TOKEN")
if _DEFAULT_TOKEN:
    API_TOKEN = _DEFAULT_TOKEN
else:
    API_TOKEN = secrets.token_urlsafe(32)
    print(f"[security] CHAOS_API_TOKEN 未设置，已自动生成临时 Token: {API_TOKEN}")


_CORS_ORIGINS = os.environ.get("CHAOS_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173,http://localhost:8768,http://127.0.0.1:8768")
CORS_ORIGINS = [o.strip() for o in _CORS_ORIGINS.split(",") if o.strip()] or ["http://localhost:5173"]

app = FastAPI(title="AGIPyAG Chaos Engine", version=ENGINE_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)







_RATE_LIMIT_RPM = int(os.environ.get("CHAOS_RATE_LIMIT_RPM", "600"))
_rate_limit_store: Dict[str, List[float]] = {}
_rate_limit_lock = threading.Lock()


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    if not request.url.path.startswith("/api"):
        return await call_next(request)

    if request.url.path.startswith("/api/health"):
        return await call_next(request)
    client_host = request.client.host if request.client else "unknown"
    now = time.time()
    window_start = now - 60.0
    with _rate_limit_lock:
        window = _rate_limit_store.get(client_host, [])
        window = [t for t in window if t >= window_start]
        if len(window) >= _RATE_LIMIT_RPM:
            return JSONResponse(
                status_code=429,
                content={"error": "rate_limited", "message": f"请求过于频繁，请稍后再试 (限制 {_RATE_LIMIT_RPM}/min)"},
                headers={"Retry-After": "60"},
            )
        window.append(now)
        _rate_limit_store[client_host] = window
    return await call_next(request)





@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    response: Response = await call_next(request)
    if request.url.path.startswith("/api"):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response





@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    if request.url.path.startswith("/api"):
        token = request.headers.get("X-API-Token", "")
        if token != API_TOKEN:

            try:
                get_engine().network_tracer.trace(
                    action="api_call",
                    target=request.url.path,
                    source=request.client.host if request.client else "unknown",
                    method=request.method,
                    status_code=401,
                    auth_type="blocked",
                    details={"reason": "invalid_token", "provided": token[:10] + "..." if token else "none"},
                )
            except Exception:
                pass
            return JSONResponse(status_code=401, content={"error": "unauthorized", "message": "X-API-Token 无效"})

        try:
            get_engine().network_tracer.trace(
                action="api_call",
                target=request.url.path,
                source=request.client.host if request.client else "unknown",
                method=request.method,
                status_code=200,
                auth_type="token",
            )
        except Exception:
            pass
    return await call_next(request)





class GenerateReq(BaseModel):
    text: str = Field(..., min_length=1)
    max_tokens: int = Field(64, ge=1, le=512)
    temperature: float = Field(0.8, ge=0.05, le=2.0)
    top_k: int = Field(50, ge=0, le=500)
    top_p: float = Field(0.9, gt=0.0, le=1.0)
    use_rag: bool = Field(False)
    intensity: str = Field("standard", pattern="^(standard|enhanced|high|extreme|apocalypse)$")
    model: str = Field("starlight", pattern="^(starlight|chaos|full|chaos_llm|chaos_world|chaos_wm_v2|koopman)$")

class ThinkReq(BaseModel):
    text: str = Field(..., min_length=1)
    max_tokens: int = Field(96, ge=1, le=512)
    use_rag: bool = Field(True)
    intensity: str = Field("standard", pattern="^(standard|enhanced|high|extreme|apocalypse)$")
    model: str = Field("starlight", pattern="^(starlight|chaos|full|chaos_llm|chaos_world|chaos_wm_v2|koopman)$")


class TrainReq(BaseModel):
    model: str = Field("starlight", pattern="^(starlight|chaos|full)$")
    steps: int = Field(500, ge=1, le=100000)
    batch: int = Field(4, ge=1, le=64)
    lr: float = Field(3e-4, gt=0, le=1e-1)
    seq_len: int = Field(64, ge=16, le=128)
    phase: int = Field(4, ge=1, le=4)
    compute_level: int = Field(5, ge=1, le=10)
    use_cluster: bool = Field(False)
    use_online_data: bool = Field(False)


class VocabBuildReq(BaseModel):
    vocab_size: int = Field(8000, ge=256, le=64000)
    model_type: str = Field("bpe", pattern="^(bpe|unigram)$")


class OnnxExportReq(BaseModel):
    model: str = Field("starlight", pattern="^(starlight|chaos)$")





class MemoryCreateReq(BaseModel):
    memory_dim: int = Field(384, ge=64, le=2048)
    capacity: float = Field(0.6, gt=0.0, le=1.0)
    max_memories: int = Field(4096, ge=16, le=65536)


class MemoryWriteReq(BaseModel):
    text: str = Field(..., min_length=1)
    embedding: Optional[List[float]] = None


class MemoryBulkWriteReq(BaseModel):
    items: List[Dict[str, Any]] = Field(..., min_length=1)


class MemoryRetrieveReq(BaseModel):
    embedding: List[float] = Field(..., min_length=1)
    top_k: int = Field(5, ge=1, le=100)
    mode: str = Field("associative", pattern="^(exact|associative|random)$")


class MemoryDecayReq(BaseModel):
    steps: int = Field(1, ge=1, le=1000)


class MemoryConsolidateReq(BaseModel):
    steps: int = Field(5, ge=1, le=100)





def sse_stream(gen: Generator[Dict[str, Any], None, None]) -> StreamingResponse:
    def event_source():
        try:
            for item in gen:
                yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)}, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_source(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )





@app.get("/api/health")
def health():
    return get_engine().health()


@app.get("/api/model/info")
def model_info():
    return get_engine().model_info()


@app.post("/api/model/export/onnx")
def export_onnx(req: OnnxExportReq):
    
    eng = get_engine()
    if req.model == "starlight":
        path = os.path.join(MODELS_DIR, "starlight.onnx")
        result = eng.export_starlight_onnx(path)
    elif req.model == "chaos":
        path = os.path.join(MODELS_DIR, "chaos_nn.onnx")
        result = eng.export_chaos_nn_onnx(path)
    else:
        raise HTTPException(status_code=400, detail=f"不支持的模型类型: {req.model}")

    if not result.get("ok"):
        raise HTTPException(status_code=500, detail=result.get("error", "导出失败"))
    return result





def _koopman_engine():
    
    import importlib
    ke = importlib.import_module("koopman_engine").get_engine()
    ke.load()
    if not ke.ready:
        raise HTTPException(status_code=503, detail=f"Koopman 引擎不可用：{ke.missing}")
    return ke


@app.get("/api/koopman/spectral")
def koopman_spectral(h: str = "1,5,20,80,160"):
    





    ke = _koopman_engine()
    hs = tuple(int(v) for v in str(h).split(",") if v.strip())
    return ke.spectral_forecast(hs)


@app.get("/api/koopman/chaos")
def koopman_chaos():
    




    return _koopman_engine().chaos_diag()


@app.get("/api/koopman/attribution")
def koopman_attribution(h: int = 20, top_k: int = 3):
    
    return _koopman_engine().attribution(h, top_k)


@app.post("/api/generate")
def generate(req: GenerateReq):
    try:
        return get_engine().generate(req.text, req.max_tokens, req.temperature, req.top_k, req.top_p,
                                     use_rag=req.use_rag, intensity=req.intensity, model=req.model)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/generate/stream")
def generate_stream(req: GenerateReq):
    return sse_stream(get_engine().generate_stream(req.text, req.max_tokens, req.temperature, req.top_k, req.top_p,
                                                    intensity=req.intensity, model=req.model))


@app.post("/api/agent/think")
def agent_think(req: ThinkReq):
    try:
        return get_engine().agent_think(req.text, req.max_tokens, intensity=req.intensity, model=req.model)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/agent/think/stream")
def agent_think_stream(req: ThinkReq):
    return sse_stream(get_engine().agent_think_stream(req.text, req.max_tokens, intensity=req.intensity, model=req.model))


@app.get("/api/corpus/stats")
def corpus_stats():
    eng = get_engine()
    return {
        "path": eng.__class__.__dict__.get("CORPUS_PATH", "backend/data/corpus.txt"),
        "tokens": int(len(eng.corpus_ids)) if eng.corpus_ids is not None else 0,
    }


@app.post("/api/corpus/rebuild")
def corpus_rebuild():
    
    from backend.engine import build_corpus
    info = build_corpus(force=True)

    get_engine()._tokenize_corpus()
    return info


@app.post("/api/train")
def train_start(req: TrainReq):
    try:
        return get_engine().trainer.start(
            req.model, req.steps, req.batch, req.lr, req.seq_len, req.phase,
            compute_level=req.compute_level, use_cluster=req.use_cluster, use_online_data=req.use_online_data
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/train/status")
def train_status():
    return get_engine().trainer.status()


@app.post("/api/train/stop")
def train_stop():
    return get_engine().trainer.stop()


@app.post("/api/train/open-folder")
def train_open_folder():
    
    return get_engine().open_models_dir()


@app.get("/api/train/cluster")
def train_cluster():
    
    return get_engine().cluster_status()


@app.get("/api/train/online/sources")
def train_online_sources():
    
    return {"sources": get_engine().online_sources()}


@app.post("/api/vocab/build")
def vocab_build(req: VocabBuildReq):
    return get_engine().vocab_builder.start(req.vocab_size, req.model_type)


@app.get("/api/vocab/build/status")
def vocab_build_status():
    return get_engine().vocab_builder.status()


@app.get("/api/vocab/stats")
def vocab_stats():
    return get_engine().vocab_stats()


@app.get("/api/security/status")
def security_status():
    return get_engine().security_status()


@app.get("/api/chaos/state")
def chaos_state(steps: int = 200):
    return get_engine().chaos_state(steps)


@app.get("/api/logs")
def logs(n: int = 100):
    return {"logs": get_engine().get_logs(min(n, 300))}





@app.post("/api/memory/create")
def memory_create(req: MemoryCreateReq):
    return get_engine().memory.create(
        memory_dim=req.memory_dim,
        capacity=req.capacity,
        max_memories=req.max_memories,
    )


@app.get("/api/memory/stats")
def memory_stats():
    return get_engine().memory.stats()


@app.post("/api/memory/write")
def memory_write(req: MemoryWriteReq):
    return get_engine().memory.write(req.text, req.embedding)


@app.post("/api/memory/write/bulk")
def memory_write_bulk(req: MemoryBulkWriteReq):
    return get_engine().memory.write_bulk(req.items)


@app.post("/api/memory/retrieve")
def memory_retrieve(req: MemoryRetrieveReq):
    return get_engine().memory.retrieve(
        query_embedding=req.embedding,
        top_k=req.top_k,
        mode=req.mode,
    )


class MemoryRetrieveTextReq(BaseModel):
    text: str = Field(..., min_length=1)
    top_k: int = Field(5, ge=1, le=100)
    mode: str = Field("associative", pattern="^(exact|associative|random)$")


@app.post("/api/memory/retrieve/text")
def memory_retrieve_text(req: MemoryRetrieveTextReq):
    
    return get_engine().memory.retrieve_by_text(req.text, top_k=req.top_k, mode=req.mode)


@app.post("/api/memory/decay")
def memory_decay(req: MemoryDecayReq):
    
    return get_engine().memory.decay(req.steps)


@app.post("/api/memory/consolidate")
def memory_consolidate(req: MemoryConsolidateReq):
    
    return get_engine().memory.consolidate(req.steps)


@app.delete("/api/memory")
def memory_reset():
    
    return get_engine().memory.reset()


class MemorySaveReq(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)


@app.post("/api/memory/save")
def memory_save(req: MemorySaveReq):
    
    try:
        return get_engine().memory.save(req.name)
    except (RuntimeError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/memory/load")
def memory_load(req: MemorySaveReq):
    
    try:
        return get_engine().memory.load(req.name)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/memory/banks")
def memory_banks():
    
    return get_engine().memory.list_banks()





class MCPCallReq(BaseModel):
    name: str = Field(..., min_length=1)
    arguments: Dict[str, Any] = Field(default_factory=dict)


@app.get("/api/mcp/tools")
def mcp_tools():
    
    from backend.mcp_client import get_mcp_client
    try:
        tools = get_mcp_client().list_tools()
        return {"tools": tools, "count": len(tools)}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"MCP 不可用: {e}")


@app.post("/api/mcp/call")
def mcp_call(req: MCPCallReq):
    
    from backend.mcp_client import get_mcp_client
    try:
        result = get_mcp_client().call_tool(req.name, req.arguments)
        return {"result": result}
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"MCP 调用失败: {e}")





@app.get("/api/network/stats")
def network_stats():
    
    return get_engine().network_trace_stats()


@app.get("/api/network/records")
def network_records(
    limit: int = 500,
    action: Optional[str] = None,
    since: Optional[int] = None,
):
    
    return {
        "records": get_engine().network_trace_records(
            limit=limit, action_filter=action, since_minutes=since
        )
    }


@app.get("/api/network/connections")
def network_connections():
    
    return {"connections": get_engine().network_trace_connections()}


@app.get("/api/network/nodes")
def network_nodes():
    
    return {"nodes": get_engine().network_trace_nodes()}





@app.get("/api/map/tile/{z}/{x}/{y}")
def map_tile(z: int, x: int, y: int):
    



    data, meta = get_engine().map_tile(z, x, y)
    if data is None:
        error_msg = meta.get("error", "unknown")
        if "HTTP 404" in error_msg:
            raise HTTPException(status_code=404, detail=f"瓦片不存在: z={z} x={x} y={y}")
        raise HTTPException(status_code=503, detail=f"瓦片获取失败: {error_msg}")
    
    headers = {
        "X-Tile-Source": meta.get("source", "unknown"),
        "X-Cache-Hit": "true" if meta.get("cache_hit") else "false",
    }
    return Response(content=data, media_type="image/png", headers=headers)


@app.get("/api/map/stats")
def map_stats():
    
    return get_engine().map_tile_stats()


class MapDownloadReq(BaseModel):
    lat_min: float = Field(..., ge=-90, le=90)
    lon_min: float = Field(..., ge=-180, le=180)
    lat_max: float = Field(..., ge=-90, le=90)
    lon_max: float = Field(..., ge=-180, le=180)
    zoom_levels: List[int] = Field(default=[2, 3, 4, 5])


@app.post("/api/map/download")
def map_download(req: MapDownloadReq):
    
    result = get_engine().map_download_region(
        req.lat_min, req.lon_min, req.lat_max, req.lon_max, req.zoom_levels
    )
    return result


@app.post("/api/map/clear")
def map_clear():
    
    return get_engine().map_clear_cache()


@app.get("/api/map/nodes")
def map_nodes():
    
    return {"nodes": get_engine().map_server_nodes()}





_MIME = {
    ".html": "text/html; charset=utf-8", ".js": "application/javascript",
    ".css": "text/css", ".json": "application/json", ".svg": "image/svg+xml",
    ".png": "image/png", ".jpg": "image/jpeg", ".ico": "image/x-icon",
    ".woff": "font/woff", ".woff2": "font/woff2", ".map": "application/json",
    ".txt": "text/plain",
}


class MemoryStaticFiles:
    

    def __init__(self, directory: str):
        self.files: dict = {}
        for root, _, fnames in os.walk(directory):
            for fn in fnames:
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, directory).replace("\\", "/")
                with open(p, "rb") as f:
                    self.files[rel] = f.read()
        self.index = self.files.get("index.html")

    async def __call__(self, scope, receive, send):
        path = scope.get("path", "/").lstrip("/")
        if not path:
            path = "index.html"
        data = self.files.get(path)
        if data is None:

            last = path.rsplit("/", 1)[-1]
            if "." not in last and self.index is not None:
                data, path = self.index, "index.html"
            else:
                headers = [(b"content-type", b"text/plain; charset=utf-8")]
                await send({"type": "http.response.start", "status": 404, "headers": headers})
                await send({"type": "http.response.body", "body": b"Not Found"})
                return
        ctype = _MIME.get(os.path.splitext(path)[1], "application/octet-stream")
        headers = [(b"content-type", ctype.encode("utf-8")), (b"cache-control", b"no-store")]
        await send({"type": "http.response.start", "status": 200, "headers": headers})
        await send({"type": "http.response.body", "body": data})


_DIST = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "webui", "dist")
if os.path.isdir(_DIST):
    app.mount("/", MemoryStaticFiles(_DIST), name="webui-mem")
    print(f"[server] UI 静态资源已载入内存 serve（{_DIST}），运行期零磁盘读")


def main():
    import uvicorn

    get_engine()
    uvicorn.run(app, host="127.0.0.1", port=8768, log_level="info")


if __name__ == "__main__":
    main()
