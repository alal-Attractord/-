#!/usr/bin/env python3













import os
import sys
import json
import time
import math
import threading
import traceback
import socket
import urllib.parse
import urllib.request
import hashlib
import gc
import platform
import subprocess
from collections import OrderedDict, deque
from datetime import datetime, timedelta
from typing import Any, Dict, Generator, List, Optional, Set, Tuple




_BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_BACKEND_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import torch
import torch.nn as nn
import torch.nn.functional as F

from DeeNeuralNetwork.token_module.tokenizer import SentencePieceTokenizer, EnterpriseTokenizer
from DeeNeuralNetwork.starlight_model import StarLightModel, StarLightConfig
from DeeNeuralNetwork.chaos_neural_network import ChaosNeuralNetwork, SecurityManager
from DeeNeuralNetwork.chaos_engine import AGIChaosEngine
from DeeNeuralNetwork.chaotic_memory_bank import ZeroShotChaoticMemoryBank

from backend.embeddings import StarLightEmbedder, HashEmbedder

MODELS_DIR = os.path.join("F:/", "AGI", "models")
DATA_DIR = os.path.join(_BACKEND_DIR, "data")
CORPUS_PATH = os.path.join(DATA_DIR, "corpus.txt")
STARLIGHT_CKPT = os.path.join(MODELS_DIR, "starlight_chaos.pt")
CHAOS_CKPT = os.path.join(MODELS_DIR, "chaos_nn.pt")
VOCAB_BUILD_DIR = os.path.join(DATA_DIR, "vocab_build")

os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(VOCAB_BUILD_DIR, exist_ok=True)

ENGINE_VERSION = "9.0.0-jupiter"





class MapTileManager:
    









    TILE_SERVERS = ["a", "b", "c"]
    TILE_URL_TEMPLATE = "https://{subdomain}.tile.openstreetmap.org/{z}/{x}/{y}.png"
    

    DEFAULT_CACHE_DIR = os.path.join(DATA_DIR, "map_tiles")
    

    USER_AGENT = "AGIPyAG-ChaosEngine/9.0 (Research Project; contact@agipyag.local)"
    

    TILE_SIZE = 256

    def __init__(self, cache_dir: Optional[str] = None, max_cache_mb: int = 2048):
        self.cache_dir = cache_dir or self.DEFAULT_CACHE_DIR
        self.max_cache_bytes = max_cache_mb * 1024 * 1024
        self._server_index = 0
        self._lock = threading.Lock()
        self._download_lock = threading.Lock()

        self._mem_cache: "OrderedDict[str, bytes]" = OrderedDict()
        self._mem_max = 512
        self._stats = {
            "total_requests": 0,
            "cache_hits": 0,
            "downloads": 0,
            "download_errors": 0,
            "bytes_downloaded": 0,
            "cache_size_bytes": 0,
            "cache_files": 0,
        }
        self._stats_lock = threading.Lock()
        
        os.makedirs(self.cache_dir, exist_ok=True)
        self._update_cache_stats()
        

        self.server_nodes = {

            "beijing": {"lat": 39.9042, "lon": 116.4074, "label": "北京", "type": "server", "region": "中国"},
            "shanghai": {"lat": 31.2304, "lon": 121.4737, "label": "上海", "type": "server", "region": "中国"},
            "shenzhen": {"lat": 22.5431, "lon": 114.0579, "label": "深圳", "type": "cloud", "region": "中国"},
            "hangzhou": {"lat": 30.2741, "lon": 120.1551, "label": "杭州", "type": "cloud", "region": "中国"},
            "san_francisco": {"lat": 37.7749, "lon": -122.4194, "label": "旧金山", "type": "ai_service", "region": "美国"},
            "seattle": {"lat": 47.6062, "lon": -122.3321, "label": "西雅图", "type": "ai_service", "region": "美国"},
            "new_york": {"lat": 40.7128, "lon": -74.0060, "label": "纽约", "type": "data_source", "region": "美国"},
            "london": {"lat": 51.5074, "lon": -0.1278, "label": "伦敦", "type": "ai_service", "region": "英国"},
            "paris": {"lat": 48.8566, "lon": 2.3522, "label": "巴黎", "type": "ai_service", "region": "法国"},
            "tokyo": {"lat": 35.6762, "lon": 139.6503, "label": "东京", "type": "ai_service", "region": "日本"},
            "singapore": {"lat": 1.3521, "lon": 103.8198, "label": "新加坡", "type": "cloud", "region": "新加坡"},
            "sydney": {"lat": -33.8688, "lon": 151.2093, "label": "悉尼", "type": "cloud", "region": "澳大利亚"},
            "frankfurt": {"lat": 50.1109, "lon": 8.6821, "label": "法兰克福", "type": "cdn", "region": "德国"},
            "dubai": {"lat": 25.2048, "lon": 55.2708, "label": "迪拜", "type": "cloud", "region": "阿联酋"},
            "mumbai": {"lat": 19.0760, "lon": 72.8777, "label": "孟买", "type": "cloud", "region": "印度"},
            "sao_paulo": {"lat": -23.5505, "lon": -46.6333, "label": "圣保罗", "type": "cloud", "region": "巴西"},
        }

    def _get_next_server(self) -> str:
        
        with self._lock:
            server = self.TILE_SERVERS[self._server_index % len(self.TILE_SERVERS)]
            self._server_index += 1
            return server

    def _tile_path(self, z: int, x: int, y: int) -> str:
        
        return os.path.join(self.cache_dir, str(z), str(x), f"{y}.png")

    def _update_cache_stats(self):
        
        total_size = 0
        total_files = 0
        for root, _, files in os.walk(self.cache_dir):
            for f in files:
                if f.endswith(".png"):
                    fp = os.path.join(root, f)
                    total_size += os.path.getsize(fp)
                    total_files += 1
        with self._stats_lock:
            self._stats["cache_size_bytes"] = total_size
            self._stats["cache_files"] = total_files

    def _mem_get(self, path: str) -> Optional[bytes]:
        with self._lock:
            data = self._mem_cache.get(path)
            if data is not None:
                self._mem_cache.move_to_end(path)
            return data

    def _mem_put(self, path: str, data: bytes):
        with self._lock:
            self._mem_cache[path] = data
            self._mem_cache.move_to_end(path)
            while len(self._mem_cache) > self._mem_max:
                self._mem_cache.popitem(last=False)

    def get_tile(self, z: int, x: int, y: int) -> Tuple[Optional[bytes], Dict[str, Any]]:
        








        if not (0 <= z <= 19):
            return None, {"source": "validation", "error": "zoom level out of range [0, 19]"}
        max_coord = (1 << z) - 1
        if not (0 <= x <= max_coord and 0 <= y <= max_coord):
            return None, {"source": "validation", "error": "tile coordinates out of range"}

        with self._stats_lock:
            self._stats["total_requests"] += 1
        
        tile_path = self._tile_path(z, x, y)


        mem_data = self._mem_get(tile_path)
        if mem_data is not None:
            with self._stats_lock:
                self._stats["cache_hits"] += 1
            return mem_data, {"source": "mem_cache", "cache_hit": True, "path": tile_path}
        

        if os.path.exists(tile_path):
            try:
                with open(tile_path, "rb") as f:
                    data = f.read()
                self._mem_put(tile_path, data)
                with self._stats_lock:
                    self._stats["cache_hits"] += 1
                return data, {"source": "cache", "cache_hit": True, "path": tile_path}
            except Exception as e:
                pass
        

        return self._download_tile(z, x, y)

    def _download_tile(self, z: int, x: int, y: int) -> Tuple[Optional[bytes], Dict[str, Any]]:
        
        tile_path = self._tile_path(z, x, y)
        
        with self._download_lock:

            if os.path.exists(tile_path):
                try:
                    with open(tile_path, "rb") as f:
                        data = f.read()
                    with self._stats_lock:
                        self._stats["cache_hits"] += 1
                    return data, {"source": "cache", "cache_hit": True, "path": tile_path}
                except Exception:
                    pass
            
            server = self._get_next_server()
            url = self.TILE_URL_TEMPLATE.format(subdomain=server, z=z, x=x, y=y)
            
            try:
                req = urllib.request.Request(
                    url,
                    headers={
                        "User-Agent": self.USER_AGENT,
                        "Accept": "image/png",
                    }
                )
                
                with urllib.request.urlopen(req, timeout=15) as response:
                    data = response.read()
                    
                    if len(data) < 100:

                        with self._stats_lock:
                            self._stats["download_errors"] += 1
                        return None, {"source": "network", "error": "invalid_tile_data", "url": url}
                    

                    self._mem_put(tile_path, data)
                    os.makedirs(os.path.dirname(tile_path), exist_ok=True)
                    with open(tile_path, "wb") as f:
                        f.write(data)
                    
                    with self._stats_lock:
                        self._stats["downloads"] += 1
                        self._stats["bytes_downloaded"] += len(data)
                    
                    self._update_cache_stats()
                    self._enforce_cache_limit()
                    
                    return data, {"source": "network", "cache_hit": False, "url": url, "size": len(data)}
                    
            except urllib.error.HTTPError as e:
                with self._stats_lock:
                    self._stats["download_errors"] += 1
                return None, {"source": "network", "error": f"HTTP {e.code}", "url": url}
            except Exception as e:
                with self._stats_lock:
                    self._stats["download_errors"] += 1
                return None, {"source": "network", "error": str(e), "url": url}

    def _enforce_cache_limit(self):
        
        with self._stats_lock:
            if self._stats["cache_size_bytes"] <= self.max_cache_bytes:
                return
        

        files = []
        for root, _, filenames in os.walk(self.cache_dir):
            for f in filenames:
                if f.endswith(".png"):
                    fp = os.path.join(root, f)
                    files.append((fp, os.path.getmtime(fp), os.path.getsize(fp)))
        

        files.sort(key=lambda x: x[1])
        
        current_size = sum(f[2] for f in files)
        target_size = self.max_cache_bytes * 0.8
        
        for fp, _, size in files:
            if current_size <= target_size:
                break
            try:
                os.remove(fp)
                current_size -= size
            except Exception:
                pass
        
        self._update_cache_stats()

    def download_region(self, lat_min: float, lon_min: float, 
                        lat_max: float, lon_max: float,
                        zoom_levels: List[int]) -> Dict[str, Any]:
        










        results = {"requested": 0, "downloaded": 0, "cached": 0, "errors": 0, "bytes": 0}


        valid_zoom_levels = [z for z in zoom_levels if isinstance(z, int) and 0 <= z <= 19]
        if len(valid_zoom_levels) != len(zoom_levels):
            results["errors"] += 1

        for z in valid_zoom_levels:

            def latlon_to_tile(lat, lon, zoom):
                lat_rad = math.radians(lat)
                n = 2.0 ** zoom
                x = int((lon + 180.0) / 360.0 * n)
                y = int((1.0 - math.log(math.tan(lat_rad) + (1 / math.cos(lat_rad))) / math.pi) / 2.0 * n)
                return x, y
            
            x_min, y_max = latlon_to_tile(lat_min, lon_min, z)
            x_max, y_min = latlon_to_tile(lat_max, lon_max, z)
            

            x_min, x_max = min(x_min, x_max), max(x_min, x_max)
            y_min, y_max = min(y_min, y_max), max(y_min, y_max)
            

            max_tiles = 500
            total_tiles = (x_max - x_min + 1) * (y_max - y_min + 1)
            if total_tiles > max_tiles:

                cx, cy = (x_min + x_max) // 2, (y_min + y_max) // 2
                half = int(math.sqrt(max_tiles) // 2)
                x_min, x_max = max(0, cx - half), cx + half
                y_min, y_max = max(0, cy - half), cy + half
            
            for x in range(x_min, x_max + 1):
                for y in range(y_min, y_max + 1):
                    results["requested"] += 1
                    data, meta = self.get_tile(z, x, y)
                    if data:
                        if meta.get("cache_hit"):
                            results["cached"] += 1
                        else:
                            results["downloaded"] += 1
                            results["bytes"] += meta.get("size", 0)
                    else:
                        results["errors"] += 1
        
        return results

    def get_stats(self) -> Dict[str, Any]:
        
        with self._stats_lock:
            stats = dict(self._stats)
        stats["cache_size_mb"] = round(stats["cache_size_bytes"] / (1024 * 1024), 2)
        stats["cache_dir"] = self.cache_dir
        stats["max_cache_mb"] = self.max_cache_bytes // (1024 * 1024)
        return stats

    def clear_cache(self) -> Dict[str, Any]:
        
        removed = 0
        for root, _, files in os.walk(self.cache_dir):
            for f in files:
                if f.endswith(".png"):
                    try:
                        os.remove(os.path.join(root, f))
                        removed += 1
                    except Exception:
                        pass
        self._update_cache_stats()
        return {"removed_files": removed, "cache_dir": self.cache_dir}

    def get_server_nodes(self) -> Dict[str, Any]:
        
        return self.server_nodes





class ComputeProfile:
    




    LEVEL_MULTIPLIERS = [0.5, 0.6, 0.75, 0.9, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0]

    def __init__(self):
        self.detect()

    def detect(self):
        self.cuda_available = torch.cuda.is_available()
        self.gpus = torch.cuda.device_count() if self.cuda_available else 0
        self.gpu_names = [torch.cuda.get_device_name(i) for i in range(self.gpus)] if self.cuda_available else []
        self.distributed = bool(os.environ.get("WORLD_SIZE") and os.environ.get("RANK") is not None)
        self.world_size = int(os.environ.get("WORLD_SIZE", 1))
        self.rank = int(os.environ.get("RANK", 0))
        self.local_rank = int(os.environ.get("LOCAL_RANK", 0))
        self.master_addr = os.environ.get("MASTER_ADDR", "localhost")
        self.master_port = os.environ.get("MASTER_PORT", "29500")

    def apply(self, base_batch: int, compute_level: int, use_cluster: bool):
        



        level = max(1, min(10, compute_level))
        m = self.LEVEL_MULTIPLIERS[level - 1]
        batch = max(1, int(round(base_batch * m)))

        grad_accum = max(1, 5 - level // 2)
        gpus_used = self.gpus if (use_cluster and self.gpus > 1) else 1
        if gpus_used > 1:
            batch = max(1, batch * gpus_used)
        return batch, grad_accum, gpus_used

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cuda_available": self.cuda_available,
            "gpus": self.gpus,
            "gpu_names": self.gpu_names,
            "distributed": self.distributed,
            "world_size": self.world_size,
            "rank": self.rank,
            "local_rank": self.local_rank,
            "master_addr": self.master_addr,
            "master_port": self.master_port,
            "level_multipliers": self.LEVEL_MULTIPLIERS,
        }





DEFAULT_ONLINE_SOURCES: List[Dict[str, Any]] = [
    {
        "id": "pytorch_readme",
        "name": "PyTorch README",
        "url": "https://raw.githubusercontent.com/pytorch/pytorch/main/README.md",
        "type": "markdown",
        "max_chars": 50000,
    },
    {
        "id": "huggingface_readme",
        "name": "🤗 Transformers README",
        "url": "https://raw.githubusercontent.com/huggingface/transformers/main/README.md",
        "type": "markdown",
        "max_chars": 50000,
    },
    {
        "id": "karpathy_makemore",
        "name": "karpathy makemore README",
        "url": "https://raw.githubusercontent.com/karpathy/makemore/master/README.md",
        "type": "markdown",
        "max_chars": 30000,
    },
]


def _strip_html_tags(text: str) -> str:
    
    out = []
    in_tag = False
    for c in text:
        if c == '<':
            in_tag = True
        elif c == '>':
            in_tag = False
        elif not in_tag:
            out.append(c)
    return "".join(out)


def fetch_online_text(url: str, max_chars: int = 50000, timeout: int = 15) -> Tuple[str, Dict[str, Any]]:
    



    meta = {"url": url, "bytes": 0, "status": "ok", "error": None}
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "AGIPyAG-ChaosEngine/9.0 (Research; contact@agipyag.local)",
            "Accept": "text/plain,text/markdown,text/html,*/*",
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = resp.read()
            meta["bytes"] = len(data)
            text = data.decode("utf-8", errors="ignore")
            if "<html" in text[:500].lower():
                text = _strip_html_tags(text)
            text = text[:max_chars]
            return text, meta
    except Exception as e:
        meta["status"] = "error"
        meta["error"] = str(e)
        return "", meta


def augment_corpus_online(engine: "AGIEngine", sources: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    


    sources = sources or DEFAULT_ONLINE_SOURCES
    total_chars = 0
    fetched = 0
    errors = 0
    lines: List[str] = []

    for src in sources:
        url = src.get("url", "")
        max_chars = src.get("max_chars", 50000)
        engine.log(f"[online] 正在拉取 {src.get('name', url)} ...")
        text, meta = fetch_online_text(url, max_chars=max_chars)
        engine.network_tracer.trace_data_download(url, bytes_in=meta.get("bytes", 0), content_type=src.get("type", "text"))
        if meta["status"] != "ok" or not text:
            engine.log(f"[online] 拉取失败 {url}: {meta.get('error')}")
            errors += 1
            continue
        lines.append(f"\n\n# 在线语料: {src.get('name', url)}\n\n{text}\n")
        total_chars += len(text)
        fetched += 1

    if lines:
        with open(CORPUS_PATH, "a", encoding="utf-8", errors="ignore") as f:
            f.write("\n".join(lines))
        engine._tokenize_corpus()
        engine.log(f"[online] 联网语料增强完成: {fetched} 个源, {total_chars} 字符")
    else:
        engine.log("[online] 没有拉取到任何在线语料")

    return {"fetched": fetched, "errors": errors, "total_chars": total_chars, "corpus_path": CORPUS_PATH}





class NetworkTracer:
    









    NODES = {

        "local_server": {"lat": 39.9, "lon": 116.4, "label": "本地服务器", "type": "server", "region": "北京"},
        "user_client": {"lat": 31.2, "lon": 121.5, "label": "用户终端", "type": "client", "region": "上海"},

        "openai_api": {"lat": 37.8, "lon": -122.4, "label": "OpenAI API", "type": "ai_service", "region": "旧金山"},
        "anthropic_api": {"lat": 37.8, "lon": -122.4, "label": "Anthropic API", "type": "ai_service", "region": "旧金山"},
        "google_api": {"lat": 37.4, "lon": -122.1, "label": "Google AI", "type": "ai_service", "region": "山景城"},
        "azure_api": {"lat": 47.6, "lon": -122.3, "label": "Azure OpenAI", "type": "ai_service", "region": "西雅图"},
        "huggingface": {"lat": 48.9, "lon": 2.3, "label": "HuggingFace", "type": "ai_service", "region": "巴黎"},

        "github": {"lat": 37.8, "lon": -122.4, "label": "GitHub", "type": "data_source", "region": "旧金山"},
        "pypi": {"lat": 40.7, "lon": -74.0, "label": "PyPI", "type": "data_source", "region": "纽约"},
        "npm": {"lat": 37.8, "lon": -122.4, "label": "NPM Registry", "type": "data_source", "region": "旧金山"},
        "docker_hub": {"lat": 37.8, "lon": -122.4, "label": "Docker Hub", "type": "data_source", "region": "旧金山"},

        "arxiv": {"lat": 40.7, "lon": -74.0, "label": "arXiv", "type": "data_source", "region": "纽约"},
        "wikipedia": {"lat": 37.8, "lon": -122.4, "label": "Wikipedia", "type": "data_source", "region": "旧金山"},
        "common_crawl": {"lat": 39.0, "lon": -77.0, "label": "Common Crawl", "type": "data_source", "region": "华盛顿"},

        "cloudflare": {"lat": 37.8, "lon": -122.4, "label": "Cloudflare", "type": "cdn", "region": "旧金山"},
        "fastly": {"lat": 37.8, "lon": -122.4, "label": "Fastly", "type": "cdn", "region": "旧金山"},

        "tencent_cloud": {"lat": 22.5, "lon": 114.1, "label": "腾讯云", "type": "cloud", "region": "深圳"},
        "aliyun": {"lat": 30.3, "lon": 120.2, "label": "阿里云", "type": "cloud", "region": "杭州"},
        "baidu_ai": {"lat": 39.9, "lon": 116.4, "label": "百度AI", "type": "ai_service", "region": "北京"},

        "deepmind": {"lat": 51.5, "lon": -0.1, "label": "DeepMind", "type": "ai_service", "region": "伦敦"},
        "mistral": {"lat": 48.9, "lon": 2.3, "label": "Mistral AI", "type": "ai_service", "region": "巴黎"},

        "sakana_ai": {"lat": 35.7, "lon": 139.7, "label": "Sakana AI", "type": "ai_service", "region": "东京"},
        "qwen": {"lat": 30.3, "lon": 120.2, "label": "通义千问", "type": "ai_service", "region": "杭州"},
    }

    def __init__(self, max_records: int = 10000):
        self._records: deque = deque(maxlen=max_records)
        self._lock = threading.Lock()
        self._active_connections: Dict[str, Dict[str, Any]] = {}
        self._conn_lock = threading.Lock()
        self._total_bytes_in = 0
        self._total_bytes_out = 0
        self._blocked_count = 0
        self._hostname_cache: Dict[str, str] = {}

    def _resolve_node(self, url_or_host: str) -> tuple:
        
        if not url_or_host:
            return "unknown", {"lat": 0, "lon": 0, "label": "未知", "type": "unknown", "region": "未知"}
        

        host = url_or_host
        if "://" in host:
            try:
                host = urllib.parse.urlparse(host).hostname or host
            except Exception:
                pass
        host = host.lower().split(":")[0]
        

        if host in self._hostname_cache:
            key = self._hostname_cache[host]
            return key, self.NODES.get(key, self.NODES["local_server"])
        

        keyword_map = {
            "openai": "openai_api", "api.openai": "openai_api", "chatgpt": "openai_api",
            "anthropic": "anthropic_api", "claude": "anthropic_api",
            "google": "google_api", "gemini": "google_api", "generativelanguage": "google_api",
            "azure": "azure_api", "openai.azure": "azure_api",
            "huggingface": "huggingface", "hf.co": "huggingface",
            "github": "github", "raw.githubusercontent": "github",
            "pypi": "pypi", "pythonhosted": "pypi",
            "npmjs": "npm", "registry.npmjs": "npm",
            "docker": "docker_hub", "hub.docker": "docker_hub",
            "arxiv": "arxiv", "export.arxiv": "arxiv",
            "wikipedia": "wikipedia", "wikimedia": "wikipedia",
            "commoncrawl": "common_crawl",
            "cloudflare": "cloudflare", "cdnjs": "cloudflare",
            "fastly": "fastly",
            "tencent": "tencent_cloud", "qcloud": "tencent_cloud",
            "aliyun": "aliyun", "alibaba": "aliyun",
            "baidu": "baidu_ai", "bcebos": "baidu_ai",
            "deepmind": "deepmind", "googleapis": "google_api",
            "mistral": "mistral",
            "sakana": "sakana_ai",
            "qwen": "qwen", "aliyun.com": "qwen",
        }
        
        for kw, node_key in keyword_map.items():
            if kw in host:
                self._hostname_cache[host] = node_key
                return node_key, self.NODES[node_key]
        

        try:
            ip = socket.gethostbyname(host)

            if ip.startswith("127.") or ip.startswith("192.168.") or ip.startswith("10."):
                self._hostname_cache[host] = "local_server"
                return "local_server", self.NODES["local_server"]
        except Exception:
            pass
        
        self._hostname_cache[host] = "unknown"
        return "unknown", {"lat": 0, "lon": 0, "label": host[:30], "type": "unknown", "region": "未知"}

    def trace(
        self,
        action: str,
        target: str,
        source: str = "local",
        method: str = "GET",
        status_code: Optional[int] = None,
        bytes_in: int = 0,
        bytes_out: int = 0,
        duration_ms: Optional[float] = None,
        auth_type: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        
        node_key, node_info = self._resolve_node(target)
        
        record = {
            "id": f"{time.time():.6f}-{threading.current_thread().ident}",
            "timestamp": datetime.now().isoformat(timespec="milliseconds"),
            "action": action,
            "target": target,
            "target_node": node_key,
            "target_region": node_info["region"],
            "target_lat": node_info["lat"],
            "target_lon": node_info["lon"],
            "source": source,
            "method": method,
            "status_code": status_code,
            "bytes_in": bytes_in,
            "bytes_out": bytes_out,
            "duration_ms": duration_ms,
            "auth_type": auth_type or "none",
            "details": details or {},
        }
        
        with self._lock:
            self._records.append(record)
            self._total_bytes_in += bytes_in
            self._total_bytes_out += bytes_out
            if auth_type == "blocked" or status_code in (401, 403, 407):
                self._blocked_count += 1
        

        conn_key = f"{source}->{node_key}"
        with self._conn_lock:
            self._active_connections[conn_key] = {
                "source": source,
                "target": node_key,
                "target_lat": node_info["lat"],
                "target_lon": node_info["lon"],
                "last_active": record["timestamp"],
                "action": action,
                "bytes_total": bytes_in + bytes_out,
            }
        
        return record

    def trace_api_call(self, endpoint: str, client_ip: str, method: str = "GET",
                       status_code: int = 200, duration_ms: float = 0,
                       auth_type: str = "token") -> Dict[str, Any]:
        
        return self.trace(
            action="api_call",
            target=endpoint,
            source=client_ip,
            method=method,
            status_code=status_code,
            bytes_out=0,
            duration_ms=duration_ms,
            auth_type=auth_type,
        )

    def trace_ai_inference(self, service: str, model: str, tokens_in: int = 0,
                           tokens_out: int = 0, duration_ms: float = 0) -> Dict[str, Any]:
        
        return self.trace(
            action="ai_inference",
            target=service,
            source="AGIEngine",
            method="POST",
            bytes_out=tokens_in * 4,
            bytes_in=tokens_out * 4,
            duration_ms=duration_ms,
            auth_type="api_key",
            details={"model": model, "tokens_in": tokens_in, "tokens_out": tokens_out},
        )

    def trace_data_download(self, url: str, bytes_in: int = 0,
                            content_type: str = "unknown") -> Dict[str, Any]:
        
        return self.trace(
            action="data_download",
            target=url,
            source="AGIEngine",
            bytes_in=bytes_in,
            auth_type="none",
            details={"content_type": content_type},
        )

    def trace_web_scrape(self, url: str, bytes_in: int = 0,
                         status_code: int = 200) -> Dict[str, Any]:
        
        return self.trace(
            action="web_scrape",
            target=url,
            source="AGIEngine",
            bytes_in=bytes_in,
            status_code=status_code,
            auth_type="none",
        )

    def get_records(self, limit: int = 500, action_filter: Optional[str] = None,
                    since_minutes: Optional[int] = None) -> List[Dict[str, Any]]:
        
        with self._lock:
            records = list(self._records)
        
        if since_minutes:
            cutoff = datetime.now() - timedelta(minutes=since_minutes)
            records = [r for r in records if datetime.fromisoformat(r["timestamp"]) > cutoff]
        
        if action_filter:
            records = [r for r in records if r["action"] == action_filter]
        
        return records[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        
        with self._lock:
            records = list(self._records)
        
        actions = {}
        regions = {}
        auth_types = {}
        for r in records:
            actions[r["action"]] = actions.get(r["action"], 0) + 1
            regions[r["target_region"]] = regions.get(r["target_region"], 0) + 1
            auth_types[r["auth_type"]] = auth_types.get(r["auth_type"], 0) + 1
        
        return {
            "total_requests": len(records),
            "total_bytes_in": self._total_bytes_in,
            "total_bytes_out": self._total_bytes_out,
            "blocked_count": self._blocked_count,
            "active_connections": len(self._active_connections),
            "action_breakdown": actions,
            "region_breakdown": regions,
            "auth_breakdown": auth_types,
            "nodes": self.NODES,
        }

    def get_active_connections(self) -> List[Dict[str, Any]]:
        
        with self._conn_lock:
            return list(self._active_connections.values())

    def get_nodes(self) -> Dict[str, Any]:
        
        return self.NODES





class ChaoticMemoryManager:
    

    def __init__(self, engine: Optional["AGIEngine"] = None):
        self.engine = engine
        self._bank: Optional[ZeroShotChaoticMemoryBank] = None
        self._lock = threading.Lock()
        self._text_to_idx: Dict[str, int] = {}
        self._idx_to_text: Dict[int, str] = {}

    def _embed(self, text: str) -> List[float]:
        
        if self.engine is not None and getattr(self.engine, "embedder", None) is not None:
            return self.engine.embedder.embed(text)
        return HashEmbedder(self._bank.memory_dim if self._bank else 384).embed(text)

    @property
    def bank(self) -> Optional[ZeroShotChaoticMemoryBank]:
        return self._bank

    def create(
        self,
        memory_dim: int = 384,
        capacity: float = 0.6,
        max_memories: int = 4096,
    ) -> Dict[str, Any]:
        
        with self._lock:
            self._bank = ZeroShotChaoticMemoryBank(
                memory_dim=memory_dim,
                capacity=capacity,
                max_memories=max_memories,
                direct_encode=True,
            )
            self._text_to_idx.clear()
            self._idx_to_text.clear()
            return {
                "status": "created",
                "memory_dim": memory_dim,
                "capacity": capacity,
                "max_memories": max_memories,
            }

    def write(self, text: str, embedding: Optional[List[float]] = None) -> Dict[str, Any]:
        
        if self._bank is None:
            raise RuntimeError("记忆库未创建，请先 POST /api/memory/create")

        with self._lock:
            if embedding is not None:
                vec = torch.tensor(embedding, dtype=torch.float32)
            else:
                vec = torch.tensor(self._embed(text), dtype=torch.float32)
            idx = self._bank.write_embedding(vec)
            self._text_to_idx[text] = idx
            self._idx_to_text[idx] = text
            return {"status": "written", "index": idx, "text": text[:200]}

    def retrieve(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        mode: str = "associative",
    ) -> Dict[str, Any]:
        
        if self._bank is None:
            raise RuntimeError("记忆库未创建")

        q = torch.tensor(query_embedding, dtype=torch.float32)
        raw_vecs, scores, indices = self._bank.retrieve_raw(q, top_k=top_k, mode=mode)

        results = []
        for i in range(len(indices)):
            idx = int(indices[i].item())
            text = self._idx_to_text.get(idx, f"<memory #{idx}>")
            score = float(scores[i].item())

            if not (score == score and abs(score) != float("inf")):
                score = 0.0
            results.append({
                "index": idx,
                "text": text[:200],
                "score": score,
            })

        return {"results": results, "top_k": top_k, "mode": mode}

    def stats(self) -> Dict[str, Any]:
        
        if self._bank is None:
            return {"status": "not_created"}
        stats = self._bank.get_stats()
        stats["stored_texts"] = len(self._text_to_idx)
        stats["memory_dim"] = self._bank.memory_dim
        stats["capacity"] = self._bank.capacity
        stats["max_memories"] = self._bank.max_memories
        return stats

    def decay(self, steps: int = 1) -> Dict[str, Any]:
        
        if self._bank is None:
            raise RuntimeError("记忆库未创建")
        for _ in range(steps):
            self._bank.step_decay()
        return {"status": "decayed", "steps": steps, "stats": self._bank.get_stats()}

    def consolidate(self, steps: int = 5) -> Dict[str, Any]:
        
        if self._bank is None:
            raise RuntimeError("记忆库未创建")
        self._bank.offline_consolidate(steps=steps)
        return {"status": "consolidated", "steps": steps, "stats": self._bank.get_stats()}

    def reset(self) -> Dict[str, Any]:
        
        with self._lock:
            self._bank = None
            self._text_to_idx.clear()
            self._idx_to_text.clear()
        return {"status": "reset"}

    def write_bulk(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        
        if self._bank is None:
            raise RuntimeError("记忆库未创建")
        written = 0
        with self._lock:
            for item in items:
                text = item.get("text", "")
                emb = item.get("embedding")
                if emb is not None:
                    vec = torch.tensor(emb, dtype=torch.float32)
                else:
                    vec = torch.tensor(self._embed(text), dtype=torch.float32)
                idx = self._bank.write_embedding(vec)
                self._text_to_idx[text] = idx
                self._idx_to_text[idx] = text
                written += 1
        return {"status": "bulk_written", "count": written}

    def retrieve_by_text(self, text: str, top_k: int = 5, mode: str = "associative") -> Dict[str, Any]:
        
        if self._bank is None:
            raise RuntimeError("记忆库未创建")
        emb = self._embed(text)
        return self.retrieve(emb, top_k=top_k, mode=mode)




    @staticmethod
    def _banks_dir() -> str:
        d = os.path.join(DATA_DIR, "memory_banks")
        os.makedirs(d, exist_ok=True)
        return d

    @staticmethod
    def _sanitize_name(name: str) -> str:
        
        if "/" in name or "\\" in name or ".." in name:
            raise ValueError(f"记忆库名称含非法字符: {name!r}")
        safe = "".join(c for c in name if c.isalnum() or c in "._-").strip(".")
        if not safe or safe != name.strip("."):
            raise ValueError(f"记忆库名称非法: {name!r}")
        return safe

    def save(self, name: str) -> Dict[str, Any]:
        
        if self._bank is None:
            raise RuntimeError("记忆库未创建，无内容可保存")
        name = self._sanitize_name(name)
        path = os.path.join(self._banks_dir(), f"{name}.pt")
        with self._lock:
            payload = {
                "version": 1,
                "saved_at": datetime.now().isoformat(timespec="seconds"),
                "config": {
                    "memory_dim": self._bank.memory_dim,
                    "capacity": self._bank.capacity,
                    "max_memories": self._bank.max_memories,
                    "decay_rate": self._bank.decay_rate,
                    "energy_boost": self._bank.energy_boost,
                    "direct_encode": self._bank.direct_encode,
                },
                "state_dict": {k: v.cpu() for k, v in self._bank.state_dict().items()},
                "mem_count": self._bank.pool.mem_count,
                "text_to_idx": dict(self._text_to_idx),
                "idx_to_text": {int(k): v for k, v in self._idx_to_text.items()},
            }
            torch.save(payload, path)
        return {
            "status": "saved",
            "name": name,
            "path": path,
            "mem_count": payload["mem_count"],
            "stored_texts": len(self._text_to_idx),
            "size_bytes": os.path.getsize(path),
        }

    def load(self, name: str) -> Dict[str, Any]:
        
        name = self._sanitize_name(name)
        path = os.path.join(self._banks_dir(), f"{name}.pt")
        if not os.path.isfile(path):
            raise FileNotFoundError(f"记忆库 '{name}' 不存在: {path}")
        try:
            payload = torch.load(path, map_location="cpu", weights_only=True)
        except Exception:

            payload = torch.load(path, map_location="cpu", weights_only=False)
        cfg = payload["config"]
        with self._lock:
            bank = ZeroShotChaoticMemoryBank(
                memory_dim=cfg["memory_dim"],
                capacity=cfg["capacity"],
                max_memories=cfg["max_memories"],
                decay_rate=cfg.get("decay_rate", 0.995),
                energy_boost=cfg.get("energy_boost", 0.05),
                direct_encode=cfg.get("direct_encode", True),
            )
            bank.load_state_dict(payload["state_dict"])
            bank.pool.mem_count = int(payload["mem_count"])
            for p in bank.parameters():
                p.requires_grad = False
            self._bank = bank
            self._text_to_idx = dict(payload.get("text_to_idx", {}))
            self._idx_to_text = {int(k): v for k, v in payload.get("idx_to_text", {}).items()}
        return {
            "status": "loaded",
            "name": name,
            "mem_count": bank.pool.mem_count,
            "stored_texts": len(self._text_to_idx),
            "memory_dim": cfg["memory_dim"],
            "saved_at": payload.get("saved_at"),
        }

    def list_banks(self) -> Dict[str, Any]:
        
        banks = []
        d = self._banks_dir()
        for fn in sorted(os.listdir(d)):
            if not fn.endswith(".pt"):
                continue
            fp = os.path.join(d, fn)
            try:

                payload = torch.load(fp, map_location="cpu", weights_only=True)
                banks.append({
                    "name": fn[:-3],
                    "mem_count": int(payload.get("mem_count", 0)),
                    "stored_texts": len(payload.get("text_to_idx", {})),
                    "memory_dim": payload.get("config", {}).get("memory_dim"),
                    "saved_at": payload.get("saved_at"),
                    "size_bytes": os.path.getsize(fp),
                })
            except Exception:
                banks.append({"name": fn[:-3], "error": "无法读取", "size_bytes": os.path.getsize(fp)})
        return {"banks": banks, "dir": d}





def build_corpus(force: bool = False) -> Dict[str, Any]:
    
    if os.path.exists(CORPUS_PATH) and not force:
        with open(CORPUS_PATH, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        return {"path": CORPUS_PATH, "chars": len(text), "rebuilt": False}

    chunks: List[str] = []

    for root, _dirs, files in os.walk(_PROJECT_ROOT):
        if "node_modules" in root or "__pycache__" in root or ".git" in root:
            continue
        for fn in files:
            fp = os.path.join(root, fn)
            try:
                if fn.endswith(".md"):
                    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                        chunks.append(f.read()[:20000])
                elif fn.endswith(".py"):
                    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            s = line.strip()
                            if s.startswith("#") and len(s) > 12:
                                chunks.append(s.lstrip("# ").strip())
            except Exception:
                continue


    seed = """
混沌神经网络通过非线性动力学实现自适应计算分配，Lyapunov 指数刻画系统的混沌强度。
StarLight 模型使用双数种子嵌入，将每个 token 映射为四维双数向量 [a, b, c, d]。
种子引导采样器根据隐藏状态动态调整温度，混沌越强温度越高，生成越发散。
Lorenz 吸引子由 sigma rho beta 三个参数控制，是著名的混沌动力系统。
融合门控在混沌模型与稳定模型的 logits 之间做加权融合，兼顾创造力与稳定性。
企业级安全体系包含 Fernet 对称加密、RSA 非对称加密、入侵检测、异常检测与行为监控。
Hebbian 自适应层遵循一起激活的神经元连接增强原则，实现无监督可塑性。
Hopf 分岔注意力在临界点附近产生振荡，为注意力注入节律性。
量子纠缠注意力利用纠缠态表示 token 间的长程关联。
秩保护锚点防止种子表示坍缩到低秩子空间，保持表达能力。
训练防火墙执行 NaN 检测、损失尖峰 EMA 检测与权重抽样检测，保障训练稳定。
混合精度训练在 BF16 设备上无需梯度缩放器，FP16 设备必须先 unscale 再裁剪梯度。
进化调度器根据训练进度动态调整超参数，实现自我进化。
知识蒸馏将教师模型的暗知识迁移到学生模型，离线模式使用预生成 logits。
AGI 的目标是通用人工智能，需要感知、推理、规划、记忆与自我进化的闭环。
"""
    chunks.append("\n".join([seed.strip()] * 40))

    text = "\n".join(c for c in chunks if c and c.strip())
    with open(CORPUS_PATH, "w", encoding="utf-8") as f:
        f.write(text)
    return {"path": CORPUS_PATH, "chars": len(text), "rebuilt": True}





class TrainingManager:
    

    def __init__(self, engine: "AGIEngine"):
        self.engine = engine
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self.state: Dict[str, Any] = {
            "running": False,
            "model": None,
            "phase": 4,
            "step": 0,
            "total_steps": 0,
            "loss": None,
            "lr": None,
            "lyap": None,
            "grad_norm": None,
            "started_at": None,
            "elapsed": 0.0,
            "message": "idle",
            "checkpoint": None,
            "compute_level": 5,
            "use_cluster": False,
            "use_online_data": False,
            "gpus_used": 1,
            "grad_accum": 1,
        }
        self.loss_history: deque = deque(maxlen=1000)
        self.lyap_history: deque = deque(maxlen=1000)
        self._compute_profile: Optional[Dict[str, Any]] = None


    def _train_starlight(self, steps: int, batch: int, lr: float, seq_len: int):
        eng = self.engine
        model = eng.starlight
        device = eng.device
        model.train()


        gpus_used = self._compute_profile.get("gpus_used", 1) if self._compute_profile else 1
        grad_accum = self._compute_profile.get("grad_accum", 1) if self._compute_profile else 1
        if gpus_used > 1 and torch.cuda.device_count() >= gpus_used:
            model = torch.nn.DataParallel(model, device_ids=list(range(gpus_used)))
            eng.log(f"[train] 启用 DataParallel gpus={gpus_used}")

        ids = eng.corpus_ids
        if ids is None or len(ids) < seq_len + 2:
            raise RuntimeError("语料 token 数量不足，无法训练")

        opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
        has_bf16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
        use_amp = device.type == "cuda"
        amp_dtype = torch.bfloat16 if has_bf16 else torch.float16
        scaler = torch.amp.GradScaler("cuda", enabled=(use_amp and not has_bf16))

        n = len(ids)
        t0 = time.time()
        ema_loss = None
        for step in range(1, steps + 1):
            if self._stop.is_set():
                with self._lock:
                    self.state["message"] = "stopped by user"
                break


            starts = torch.randint(0, n - seq_len - 1, (batch,))
            x = torch.stack([ids[s:s + seq_len] for s in starts]).to(device, non_blocking=True)

            with torch.amp.autocast("cuda", dtype=amp_dtype, enabled=use_amp):
                logits, aux = model(x, labels=x)
                loss = aux["total_loss"] / grad_accum


            if not torch.isfinite(loss):
                lm_loss = aux.get("lm_loss")
                if lm_loss is not None and torch.isfinite(lm_loss):
                    loss = lm_loss / grad_accum
                    eng.log(f"[train] step {step}: 总损失非有限，已回退到 LM 损失")
                else:
                    eng.log(f"[train] step {step}: 非有限损失，跳过")
                    continue


            if scaler is not None and scaler.is_enabled():
                scaler.scale(loss).backward()
            else:
                loss.backward()


            is_update_step = (step % grad_accum == 0) or (step == steps)
            if is_update_step:
                if scaler is not None and scaler.is_enabled():
                    scaler.unscale_(opt)
                    gn = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    scaler.step(opt)
                    scaler.update()
                else:
                    gn = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    opt.step()
                opt.zero_grad(set_to_none=True)
            else:
                gn = torch.tensor(0.0)


            lv = loss.item() * grad_accum
            ema_loss = lv if ema_loss is None else 0.95 * ema_loss + 0.05 * lv
            lyap = None
            aux_losses = getattr(eng.starlight, "aux_losses", {}) or {}
            if "lyap" in aux_losses and isinstance(aux_losses["lyap"], dict):
                lyap = aux_losses["lyap"].get("lyap")

            with self._lock:
                self.state.update({
                    "step": step, "loss": round(ema_loss, 5), "lr": lr,
                    "lyap": round(lyap, 4) if lyap is not None else None,
                    "grad_norm": round(float(gn), 4),
                    "elapsed": round(time.time() - t0, 1),
                    "message": "training",
                    "gpus_used": gpus_used,
                    "grad_accum": grad_accum,
                })
            self.loss_history.append({"step": step, "loss": round(lv, 5), "ema": round(ema_loss, 5)})
            if lyap is not None:
                self.lyap_history.append({"step": step, "lyap": round(float(lyap), 4)})

            if step % 50 == 0:
                eng.log(f"[train] step {step}/{steps} ema_loss={ema_loss:.4f} gn={float(gn):.3f} batch={batch} accum={grad_accum} gpus={gpus_used}")




            _DISK_INTERVAL = 1000
            if step % 100 == 0:
                eng.train_step_counter = step
                last_disk = getattr(eng, "_last_starlight_disk", 0)
                if step - last_disk >= _DISK_INTERVAL:
                    eng.save_starlight()
                    eng._last_starlight_disk = step

        eng.train_step_counter = self.state["step"]
        eng.save_starlight()


    def _train_chaos(self, steps: int, batch: int, lr: float):
        eng = self.engine
        model = eng.chaos_nn
        model.train()
        opt = torch.optim.Adam(model.parameters(), lr=lr)


        traj = eng.lorenz_trajectory(n=4096)
        window = model.input_size // 3
        out_win = model.output_size // 3 + 1
        feats, tgts = [], []
        for i in range(len(traj) - window - out_win):
            feats.append(traj[i:i + window].flatten())
            tgt = traj[i + window:i + window + out_win].flatten()
            tgts.append(tgt[:model.output_size])
        X = torch.stack(feats)
        Y = torch.stack(tgts)

        t0 = time.time()
        ema_loss = None
        for step in range(1, steps + 1):
            if self._stop.is_set():
                with self._lock:
                    self.state["message"] = "stopped by user"
                break
            idx = torch.randint(0, len(X), (batch,))
            bx, by = X[idx], Y[idx]
            opt.zero_grad(set_to_none=True)
            loss, p_t, aux_loss = model.train_step(bx, by)
            if not torch.isfinite(loss):
                continue
            loss.backward()
            gn = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()

            lv = loss.item()
            ema_loss = lv if ema_loss is None else 0.95 * ema_loss + 0.05 * lv
            conv = model.training_stats["convergence_history"][-1] if model.training_stats["convergence_history"] else None
            with self._lock:
                self.state.update({
                    "step": step, "loss": round(ema_loss, 6), "lr": lr,
                    "lyap": round(float(conv), 4) if conv is not None else None,
                    "grad_norm": round(float(gn), 4),
                    "elapsed": round(time.time() - t0, 1),
                    "message": "training",
                })
            self.loss_history.append({"step": step, "loss": round(lv, 6), "ema": round(ema_loss, 6)})

        torch.save({"model_state": model.state_dict(), "step": self.state["step"]}, CHAOS_CKPT)
        with self._lock:
            self.state["checkpoint"] = CHAOS_CKPT
        eng.log(f"[train] ChaosNN 已保存: {CHAOS_CKPT}")


    def start(self, model_type: str, steps: int, batch: int, lr: float, seq_len: int, phase: int,
              compute_level: int = 5, use_cluster: bool = False, use_online_data: bool = False) -> Dict[str, Any]:
        if self._thread and self._thread.is_alive():
            return {"ok": False, "message": "训练已在运行中"}
        self._stop.clear()
        self.loss_history.clear()
        self.lyap_history.clear()


        profile = self.engine.compute_profile
        actual_batch, grad_accum, gpus_used = profile.apply(batch, compute_level, use_cluster)
        self._compute_profile = {
            "batch": actual_batch, "grad_accum": grad_accum, "gpus_used": gpus_used,
            "compute_level": compute_level, "use_cluster": use_cluster,
        }

        with self._lock:
            self.state.update({
                "running": True, "model": model_type, "phase": phase, "step": 0,
                "total_steps": steps, "loss": None, "lyap": None, "grad_norm": None,
                "started_at": datetime.now().isoformat(timespec="seconds"),
                "elapsed": 0.0, "message": "starting", "checkpoint": None,
                "compute_level": compute_level, "use_cluster": use_cluster,
                "use_online_data": use_online_data, "gpus_used": gpus_used,
                "grad_accum": grad_accum, "batch": actual_batch,
            })


        if use_online_data:
            self.engine.log("[train] 联网训练开启，正在增强语料...")
            augment_corpus_online(self.engine)

        def runner():
            try:
                if model_type == "full":

                    self.engine.log("[train] 课程式训练启动: StarLight -> ChaosNN")
                    self._train_starlight(steps // 2, actual_batch, lr, seq_len)
                    if not self._stop.is_set():
                        self._train_chaos(steps // 2, actual_batch, lr)
                elif model_type == "chaos":
                    self._train_chaos(steps, actual_batch, lr)
                else:
                    self._train_starlight(steps, actual_batch, lr, seq_len)
                with self._lock:
                    if self.state["message"] == "training":
                        self.state["message"] = "completed"
            except Exception as e:
                self.engine.log(f"[train] 异常: {e}\n{traceback.format_exc()}")
                with self._lock:
                    self.state["message"] = f"error: {e}"
            finally:
                self._cleanup_after_train()
                with self._lock:
                    self.state["running"] = False

        self._thread = threading.Thread(target=runner, daemon=True, name="TrainingManager")
        self._thread.start()
        return {
            "ok": True,
            "message": f"真实训练已启动 model={model_type} steps={steps} batch={actual_batch} lr={lr} level={compute_level} gpus={gpus_used}",
        }

    def _cleanup_after_train(self):
        
        try:
            model_type = self.state.get("model")
            step = self.state.get("step", 0)
            if step > 0:
                if model_type == "chaos":
                    self.engine.save_chaos()
                else:
                    self.engine.save_starlight()
                with self._lock:
                    if self.state.get("message") == "stopped by user":
                        self.state["message"] = "stopped by user · checkpoint saved"


            self.engine.starlight.eval()
            self.engine.chaos_nn.eval()
            if torch.cuda.is_available():
                torch.cuda.synchronize()
                torch.cuda.empty_cache()
            gc.collect()
            self.engine.log("[train] 训练显存已清理，模型已切回评估模式")
        except Exception as e:
            self.engine.log(f"[train] 训练清理异常: {e}")

    def stop(self) -> Dict[str, Any]:
        self._stop.set()
        return {"ok": True, "message": "停止信号已发送，训练线程将保存检查点并释放显存"}

    def status(self) -> Dict[str, Any]:
        with self._lock:
            s = dict(self.state)
        s["loss_history"] = list(self.loss_history)[-200:]
        s["lyap_history"] = list(self.lyap_history)[-200:]
        return s





class VocabBuilder:
    def __init__(self, engine: "AGIEngine"):
        self.engine = engine
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self.state: Dict[str, Any] = {"running": False, "message": "idle", "result": None}

    def start(self, vocab_size: int, model_type: str) -> Dict[str, Any]:
        if self._thread and self._thread.is_alive():
            return {"ok": False, "message": "词表构建正在进行中"}
        with self._lock:
            self.state = {"running": True, "message": "building", "result": None}

        def runner():
            try:
                import sentencepiece as spm
                build_corpus()
                prefix = os.path.join(VOCAB_BUILD_DIR, f"spm_{model_type}_{vocab_size}")
                cmd = (
                    f"--input={CORPUS_PATH} --model_prefix={prefix} "
                    f"--vocab_size={vocab_size} --model_type={model_type} "
                    f"--character_coverage=0.9995 --max_sentence_length=4192 "
                    f"--pad_id=0 --unk_id=1 --bos_id=2 --eos_id=3 "
                    f"--pad_piece=[PAD] --unk_piece=[UNK] --bos_piece=[BOS] --eos_piece=[EOS]"
                )
                self.engine.log(f"[vocab] SPM 训练开始 size={vocab_size} type={model_type}")
                spm.SentencePieceTrainer.Train(cmd)
                sp = spm.SentencePieceProcessor()
                sp.Load(f"{prefix}.model")
                pieces = [sp.IdToPiece(i) for i in range(min(40, sp.GetPieceSize()))]
                result = {
                    "model_path": f"{prefix}.model",
                    "vocab_size": sp.GetPieceSize(),
                    "model_type": model_type,
                    "sample_tokens": pieces,
                }
                self.engine.log(f"[vocab] 完成: {sp.GetPieceSize()} pieces")
                with self._lock:
                    self.state = {"running": False, "message": "completed", "result": result}
            except Exception as e:
                self.engine.log(f"[vocab] 异常: {e}")
                with self._lock:
                    self.state = {"running": False, "message": f"error: {e}", "result": None}

        self._thread = threading.Thread(target=runner, daemon=True, name="VocabBuilder")
        self._thread.start()
        return {"ok": True, "message": f"词表构建已启动 vocab_size={vocab_size} type={model_type}"}

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self.state)





class AGIEngine:
    def __init__(self):
        self.boot_time = time.time()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        cpu_threads = max(1, (os.cpu_count() or 4) - 2)
        torch.set_num_threads(cpu_threads)
        self.logs: deque = deque(maxlen=300)
        self._log_lock = threading.Lock()
        self._gen_lock = threading.Lock()
        self.train_step_counter = 0
        self.generate_counter = 0

        self.log(f"[engine] 启动 device={self.device}")


        self.security = SecurityManager()
        self.log("[engine] SecurityManager 就绪 (Fernet+RSA-2048+IDS+ADS)")


        self.tokenizer = SentencePieceTokenizer()
        self.log(f"[engine] 分词器就绪 vocab={self.tokenizer.vocab_size}")


        corpus_info = build_corpus()
        self.log(f"[engine] 语料就绪 chars={corpus_info['chars']}")
        self.corpus_ids: Optional[torch.Tensor] = None
        self._tokenize_corpus()


        self.starlight: StarLightModel = self._build_starlight()
        self.starlight_params = sum(p.numel() for p in self.starlight.parameters())
        self.log(f"[engine] StarLight 就绪 params={self.starlight_params/1e6:.2f}M")


        self.chaos_nn = ChaosNeuralNetwork(input_size=24, hidden_size=96, output_size=24,
                                           security_manager=self.security)
        if os.path.exists(CHAOS_CKPT):
            try:
                ck = torch.load(CHAOS_CKPT, map_location="cpu", weights_only=True)
                self.chaos_nn.load_state_dict(ck["model_state"])
                self.log(f"[engine] ChaosNN 检查点已加载 step={ck.get('step')}")
            except Exception as e:
                self.log(f"[engine] ChaosNN 检查点加载失败: {e}")
        self.chaos_engine = AGIChaosEngine(chaos_dim=64)


        self.trainer = TrainingManager(self)
        self.vocab_builder = VocabBuilder(self)


        self.embedder = StarLightEmbedder(
            self.starlight, self.tokenizer, memory_dim=384, device=str(self.device)
        )
        self.log("[engine] StarLightEmbedder 就绪 dim=384")


        vocab_size = self.tokenizer.vocab_size
        chaos_flat_dim = 3 * 64
        self.chaos_vocab_proj = torch.randn(chaos_flat_dim, vocab_size, device=self.device) / (vocab_size ** 0.5)
        self.log(f"[engine] 混沌投影矩阵就绪 {chaos_flat_dim}x{vocab_size}")


        self.memory = ChaoticMemoryManager(engine=self)


        self.network_tracer = NetworkTracer(max_records=10000)
        self.log("[engine] NetworkTracer 就绪 (全链路网络追踪)")


        self.map_tile_manager = MapTileManager(max_cache_mb=2048)
        self.log("[engine] MapTileManager 就绪 (OpenStreetMap 离线缓存)")


        self.compute_profile = ComputeProfile()
        self.log(f"[engine] ComputeProfile 就绪 gpus={self.compute_profile.gpus} distributed={self.compute_profile.distributed}")


        self.network_tracer.trace(
            action="internal",
            target="AGIEngine",
            source="system",
            details={"version": ENGINE_VERSION, "device": str(self.device)},
        )

        self.log("[engine] 全部子系统就绪")


    def log(self, msg: str):
        line = f"{datetime.now().strftime('%H:%M:%S')} {msg}"
        with self._log_lock:
            self.logs.append(line)

    def get_logs(self, n: int = 100) -> List[str]:
        with self._log_lock:
            return list(self.logs)[-n:]

    def _tokenize_corpus(self):
        with open(CORPUS_PATH, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        ids: List[int] = []
        for para in text.split("\n"):
            para = para.strip()
            if len(para) < 8:
                continue
            ids.extend(self.tokenizer.encode_text(para[:512], add_special_tokens=True))
            if len(ids) >= 300_000:
                break
        self.corpus_ids = torch.tensor(ids[:300_000], dtype=torch.long)
        self.log(f"[engine] 语料 token 化完成 tokens={len(self.corpus_ids)}")

    def _build_starlight(self) -> StarLightModel:
        cfg = StarLightConfig(
            vocab_size=self.tokenizer.vocab_size,
            hidden_dim=256,
            num_layers=4,
            num_heads=8,
            max_seq_len=128,
            dropout=0.1,
            pad_token_id=max(self.tokenizer.pad_id, 0),
            bos_token_id=self.tokenizer.bos_id if self.tokenizer.bos_id >= 0 else 2,
            eos_token_id=self.tokenizer.eos_id if self.tokenizer.eos_id >= 0 else 3,
            use_lyap_reg=True,
            use_rank_anchor=True,
            use_compile=False,
            compile_mode="default",
        )
        model = StarLightModel(cfg).to(self.device)
        if os.path.exists(STARLIGHT_CKPT):
            try:
                ck = torch.load(STARLIGHT_CKPT, map_location=self.device, weights_only=True)
                model.load_state_dict(ck["model_state"])
                self.train_step_counter = ck.get("step", 0)
                self.log(f"[engine] StarLight 检查点已加载 step={ck.get('step')} loss={ck.get('loss')}")
            except Exception as e:
                self.log(f"[engine] StarLight 检查点加载失败（使用随机初始化）: {e}")
        model.eval()
        return model

    def save_starlight(self):
        try:
            torch.save({
                "model_state": self.starlight.state_dict(),
                "step": self.train_step_counter,
                "loss": self.trainer.state.get("loss"),
                "saved_at": datetime.now().isoformat(timespec="seconds"),
            }, STARLIGHT_CKPT)
            with self.trainer._lock:
                self.trainer.state["checkpoint"] = STARLIGHT_CKPT
            self.log(f"[engine] StarLight 已保存 step={self.train_step_counter}")
        except Exception as e:
            self.log(f"[engine] StarLight 保存失败: {e}")

    def save_chaos(self):
        try:
            torch.save({
                "model_state": self.chaos_nn.state_dict(),
                "step": self.train_step_counter,
                "saved_at": datetime.now().isoformat(timespec="seconds"),
            }, CHAOS_CKPT)
            with self.trainer._lock:
                self.trainer.state["checkpoint"] = CHAOS_CKPT
            self.log(f"[engine] ChaosNN 已保存 step={self.train_step_counter}")
        except Exception as e:
            self.log(f"[engine] ChaosNN 保存失败: {e}")


    def export_starlight_onnx(self, output_path: str) -> Dict[str, Any]:
        
        try:
            os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
            self.starlight.eval()

            class StarLightONNXWrapper(nn.Module):
                def __init__(self, model):
                    super().__init__()
                    self.model = model

                def forward(self, input_ids):
                    logits, _ = self.model(input_ids)
                    return logits

            wrapped = StarLightONNXWrapper(self.starlight).to(self.device)
            dummy_input = torch.randint(
                0, self.tokenizer.vocab_size, (1, 32), device=self.device
            )
            torch.onnx.export(
                wrapped,
                dummy_input,
                output_path,
                input_names=["input_ids"],
                output_names=["logits"],
                dynamic_axes={
                    "input_ids": {0: "batch", 1: "seq_len"},
                    "logits": {0: "batch", 1: "seq_len"},
                },
                opset_version=14,
                do_constant_folding=True,
                dynamo=False,
            )
            size = os.path.getsize(output_path)
            self.log(f"[engine] StarLight ONNX 已导出: {output_path} ({size / 1024 / 1024:.2f} MB)")
            return {"ok": True, "path": output_path, "size_bytes": size}
        except Exception as e:
            self.log(f"[engine] StarLight ONNX 导出失败: {e}")
            return {"ok": False, "error": str(e)}

    def export_chaos_nn_onnx(self, output_path: str) -> Dict[str, Any]:
        




        try:
            os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

            class ChaosNNONNXWrapper(nn.Module):
                def __init__(self, model):
                    super().__init__()
                    self.register_buffer("W1", model.W1.detach().clone())
                    self.register_buffer("b1", model.b1.detach().clone())
                    self.register_buffer("W2", model.W2.detach().clone())
                    self.register_buffer("b2", model.b2.detach().clone())

                def forward(self, x):
                    if x.dim() == 1:
                        x = x.unsqueeze(0)
                    h = torch.relu(torch.mm(x, self.W1.t()) + self.b1.unsqueeze(0))
                    h = torch.clamp(h, -5.0, 5.0)
                    output = torch.mm(h, self.W2.t()) + self.b2.unsqueeze(0)
                    return output

            wrapped = ChaosNNONNXWrapper(self.chaos_nn).to(self.device)
            dummy_input = torch.randn(1, self.chaos_nn.input_size, device=self.device)
            torch.onnx.export(
                wrapped,
                dummy_input,
                output_path,
                input_names=["input"],
                output_names=["output"],
                dynamic_axes={
                    "input": {0: "batch"},
                    "output": {0: "batch"},
                },
                opset_version=14,
                do_constant_folding=True,
                dynamo=False,
            )
            size = os.path.getsize(output_path)
            self.log(f"[engine] ChaosNN ONNX 已导出: {output_path} ({size / 1024 / 1024:.2f} MB)")
            return {"ok": True, "path": output_path, "size_bytes": size, "note": "仅包含 MLP 推理核心，未包含混沌状态副作用"}
        except Exception as e:
            self.log(f"[engine] ChaosNN ONNX 导出失败: {e}")
            return {"ok": False, "error": str(e)}

    def open_models_dir(self) -> Dict[str, Any]:
        
        path = MODELS_DIR
        os.makedirs(path, exist_ok=True)

        real_path = os.path.realpath(path)
        real_base = os.path.realpath(MODELS_DIR)
        if not real_path.startswith(real_base + os.sep) and real_path != real_base:
            return {"ok": False, "path": path, "error": "目标目录不在允许的模型目录内"}
        system = platform.system()
        try:
            if system == "Windows":
                os.startfile(real_path)
            elif system == "Darwin":
                subprocess.Popen(["open", real_path])
            else:
                subprocess.Popen(["xdg-open", real_path])
            return {"ok": True, "path": real_path, "system": system}
        except Exception as e:
            return {"ok": False, "path": real_path, "error": str(e)}


    def health(self) -> Dict[str, Any]:
        return {
            "status": "ok",
            "version": ENGINE_VERSION,
            "device": f"{self.device}" + (f" ({torch.cuda.get_device_name(0)})" if self.device.type == "cuda" else ""),
            "checkpoint": STARLIGHT_CKPT if os.path.exists(STARLIGHT_CKPT) else "none",
            "uptime_s": round(time.time() - self.boot_time, 1),
            "vocab_size": self.tokenizer.vocab_size,
            "corpus_tokens": int(len(self.corpus_ids)) if self.corpus_ids is not None else 0,
            "train_steps_total": self.train_step_counter,
            "generations_total": self.generate_counter,
        }

    def model_info(self) -> Dict[str, Any]:
        cfg = self.starlight.config
        return {
            "params_m": round(self.starlight_params / 1e6, 2),
            "phase": 4,
            "device": str(self.device),
            "config": json.dumps(cfg.to_dict(), ensure_ascii=False),
            "config_dict": cfg.to_dict(),
            "vocab_size": self.tokenizer.vocab_size,
            "checkpoint": STARLIGHT_CKPT if os.path.exists(STARLIGHT_CKPT) else "none",
            "train_steps_total": self.train_step_counter,
            "available_models": [
                {"id": "starlight", "name": "StarLight LM", "params_m": round(self.starlight_params / 1e6, 2),
                 "desc": "双数种子混沌 Transformer"},
                {"id": "chaos", "name": "ChaosNN", "params_m": round(sum(p.numel() for p in self.chaos_nn.parameters()) / 1e6, 4),
                 "desc": "Lorenz 状态投影生成"},
                {"id": "full", "name": "Full AGI", "params_m": round((self.starlight_params + sum(p.numel() for p in self.chaos_nn.parameters())) / 1e6, 2),
                 "desc": "StarLight + Lorenz 融合生成"},
            ],
            "chaos_nn": {
                "input": self.chaos_nn.input_size,
                "hidden": self.chaos_nn.hidden_size,
                "output": self.chaos_nn.output_size,
                "params": sum(p.numel() for p in self.chaos_nn.parameters()),
                "samples_processed": self.chaos_nn.training_stats["total_samples_processed"],
                "anomaly_count": self.chaos_nn.training_stats["anomaly_count"],
            },
        }


    INTENSITY_MAP = {
        "standard":    {"temperature": 0.70, "chaos_steps": 12, "reflection": False, "tools": "minimal"},
        "enhanced":    {"temperature": 0.85, "chaos_steps": 24, "reflection": True,  "tools": "standard"},
        "high":        {"temperature": 1.00, "chaos_steps": 36, "reflection": True,  "tools": "aggressive"},
        "extreme":     {"temperature": 1.30, "chaos_steps": 48, "reflection": True,  "tools": "all"},
        "apocalypse":  {"temperature": 1.60, "chaos_steps": 64, "reflection": True,  "tools": "all"},
    }

    def _intensity_config(self, intensity: str) -> Dict[str, Any]:
        return self.INTENSITY_MAP.get(intensity, self.INTENSITY_MAP["standard"])

    @torch.no_grad()
    def _sample_step(self, generated: torch.Tensor, temperature: float,
                     top_k: int, top_p: float, model: str = "starlight") -> tuple:
        


        vocab_size = self.tokenizer.vocab_size
        if model == "chaos":

            state_vec = self.chaos_engine.step().flatten().to(self.device)
            next_logits = (state_vec @ self.chaos_vocab_proj).unsqueeze(0).float()
            adaptive_temp = 1.0
        elif model == "full":

            star = self.starlight
            if generated.size(1) > star.config.max_seq_len:
                generated = generated[:, -star.config.max_seq_len:]
            logits, aux = star(generated)
            next_logits = logits[:, -1, :].float()
            state_vec = self.chaos_engine.step().flatten().to(self.device)
            chaos_logits = (state_vec @ self.chaos_vocab_proj).unsqueeze(0).float()
            next_logits = next_logits + 0.35 * chaos_logits
            s = aux["state"][:, -1, :, :]
            adaptive_temp = float(star.sampler(s))
        else:

            star = self.starlight
            if generated.size(1) > star.config.max_seq_len:
                generated = generated[:, -star.config.max_seq_len:]
            logits, aux = star(generated)
            next_logits = logits[:, -1, :].float()
            s = aux["state"][:, -1, :, :]
            adaptive_temp = float(star.sampler(s))


        if not torch.isfinite(next_logits).all():
            self.log("[sample] 检测到非有限 logits，执行 NaN/Inf 清洗")
        next_logits = torch.nan_to_num(next_logits, nan=-1e4, posinf=1e4, neginf=-1e4)
        temp = max(temperature * adaptive_temp / max(self.starlight.config.base_temperature, 1e-6), 1e-4)


        probs_full = F.softmax(next_logits / temp, dim=-1)

        probs_full = torch.clamp(probs_full, min=1e-8)
        topv, topi = torch.topk(probs_full[0], 5)
        candidates = [
            {"token": self.tokenizer.decode([int(i)]), "id": int(i), "prob": round(float(v), 4)}
            for v, i in zip(topv, topi)
        ]


        for tid in set(generated[0].tolist()[-50:]):
            if next_logits[0, tid] > 0:
                next_logits[0, tid] /= 1.1
            else:
                next_logits[0, tid] *= 1.1
        next_logits = torch.nan_to_num(next_logits, nan=-1e4, posinf=1e4, neginf=-1e4)
        next_logits = next_logits / temp
        if top_k > 0:
            k = min(top_k, next_logits.size(-1))
            kv, _ = torch.topk(next_logits, k, dim=-1)
            next_logits = torch.where(next_logits < kv[..., -1].unsqueeze(-1),
                                      torch.tensor(float("-inf"), device=next_logits.device), next_logits)
        if top_p < 1.0:
            sl, si = torch.sort(next_logits, descending=True)
            cp = torch.cumsum(F.softmax(sl, dim=-1), dim=-1)
            rem = cp > top_p
            rem[..., 1:] = rem[..., :-1].clone()
            rem[..., 0] = False
            next_logits[..., si[rem]] = float("-inf")
        probs = F.softmax(next_logits, dim=-1)
        probs = torch.clamp(probs, min=1e-8)

        if probs.sum() < 1e-6:
            probs = torch.ones_like(probs) / probs.size(-1)
        nxt = torch.multinomial(probs, num_samples=1)
        return nxt, round(adaptive_temp, 4), candidates

    def _rag_prefix(self, text: str, top_k: int = 3, threshold: float = 0.25) -> str:
        
        if self.memory.bank is None:
            return ""
        try:
            hits = self.memory.retrieve_by_text(text, top_k=top_k)
            lines = []
            for h in hits.get("results", []):
                if h["score"] >= threshold:
                    lines.append(f"[记忆 score={h['score']:.2f}] {h['text']}")
            if lines:
                return "\n".join(lines) + "\n[问题]\n"
        except Exception as e:
            self.log(f"[rag] 检索失败: {e}")
        return ""

    def _get_pure_chaos(self):
        
        if getattr(self, "_pure_chaos", None) is not None:
            return self._pure_chaos
        try:
            root = os.path.dirname(_BACKEND_DIR)
            path = None
            for sub in ("chaos_sft", "demo_50mb_big", "demo_50mb_cn_zero"):
                cand = os.path.join(root, "checkpoints", sub, "final_model.pt")
                if os.path.exists(cand):
                    path = cand
                    break
            if path is None:
                self.log(f"[engine] 纯混沌模型缺失: {root}/checkpoints/*/final_model.pt（先训练）")
                return None
            import importlib
            pclm = importlib.import_module("pure_chaos_lm_one_file")
            ck = torch.load(path, map_location="cpu", weights_only=True)
            cfg = ck["config"]
            cfg["use_chaos_db"] = False
            cfg["device"] = "cuda" if torch.cuda.is_available() else "cpu"
            m = pclm.ChaosLLM_Engine(cfg).to(cfg["device"])
            m.load_state_dict(m._remap_state_dict(ck["state_dict"]), strict=False)
            m.eval()
            tok = pclm.CharTokenizer(cfg["vocab_size"])
            pred = pclm.ChaosLLMPredictor(m)
            self._pure_chaos = (pred, tok, m)
            self.log(f"[engine] 纯混沌 LLM 已加载 vocab={cfg['vocab_size']} "
                     f"state_init={cfg.get('state_init_mode')} tokenizer={cfg.get('tokenizer_type')}")
            return self._pure_chaos
        except Exception as e:
            self.log(f"[engine] 纯混沌 LLM 加载失败: {e}")
            return None

    def generate(self, text: str, max_tokens: int = 64, temperature: float = 0.8,
                 top_k: int = 50, top_p: float = 0.9, use_rag: bool = False,
                 intensity: str = "standard", model: str = "starlight") -> Dict[str, Any]:
        cfg = self._intensity_config(intensity)
        temp = cfg["temperature"] if intensity != "standard" else temperature


        if model == "chaos_world":
            t0w = time.time()
            try:
                import importlib
                ac = importlib.import_module("agent_core")
                txt = text or ""
                if any(k in txt for k in ("发散", "不稳", "敏感", "危险", "加大")):
                    wv, jd = "轨迹快速发散", "当前处于敏感区域"
                elif any(k in txt for k in ("波动不大", "平稳", "稳定", "正常")):
                    wv, jd = "波动不大", "系统平稳"
                else:
                    wv, jd = "波动正在加大", "进入不稳定窗口"
                with self._gen_lock:
                    result_text = ac.ask(wv, jd)
                    self.generate_counter += 1
                return {"result": result_text, "tokens": max(1, len(result_text)), "token_ids": [],
                        "temperature_history": [], "elapsed_ms": round((time.time() - t0w) * 1000, 1),
                        "model": model, "trained_steps": self.train_step_counter,
                        "rag_used": False, "intensity": intensity, "domain": "chaos_world", "entry": -1}
            except Exception as e:
                return {"result": f"[chaos_world] Agent 核心不可用: {str(e)[:120]}", "tokens": 0,
                        "token_ids": [], "temperature_history": [], "elapsed_ms": round((time.time() - t0w) * 1000, 1),
                        "model": model, "trained_steps": self.train_step_counter, "rag_used": False, "intensity": intensity}






        if model == "chaos_wm_v2":
            t0w = time.time()
            try:
                import importlib
                ac = importlib.import_module("agent_chain")
                with self._gen_lock:
                    txt, info = ac.answer(text or "", K=20, with_mpc=True)
                    self.generate_counter += 1
                if not info.get("ok"):
                    return {"result": f"[chaos_wm_v2] {info.get('error', '世界模型不可用')}",
                            "tokens": 0, "token_ids": [], "temperature_history": [],
                            "elapsed_ms": round((time.time() - t0w) * 1000, 1), "model": model,
                            "trained_steps": self.train_step_counter, "rag_used": False,
                            "intensity": intensity, "domain": "chaos_wm_v2", "entry": -1}
                mem = info.get("memory") or {}
                return {"result": txt, "tokens": max(1, len(txt)), "token_ids": [],
                        "temperature_history": [],
                        "elapsed_ms": round((time.time() - t0w) * 1000, 1),
                        "model": model, "trained_steps": self.train_step_counter,
                        "rag_used": bool(mem.get("ok")), "intensity": intensity,
                        "domain": "chaos_wm_v2", "entry": int(mem.get("index", -1)),
                        "wm": {"wave": info.get("wave"), "judge": info.get("judge"),
                               "divergence": info.get("divergence"),
                               "gate": info.get("gate"), "memory": mem,
                               "mpc": info.get("mpc"), "status": info.get("world_status")}}
            except Exception as e:
                return {"result": f"[chaos_wm_v2] 世界模型不可用: {str(e)[:120]}", "tokens": 0,
                        "token_ids": [], "temperature_history": [],
                        "elapsed_ms": round((time.time() - t0w) * 1000, 1), "model": model,
                        "trained_steps": self.train_step_counter, "rag_used": False, "intensity": intensity}




        if model == "koopman":
            t0k = time.time()
            try:
                import importlib
                ke = importlib.import_module("koopman_engine")
                with self._gen_lock:
                    out = ke.run(text or "")
                    self.generate_counter += 1
                if not out.get("ok"):
                    return {"result": f"[koopman] {out.get('error', '引擎不可用')}",
                            "tokens": 0, "token_ids": [], "temperature_history": [],
                            "elapsed_ms": round((time.time() - t0k) * 1000, 1), "model": model,
                            "trained_steps": self.train_step_counter, "rag_used": False,
                            "intensity": intensity, "domain": "koopman", "entry": -1}
                return {"result": out.get("result", ""), "tokens": max(1, len(out.get("result", ""))),
                        "token_ids": [], "temperature_history": [],
                        "elapsed_ms": round((time.time() - t0k) * 1000, 1),
                        "model": model, "trained_steps": self.train_step_counter,
                        "rag_used": False, "intensity": intensity,
                        "domain": "koopman", "entry": -1,
                        "wm": {"backbone": out.get("backbone"), "wave": out.get("wave"),
                               "judge": out.get("judge"),
                               "forecast": out.get("forecast"),
                               "spectrum": out.get("spectrum"),
                               "capability": out.get("capability")}}
            except Exception as e:
                return {"result": f"[koopman] 引擎不可用: {str(e)[:120]}", "tokens": 0,
                        "token_ids": [], "temperature_history": [],
                        "elapsed_ms": round((time.time() - t0k) * 1000, 1), "model": model,
                        "trained_steps": self.train_step_counter, "rag_used": False,
                        "intensity": intensity}



        if model == "chaos_llm":
            t0c = time.time()
            try:
                import importlib
                ccm = importlib.import_module("core_chaos_memory")
                with self._gen_lock:
                    result_text, domain, idx = ccm.answer(text[:60])
                    self.generate_counter += 1
                return {
                    "result": result_text,
                    "tokens": max(1, len(result_text)),
                    "token_ids": [],
                    "temperature_history": [],
                    "elapsed_ms": round((time.time() - t0c) * 1000, 1),
                    "model": model,
                    "trained_steps": self.train_step_counter,
                    "rag_used": True,
                    "intensity": intensity,
                    "domain": domain,
                    "entry": idx,
                }
            except Exception as e:
                return {"result": f"[chaos_llm] 记忆问答模块不可用: {str(e)[:120]}",
                        "tokens": 0, "token_ids": [], "temperature_history": [],
                        "elapsed_ms": round((time.time() - t0c) * 1000, 1), "model": model,
                        "trained_steps": self.train_step_counter, "rag_used": False, "intensity": intensity}

        with self._gen_lock:
            self.starlight.eval()
            t0 = time.time()
            prompt = self._rag_prefix(text) + text if use_rag else text
            ids = self.tokenizer.encode_text(prompt, add_special_tokens=True)
            if not ids:
                ids = [self.starlight.config.bos_token_id]
            generated = torch.tensor([ids], dtype=torch.long, device=self.device)
            temps: List[float] = []
            eos = self.starlight.config.eos_token_id
            for _ in range(max(1, min(int(max_tokens), 512))):
                nxt, at, _ = self._sample_step(generated, temp, top_k, top_p, model=model)
                generated = torch.cat([generated, nxt], dim=1)
                temps.append(at)
                if int(nxt[0, 0]) == eos:
                    break
            new_ids = generated[0, len(ids):].tolist()
            result_text = self.tokenizer.decode(new_ids)
            self.generate_counter += 1
            return {
                "result": result_text,
                "tokens": len(new_ids),
                "token_ids": new_ids[:256],
                "temperature_history": temps,
                "elapsed_ms": round((time.time() - t0) * 1000, 1),
                "model": model,
                "trained_steps": self.train_step_counter,
                "rag_used": use_rag and prompt != text,
                "intensity": intensity,
            }

    def generate_stream(self, text: str, max_tokens: int = 64, temperature: float = 0.8,
                        top_k: int = 50, top_p: float = 0.9,
                        intensity: str = "standard", model: str = "starlight") -> Generator[Dict[str, Any], None, None]:
        
        cfg = self._intensity_config(intensity)
        temp = cfg["temperature"] if intensity != "standard" else temperature
        with self._gen_lock:
            self.starlight.eval()
            ids = self.tokenizer.encode_text(text, add_special_tokens=True) or [self.starlight.config.bos_token_id]
            generated = torch.tensor([ids], dtype=torch.long, device=self.device)
            eos = self.starlight.config.eos_token_id
            prev_text = ""
            for i in range(max(1, min(int(max_tokens), 512))):
                nxt, at, cands = self._sample_step(generated, temp, top_k, top_p, model=model)
                generated = torch.cat([generated, nxt], dim=1)
                full = self.tokenizer.decode(generated[0, len(ids):].tolist())
                delta = full[len(prev_text):]
                prev_text = full
                yield {"type": "token", "delta": delta, "token_id": int(nxt[0, 0]),
                       "adaptive_temp": at, "step": i + 1, "candidates": cands}
                if int(nxt[0, 0]) == eos:
                    break
            self.generate_counter += 1
            yield {"type": "done", "result": prev_text, "tokens": int(generated.size(1) - len(ids)), "intensity": intensity, "model": model}


    def agent_think(self, text: str, max_tokens: int = 96, intensity: str = "standard", model: str = "starlight") -> Dict[str, Any]:
        
        t0 = time.time()
        cfg = self._intensity_config(intensity)
        thinking: List[Dict[str, Any]] = []


        ids = self.tokenizer.encode_text(text, add_special_tokens=False)
        pieces = self.tokenizer.tokenize(text)[:16]
        thinking.append({
            "phase": "perceive",
            "title": "输入感知",
            "detail": f"分词为 {len(ids)} 个 token: {' '.join(pieces[:10])}{'…' if len(pieces) > 10 else ''}",
            "tokens": len(ids),
        })


        ext = torch.tensor([(t % 997) / 997.0 for t in (ids + [0] * 64)[:64]], dtype=torch.float32)
        mags = []
        for _ in range(cfg["chaos_steps"]):
            st = self.chaos_engine.step(external_input=ext)
            mags.append(float(st.norm()))
        thinking.append({
            "phase": "chaos",
            "title": "混沌动力系统激发",
            "detail": f"Lorenz 吸引子演化 {cfg['chaos_steps']} 步，混沌幅值 {mags[0]:.3f} → {mags[-1]:.3f}",
            "magnitude_start": round(mags[0], 4),
            "magnitude_end": round(mags[-1], 4),
            "trajectory": [round(m, 3) for m in mags],
        })


        tool_results = []
        mcp_keywords = {
            "搜索": "web_scrape", "网页": "web_scrape", "抓取": "web_scrape",
            "系统": "system_overview", "CPU": "cpu_info", "内存": "memory_info",
            "GPU": "gpu_info", "显卡": "gpu_info", "进程": "list_processes",
            "网络": "network_info", "IP": "network_info", "ping": "ping",
            "HTTP": "http_request", "请求": "http_request", "DNS": "dns_lookup",
        }
        try:
            from backend.mcp_client import get_mcp_client
            for kw, tool_name in mcp_keywords.items():
                if kw in text:
                    try:
                        if tool_name == "web_scrape":
                            args = {"url": text.split()[-1] if text.split()[-1].startswith("http") else "https://example.com"}
                        elif tool_name == "http_request":
                            args = {"url": "https://example.com", "method": "GET"}
                        elif tool_name == "ping":
                            args = {"host": "127.0.0.1"}
                        else:
                            args = {}
                        res = get_mcp_client().call_tool(tool_name, args)
                        tool_results.append({"tool": tool_name, "keyword": kw, "result": str(res)[:400]})
                        thinking.append({
                            "phase": "tool_call",
                            "title": f"MCP 工具调用: {tool_name}",
                            "detail": f"关键词 '{kw}' 触发，返回 {len(str(res))} 字符",
                            "result": str(res)[:400],
                        })
                        break
                    except Exception as te:
                        self.log(f"[mcp] 工具调用失败 {tool_name}: {te}")
        except Exception as e:
            self.log(f"[mcp] 客户端不可用: {e}")


        with self._gen_lock:
            self.starlight.eval()
            enc = self.tokenizer.encode_text(text, add_special_tokens=True) or [self.starlight.config.bos_token_id]
            gen = torch.tensor([enc], dtype=torch.long, device=self.device)
            _nxt, at0, cands = self._sample_step(gen, cfg["temperature"], 50, 0.9, model=model)
        thinking.append({
            "phase": "deliberate",
            "title": "候选路径权衡",
            "detail": "首步候选: " + " | ".join(f"{c['token']!r} p={c['prob']}" for c in cands[:4]),
            "candidates": cands,
            "adaptive_temp": at0,
            "model": model,
        })


        recall_hits = []
        if cands and cands[0]["prob"] < 0.35 and self.memory.bank is not None:
            recall = self.memory.retrieve_by_text(text, top_k=3)
            recall_hits = recall.get("results", [])
            thinking.append({
                "phase": "recall",
                "title": "混沌记忆检索",
                "detail": f"置信度不足 (top1={cands[0]['prob']:.2f})，检索到 {len(recall_hits)} 条相关记忆",
                "results": recall_hits,
            })


        gen_prompt = text
        if recall_hits:
            rag_lines = [f"[记忆 score={h['score']:.2f}] {h['text']}" for h in recall_hits]
            gen_prompt = "\n".join(rag_lines) + "\n[问题]\n" + text
        gen_out = self.generate(gen_prompt, max_tokens=max_tokens, temperature=cfg["temperature"], intensity=intensity, model=model)
        temps = gen_out["temperature_history"]
        thinking.append({
            "phase": "synthesize",
            "title": "种子引导合成",
            "detail": f"生成 {gen_out['tokens']} token，自适应温度均值 {sum(temps)/max(len(temps),1):.3f} "
                      f"(范围 {min(temps):.3f}~{max(temps):.3f})" if temps else "无生成",
            "temperature_history": temps[:64],
            "rag_used": bool(recall_hits),
        })


        if cfg["reflection"]:
            thinking.append({
                "phase": "reflect",
                "title": "自指复盘",
                "detail": "多面性检查：重新评估候选路径与记忆一致性，启用自指约束模块。",
            })


        self.security.behavior_monitor.record_action("agent", "generate")
        thinking.append({
            "phase": "reflect",
            "title": "安全反思",
            "detail": f"行为监控已记录，累计异常 {self.chaos_nn.training_stats['anomaly_count']} 次，"
                      f"审计日志 {len(self.security.audit_log)} 条",
        })

        return {
            "result": gen_out["result"],
            "thinking": thinking,
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
            "intensity": intensity,
            "model": model,
        }

    def agent_think_stream(self, text: str, max_tokens: int = 96, intensity: str = "standard", model: str = "starlight") -> Generator[Dict[str, Any], None, None]:
        
        cfg = self._intensity_config(intensity)
        ids = self.tokenizer.encode_text(text, add_special_tokens=False)
        pieces = self.tokenizer.tokenize(text)[:16]
        yield {"type": "thought", "phase": "perceive", "title": "输入感知",
               "detail": f"分词为 {len(ids)} 个 token: {' '.join(pieces[:10])}"}

        ext = torch.tensor([(t % 997) / 997.0 for t in (ids + [0] * 64)[:64]], dtype=torch.float32)
        mags = []
        for _ in range(cfg["chaos_steps"]):
            mags.append(float(self.chaos_engine.step(external_input=ext).norm()))
        yield {"type": "thought", "phase": "chaos", "title": "混沌动力系统激发",
               "detail": f"Lorenz 演化 {cfg['chaos_steps']} 步，幅值 {mags[0]:.3f} → {mags[-1]:.3f}",
               "trajectory": [round(m, 3) for m in mags]}

        with self._gen_lock:
            self.starlight.eval()
            enc = self.tokenizer.encode_text(text, add_special_tokens=True) or [self.starlight.config.bos_token_id]
            generated = torch.tensor([enc], dtype=torch.long, device=self.device)
            nxt, at0, cands = self._sample_step(generated, cfg["temperature"], 50, 0.9, model=model)
            generated = torch.cat([generated, nxt], dim=1)
        yield {"type": "thought", "phase": "deliberate", "title": "候选路径权衡",
               "detail": "首步候选: " + " | ".join(f"{c['token']!r} p={c['prob']}" for c in cands[:4]),
               "candidates": cands,
               "model": model}


        rag_prompt = text
        if cands and cands[0]["prob"] < 0.35 and self.memory.bank is not None:
            recall = self.memory.retrieve_by_text(text, top_k=3)
            hits = recall.get("results", [])
            yield {"type": "thought", "phase": "recall", "title": "混沌记忆检索",
                   "detail": f"置信度不足 (top1={cands[0]['prob']:.2f})，检索到 {len(hits)} 条相关记忆",
                   "results": hits}
            if hits:
                rag_lines = [f"[记忆 score={h['score']:.2f}] {h['text']}" for h in hits]
                rag_prompt = "\n".join(rag_lines) + "\n[问题]\n" + text

                enc = self.tokenizer.encode_text(rag_prompt, add_special_tokens=True) or enc
                generated = torch.tensor([enc], dtype=torch.long, device=self.device)

                nxt, at0, _ = self._sample_step(generated, cfg["temperature"], 50, 0.9, model=model)
                generated = torch.cat([generated, nxt], dim=1)
                yield {"type": "token", "delta": self.tokenizer.decode([int(nxt[0, 0])]), "adaptive_temp": at0}
                prev = self.tokenizer.decode(generated[0, len(enc):].tolist())
                temps = [at0]

                eos = self.starlight.config.eos_token_id
                for i in range(1, max(2, min(int(max_tokens), 512))):
                    if int(nxt[0, 0]) == eos:
                        break
                    nxt, at, _ = self._sample_step(generated, cfg["temperature"], 50, 0.9, model=model)
                    generated = torch.cat([generated, nxt], dim=1)
                    full = self.tokenizer.decode(generated[0, len(enc):].tolist())
                    delta = full[len(prev):]
                    prev = full
                    temps.append(at)
                    yield {"type": "token", "delta": delta, "adaptive_temp": at}
                    if int(nxt[0, 0]) == eos:
                        break
                self.generate_counter += 1
                if cfg["reflection"]:
                    yield {"type": "thought", "phase": "reflect", "title": "自指复盘",
                           "detail": "多面性检查：重新评估候选路径与记忆一致性。"}
                yield {"type": "thought", "phase": "synthesize", "title": "种子引导合成",
                       "detail": f"共 {len(temps)} token，自适应温度均值 {sum(temps)/len(temps):.3f}",
                       "temperature_history": temps[:64]}
                yield {"type": "done", "result": prev, "intensity": intensity, "model": model}
                return

        first_delta = self.tokenizer.decode([int(nxt[0, 0])])
        yield {"type": "token", "delta": first_delta, "adaptive_temp": at0}

        prev = first_delta
        eos = self.starlight.config.eos_token_id
        temps = [at0]
        for i in range(1, max(2, min(int(max_tokens), 512))):
            if int(nxt[0, 0]) == eos:
                break
            nxt, at, _ = self._sample_step(generated, cfg["temperature"], 50, 0.9, model=model)
            generated = torch.cat([generated, nxt], dim=1)
            full = self.tokenizer.decode(generated[0, len(enc):].tolist())
            delta = full[len(prev):]
            prev = full
            temps.append(at)
            yield {"type": "token", "delta": delta, "adaptive_temp": at}
            if int(nxt[0, 0]) == eos:
                break
        self.generate_counter += 1
        if cfg["reflection"]:
            yield {"type": "thought", "phase": "reflect", "title": "自指复盘",
                   "detail": "多面性检查：重新评估候选路径与记忆一致性。"}
        yield {"type": "thought", "phase": "synthesize", "title": "种子引导合成",
               "detail": f"共 {len(temps)} token，自适应温度均值 {sum(temps)/len(temps):.3f}",
               "temperature_history": temps[:64]}
        yield {"type": "done", "result": prev, "intensity": intensity, "model": model}


    def lorenz_trajectory(self, n: int = 512) -> torch.Tensor:
        
        x, y, z = 0.1, 0.0, 0.0
        sigma, rho, beta = 10.0, 28.0, 8.0 / 3.0
        dt = 0.01
        pts = []
        for _ in range(n):
            dx = sigma * (y - x); dy = x * (rho - z) - y; dz = x * y - beta * z
            x += dx * dt; y += dy * dt; z += dz * dt
            pts.append([x, y, z])
        return torch.tensor(pts, dtype=torch.float32)

    def chaos_state(self, steps: int = 200) -> Dict[str, Any]:
        traj = self.lorenz_trajectory(n=max(50, min(steps, 1000)))
        eng_state = self.chaos_engine.get_state()
        return {
            "engine": eng_state,
            "trajectory": traj.tolist(),
            "nn_histories": {
                "gamma": [float(g.flatten()[0]) for g in self.chaos_nn.gamma_history[-50:]] if self.chaos_nn.gamma_history else [],
                "convergence": self.chaos_nn.training_stats["convergence_history"][-50:],
                "compute_power": self.chaos_nn.training_stats["compute_power_history"][-50:],
            },
        }

    def vocab_stats(self) -> Dict[str, Any]:
        sp = self.tokenizer.sp_model
        samples = [sp.IdToPiece(i) for i in range(0, self.tokenizer.vocab_size, max(1, self.tokenizer.vocab_size // 48))][:48]
        return {
            "active_model": os.path.basename(self.tokenizer.model_path),
            "vocab_size": self.tokenizer.vocab_size,
            "pad_id": self.tokenizer.pad_id, "unk_id": self.tokenizer.unk_id,
            "bos_id": self.tokenizer.bos_id, "eos_id": self.tokenizer.eos_id,
            "sample_tokens": samples,
            "corpus_chars": os.path.getsize(CORPUS_PATH) if os.path.exists(CORPUS_PATH) else 0,
            "builder": self.vocab_builder.status(),
        }

    def security_status(self) -> Dict[str, Any]:
        sm = self.security
        return {
            "roles": {k: v for k, v in sm.role_permissions.items()},
            "active_tokens": len(sm.access_tokens),
            "api_keys": len(sm.api_keys),
            "sessions": len(sm.sessions),
            "ip_whitelist": sm.ip_whitelist,
            "ip_blacklist_count": len(sm.ip_blacklist),
            "key_rotation_count": sm.key_rotation_count,
            "last_key_rotation": sm.last_key_rotation.isoformat(timespec="seconds"),
            "config": sm.security_config,
            "security_log_tail": [
                {k: (str(v)[:120] if k != "details" else str(v)[:200]) for k, v in e.items()}
                for e in sm.security_log[-20:]
            ],
            "audit_log_count": len(sm.audit_log),
            "encryption": {"symmetric": "Fernet(AES-128-CBC)", "asymmetric": "RSA-2048"},
            "anomaly": {
                "chaos_nn_anomaly_count": self.chaos_nn.training_stats["anomaly_count"],
                "z_threshold": sm.anomaly_detector.z_threshold,
            },
        }


    def network_trace_stats(self) -> Dict[str, Any]:
        
        return self.network_tracer.get_stats()

    def network_trace_records(self, limit: int = 500, action_filter: Optional[str] = None,
                              since_minutes: Optional[int] = None) -> List[Dict[str, Any]]:
        
        return self.network_tracer.get_records(limit=limit, action_filter=action_filter,
                                               since_minutes=since_minutes)

    def network_trace_connections(self) -> List[Dict[str, Any]]:
        
        return self.network_tracer.get_active_connections()

    def network_trace_nodes(self) -> Dict[str, Any]:
        
        return self.network_tracer.get_nodes()


    def map_tile(self, z: int, x: int, y: int) -> Tuple[Optional[bytes], Dict[str, Any]]:
        
        return self.map_tile_manager.get_tile(z, x, y)

    def map_tile_stats(self) -> Dict[str, Any]:
        
        return self.map_tile_manager.get_stats()

    def map_download_region(self, lat_min: float, lon_min: float,
                            lat_max: float, lon_max: float,
                            zoom_levels: List[int]) -> Dict[str, Any]:
        
        return self.map_tile_manager.download_region(lat_min, lon_min, lat_max, lon_max, zoom_levels)

    def map_clear_cache(self) -> Dict[str, Any]:
        
        return self.map_tile_manager.clear_cache()

    def map_server_nodes(self) -> Dict[str, Any]:
        
        return self.map_tile_manager.get_server_nodes()


    def cluster_status(self) -> Dict[str, Any]:
        
        return self.compute_profile.to_dict()

    def online_sources(self) -> List[Dict[str, Any]]:
        
        return DEFAULT_ONLINE_SOURCES

    def augment_corpus_online(self, sources: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        
        return augment_corpus_online(self, sources)





_engine: Optional[AGIEngine] = None
_engine_lock = threading.Lock()


def get_engine() -> AGIEngine:
    global _engine
    with _engine_lock:
        if _engine is None:
            _engine = AGIEngine()
        return _engine
