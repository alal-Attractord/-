#!/usr/bin/env python3

















import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wm_v2 as W

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(ROOT, "data", "wm_v2")
os.makedirs(OUT_DIR, exist_ok=True)

B, T, K = 32, 16, 8
STEPS_CHAOS = 600
STEPS_VISION = 600
STEPS_DECISION = 1500
SEED = 7


RIDGE_K_MAX = 160
RIDGE_LAM = 1e-1
RIDGE_CROSSOVER = 2


SUB, U_MAX, T_SEED, H = 8, 300.0, 12, 10
KP, LAM_U = 6.0, 0.01
TGT = np.array([8.4853, 8.4853, 27.0])
EP_STEPS, EPISODES = 80, 8



def _split_opt(m):
    
    core = getattr(m, "core", None)
    ck = ([p for n_, p in core.named_parameters()
           if any(k in n_ for k in ("coupling", "mu", "omega", "rossler", "_fb"))]
          if core is not None else [])
    ids = {id(p) for p in ck}
    ok = [p for p in m.parameters() if p.requires_grad and id(p) not in ids]
    groups = [{"params": ok, "lr": 1e-3}]
    if ck:
        groups.append({"params": ck, "lr": 1e-2})
    return torch.optim.AdamW(groups, weight_decay=1e-5)


def train_rollout(m, xn_tr, tag, steps, seed=0, erg=0.0):
    





    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    opt = _split_opt(m)
    m.train()
    if hasattr(m, "install_compile"):
        m.install_compile()
    roll = m.roll if hasattr(m, "roll") else m.forward_roll
    t0, loss = time.time(), None
    for _ in range(steps):
        s, t = W.sample_windows(xn_tr, B, T, K, rng)
        opt.zero_grad()
        p = roll(s, K)
        loss = F.mse_loss(p, t)
        if erg > 0:
            loss = loss + erg * W.erg_loss(p, t)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
        opt.step()
    print(f"    [{tag}] {steps}步 {time.time()-t0:.0f}s loss {loss.item():.4f} "
          f"P={W.param_count(m)}", flush=True)
    return m





def integrate(env, s, u, sub):
    for _ in range(sub):
        s = env.step(s, u)
    return s


def gen_action_data(env, n, seed=0, burn=4000):
    rng = np.random.default_rng(seed)
    box_lo = np.asarray(env.lo) - 2.0
    box_hi = np.asarray(env.hi) + 2.0
    s = np.array([1.0, 1.0, 1.0])
    for _ in range(burn):
        s = env.step(s)
    sa = s.copy()
    pool = np.empty((2000, 3))
    for k in range(2000):
        sa = env.step(sa)
        pool[k] = sa
    X = np.empty((n, 3)); U = np.empty((n, 3))
    i, tries = 0, 0
    while i < n and tries < n * 60:
        tries += 1
        u = rng.uniform(-U_MAX, U_MAX, 3)
        sn = integrate(env, s, u, SUB)
        if not (np.all(sn >= box_lo) and np.all(sn <= box_hi)):
            s = pool[rng.integers(len(pool))].copy()
            continue
        X[i] = s; U[i] = u
        s = sn; i += 1
    return X[:i], U[:i]


def sample_act(Xn, Un, b, t_, k_, rng, device=W.DEV):
    n = len(Xn) - t_ - k_ - 2
    j = rng.integers(0, n, b)
    seed = np.stack([Xn[a:a + t_] for a in j])
    sa = np.stack([Un[a:a + t_] for a in j])
    act = np.stack([Un[a + t_ - 1:a + t_ - 1 + k_] for a in j])
    tgt = np.stack([Xn[a + t_:a + t_ + k_] for a in j])
    tt = lambda z: torch.tensor(z, device=device)
    return tt(seed), tt(sa), tt(act), tt(tgt)


def train_action_wm(m, Xn, Un, tag, steps, seed=0):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    opt = _split_opt(m)
    m.train()
    t0, loss = time.time(), None
    for _ in range(steps):
        s, sa, a, t = sample_act(Xn, Un, B, T_SEED, K, rng)
        opt.zero_grad()
        loss = F.mse_loss(m.forward_roll(s, K, actions=a, seed_actions=sa), t)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
        opt.step()
    print(f"    [{tag}] {steps}步 {time.time()-t0:.0f}s loss {loss.item():.4f} "
          f"P={W.param_count(m)}", flush=True)
    return m


def save(name, m, kind, env, cfg, extra=None):
    p = os.path.join(OUT_DIR, name)
    torch.save({
        "kind": kind, "env_name": env.name, "cfg": cfg,
        "mu": np.asarray(env.mu, dtype=np.float64).tolist(),
        "sd": np.asarray(env.sd, dtype=np.float64).tolist(),
        "lo": np.asarray(env.lo, dtype=np.float64).tolist(),
        "hi": np.asarray(env.hi, dtype=np.float64).tolist(),
        "params": W.param_count(m),
        "state_dict": m.state_dict(),
        "extra": extra or {},
    }, p)
    print(f"    保存 {p} ({os.path.getsize(p)/1e3:.1f} KB)", flush=True)



if __name__ == "__main__":
    print(f"DEV {W.DEV} | torch {torch.__version__}", flush=True)
    meta = {"version": "wm_v2", "device": W.DEV, "torch": torch.__version__,
            "parts": {}, "created": time.strftime("%Y-%m-%d %H:%M:%S")}


    env = W.get_env("Lorenz")
    raw, xn = W.build_env_data(env, n=6000, burn=4000, seed=SEED)
    ntr = int(len(xn) * 0.8)
    xn_tr, xn_te = xn[:ntr], xn[ntr:]
    w = (env.hi - env.lo) / env.nb
    qf = float(np.mean(w / np.sqrt(12) / env.sd))
    print(f"量化下限 nb16={qf:.4f}", flush=True)

    chaos = W.ChaosWM(env, cont_std=0.30, nb=16, resid=True).to(W.DEV)
    train_rollout(chaos, xn_tr, "C-resid", STEPS_CHAOS, seed=0)
    rmse, vpt = W.evaluate(chaos, xn_te, K=20, T=T, n_win=256, seed=11)
    print(f"    C-resid 复现校验 VPT={vpt} rmse@1/5/10/20="
          f"{rmse[0]:.4f}/{rmse[4]:.4f}/{rmse[9]:.4f}/{rmse[19]:.4f} "
          f"(实验记录 0.0869/.../VPT20)", flush=True)
    save("chaos_resid.pt", chaos, "chaos_resid", env,
         {"cont_std": 0.30, "nb": 16, "resid": True, "steps": STEPS_CHAOS})
    meta["parts"]["chaos_resid"] = {"params": W.param_count(chaos), "vpt": vpt,
                                    "rmse1": float(rmse[0]), "quant_floor_nb16": qf}





    ridge = chaos.attach_ridge(xn_tr, T=T, K_max=RIDGE_K_MAX, lam=RIDGE_LAM,
                               crossover=RIDGE_CROSSOVER)
    rp = ridge.save(os.path.join(OUT_DIR, "ridge_readout.npz"))
    print(f"    长程读出已拟合：T_fit={ridge.T_fit} K_max={ridge.K_max} λ={ridge.lam} "
          f"crossover={ridge.crossover} n_fit={ridge.meta.get('n_fit')} "
          f"→ {os.path.basename(rp)}", flush=True)
    meta["parts"]["ridge_readout"] = {"T_fit": ridge.T_fit, "K_max": ridge.K_max,
                                      "lam": ridge.lam, "crossover": ridge.crossover,
                                      "n_fit": ridge.meta.get("n_fit"),
                                      "note": "直接多步解析读出，补足长程（VPT 18→46）"}


    vision = W.VisionWM(env, inten_const=None).to(W.DEV)
    train_rollout(vision, xn_tr, "V-Full", STEPS_VISION, seed=0)
    rmse_v, vpt_v = W.evaluate(vision, xn_te, K=20, T=T, n_win=256, seed=11)
    print(f"    V-Full 复现校验 VPT={vpt_v} rmse@5={rmse_v[4]:.4f} "
          f"(实验记录 0.0226 / VPT19)", flush=True)
    save("vision_full.pt", vision, "vision_full", env,
         {"inten_const": None, "ch": 16, "steps": STEPS_VISION})
    meta["parts"]["vision_full"] = {"params": W.param_count(vision), "vpt": vpt_v,
                                    "rmse5": float(rmse_v[4])}


    envd = W.get_env("Lorenz")
    X, U = gen_action_data(envd, 8000, seed=5)
    envd.mu = X.mean(0)
    envd.sd = np.clip(X.std(0), 1e-6, None)
    envd.lo_t = torch.tensor(envd.lo, dtype=torch.float32)
    envd.hi_t = torch.tensor(envd.hi, dtype=torch.float32)
    Xn = envd.normalize(X).astype(np.float32)
    Un = (U / U_MAX).astype(np.float32)
    print(f"动作数据 {len(X)} | 目标 {TGT.round(2)}", flush=True)

    dec = W.LSTMWM(envd, h=96, use_action=True, u_dim=3).to(W.DEV)
    train_action_wm(dec, Xn, Un, "MPC-LSTM", STEPS_DECISION, seed=0)
    save("lstm_decision.pt", dec, "lstm_decision", envd,
         {"h": 96, "layers": 1, "use_action": True, "u_dim": 3, "steps": STEPS_DECISION},
         extra={"TGT": TGT.tolist(), "U_MAX": U_MAX, "SUB": SUB, "T_SEED": T_SEED,
                "H": H, "KP": KP, "LAM_U": LAM_U})
    meta["parts"]["lstm_decision"] = {"params": W.param_count(dec), "h": 96}

    with open(os.path.join(OUT_DIR, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    print("完成 →", OUT_DIR, flush=True)
