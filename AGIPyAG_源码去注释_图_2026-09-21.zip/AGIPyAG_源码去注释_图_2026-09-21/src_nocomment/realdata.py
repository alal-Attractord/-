
















import os
import gzip
import numpy as np

ROOT = r'F:\ASI\data\real'


SPEC = {
    'ETTh1':      dict(file='ETTh1.csv',        kind='csv',   step_h=1.0),
    'ETTh2':      dict(file='ETTh2.csv',        kind='csv',   step_h=1.0),
    'ETTm1':      dict(file='ETTm1.csv',        kind='csv',   step_h=0.25),
    'ETTm2':      dict(file='ETTm2.csv',        kind='csv',   step_h=0.25),
    'weather':    dict(file='weather.csv',      kind='csv',   step_h=1.0/6),
    'electricity':dict(file='electricity.txt.gz',kind='gz',   step_h=1.0),
    'traffic':    dict(file='traffic.txt.gz',   kind='gz',    step_h=1.0),
    'solar_AL':   dict(file='solar_AL.txt.gz',  kind='gz',    step_h=1.0/6),
    'exchange':   dict(file='exchange_rate.txt.gz', kind='gz',step_h=1.0),
}


def _read_csv(name):
    import pandas as pd
    p = os.path.join(ROOT, SPEC[name]['file'])
    try:
        d = pd.read_csv(p)
    except UnicodeDecodeError:
        d = pd.read_csv(p, encoding='latin-1')
    drop = [c for c in d.columns if str(c).lower() in ('date', 'time', 'timestamp')]
    d = d.drop(columns=drop)

    num = [c for c in d.columns if pd.api.types.is_numeric_dtype(d[c])]
    return d[num].to_numpy(np.float64), num


def _read_gz(name):
    p = os.path.join(ROOT, SPEC[name]['file'])
    sep = ','
    with gzip.open(p, 'rt') as f:
        a = np.loadtxt(f, dtype=np.float64, delimiter=sep)
    if a.ndim == 1:
        a = a[:, None]
    cols = ['c%d' % i for i in range(a.shape[1])]
    return a, cols


def load_one(name):
    if SPEC[name]['kind'] == 'csv':
        return _read_csv(name)
    return _read_gz(name)


def load_all(names=None):
    names = names or list(SPEC.keys())
    out = {}
    for n in names:
        Z, cols = load_one(n)
        out[n] = (Z, cols)
    return out


def lstf_bounds(T):
    
    n_tr = int(T * 0.7)
    n_te = int(T * 0.2)
    n_va = T - n_tr - n_te
    return n_tr, n_tr + n_va, T


def lstf_split(T):
    a, b, c = lstf_bounds(T)
    return np.arange(0, a), np.arange(a, b), np.arange(b, c)


def blocks(name, T, stride=1):
    












    if name.startswith('ETT'):
        per_day = 24 if name in ('ETTh1', 'ETTh2') else 96
        e_tr = (12 * 30 * per_day) // stride
        e_va = (16 * 30 * per_day) // stride
        e_te = (20 * 30 * per_day) // stride
        if T >= e_te:
            return (0, e_tr), (e_tr, e_va), (e_va, e_te)

    a, b, c = lstf_bounds(T)
    return (0, a), (a, b), (b, c)


def is_official_ett_split(name, T, stride=1):
    
    if not name.startswith('ETT'):
        return False
    per_day = 24 if name in ('ETTh1', 'ETTh2') else 96
    return T >= (20 * 30 * per_day) // stride


def win_starts(name, T, H, L, which, stride=1):
    
    s, e = blocks(name, T, stride)[{'tr': 0, 'va': 1, 'te': 2}[which]]
    lo = max(L, s)
    if e - H <= lo:
        return np.array([], dtype=np.int64)
    return np.arange(lo, e - H, dtype=np.int64)


def step_starts(name, T, L_eff, which, stride=1):
    
    s, e = blocks(name, T, stride)[{'tr': 0, 'va': 1, 'te': 2}[which]]
    lo = max(L_eff - 1, s)
    if e - 1 <= lo:
        return np.array([], dtype=np.int64)
    return np.arange(lo, e - 1, dtype=np.int64)


def standardize(Z, tr_idx):
    mu = Z[tr_idx].mean(axis=0)
    sd = Z[tr_idx].std(axis=0)
    sd = np.where(sd < 1e-12, 1.0, sd)
    return (Z - mu) / sd, mu, sd


def etth_official_bounds(per_day=24):
    
    a, b, c = 12 * 30 * per_day, 16 * 30 * per_day, 20 * 30 * per_day
    return a, b, c


if __name__ == '__main__':
    for n in SPEC:
        try:
            Z, cols = load_one(n)
            a, b, c = lstf_bounds(Z.shape[0])
            print('%-12s T=%-6d C=%-4d  col[-1]=%-16s  split=%d/%d/%d  step=%.3fh'
                  % (n, Z.shape[0], Z.shape[1], cols[-1], a, b - a, c - b, SPEC[n]['step_h']))
        except Exception as e:
            print('%-12s LOAD_FAIL %s: %s' % (n, type(e).__name__, e))
