#!/usr/bin/env python3


















import json
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pure_chaos_lm_one_file import HyperChaosArray





DEV = os.environ.get("WM_DEV") or ("cuda" if torch.cuda.is_available() else "cpu")
NB = 16
CORE_DIM = 100


def eff_dim(d: int) -> int:
    hd = (int(d * 0.67) // 2) * 2
    return hd + ((d - hd) // 3) * 3


DIM = eff_dim(CORE_DIM)





class ChaoticEnv:
    













    name = "base"
    obs_dim = 3
    nb = NB
    dt = 0.01
    integrator = "euler"

    def __init__(self):
        self.lo = np.asarray(self.lo, dtype=np.float64)
        self.hi = np.asarray(self.hi, dtype=np.float64)

    def deriv(self, s, u=None):
        raise NotImplementedError

    def step(self, s, u=None):
        if self.integrator == "rk4":
            dt = self.dt
            k1 = self.deriv(s, u)
            k2 = self.deriv(s + 0.5 * dt * k1, u)
            k3 = self.deriv(s + 0.5 * dt * k2, u)
            k4 = self.deriv(s + dt * k3, u)
            return s + dt / 6.0 * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
        return s + self.dt * self.deriv(s, u)

    def simulate(self, n, s0, burn=4000, rng=None):
        s = np.asarray(s0, dtype=np.float64).copy()
        for _ in range(burn):
            s = self.step(s)
        out = np.empty((n, self.obs_dim))
        for i in range(n):
            s = self.step(s)
            out[i] = s
        return out


    def codes(self, raw):
        k = np.clip((raw - self.lo) / (self.hi - self.lo) * self.nb, 0, self.nb - 1).astype(np.int64)
        c = k[..., 0]
        for j in range(1, k.shape[-1]):
            c = c * self.nb + k[..., j]
        return c

    def code_from_torch(self, raw):
        k = torch.clamp((raw - self.lo_t) / (self.hi_t - self.lo_t) * self.nb, 0, self.nb - 1)
        k = k.to(torch.long)
        c = k[..., 0]
        for j in range(1, k.shape[-1]):
            c = c * self.nb + k[..., j]
        return c

    def normalize(self, raw):
        return (raw - self.mu) / self.sd

    def denormalize(self, xn):
        return xn * self.sd + self.mu

    def fit_norm(self, raw):
        self.mu = raw.mean(0)
        self.sd = np.clip(raw.std(0), 1e-6, None)
        self.lo_t = torch.tensor(self.lo, dtype=torch.float32)
        self.hi_t = torch.tensor(self.hi, dtype=torch.float32)

    def render(self, state, size=24):
        
        u = (state[0] - self.lo[0]) / (self.hi[0] - self.lo[0])
        v = (state[1] - self.lo[1]) / (self.hi[1] - self.lo[1])
        inten = (state[2] - self.lo[2]) / (self.hi[2] - self.lo[2])
        return render_blob(u, v, inten, size)


class LorenzEnv(ChaoticEnv):
    name = "Lorenz"
    obs_dim = 3
    dt = 0.005
    lo = [-25.0, -30.0, 0.0]
    hi = [25.0, 30.0, 60.0]

    def __init__(self):
        super().__init__()
        self.sigma, self.rho, self.beta = 10.0, 28.0, 8.0 / 3.0

    def deriv(self, s, u=None):
        x, y, z = s
        d = np.array([self.sigma * (y - x), x * (self.rho - z) - y, x * y - self.beta * z])
        if u is not None:
            d = d + np.asarray(u, dtype=np.float64)
        return d


class RosslerEnv(ChaoticEnv):
    name = "Rossler"
    obs_dim = 3
    dt = 0.02
    integrator = "rk4"
    lo = [-12.0, -12.0, 0.0]
    hi = [12.0, 12.0, 25.0]

    def __init__(self):
        super().__init__()
        self.a, self.b, self.c = 0.2, 0.2, 5.7

    def deriv(self, s, u=None):
        x, y, z = s
        d = np.array([-y - z, x + self.a * y, self.b + z * (x - self.c)])
        if u is not None:
            d = d + np.asarray(u, dtype=np.float64)
        return d


class DuffingEnv(ChaoticEnv):
    

    name = "Duffing"
    obs_dim = 3
    dt = 0.02
    lo = [-2.5, -2.5, 0.0]
    hi = [2.5, 2.5, 1.0]

    def __init__(self):
        super().__init__()
        self.delta, self.alpha, self.beta, self.gamma, self.omega = 0.15, -1.0, 1.0, 0.3, 1.0

    def deriv(self, s, u=None):
        x, y, ph = s
        th = 2 * np.pi * ph
        d = np.array([y, -self.delta * y - self.alpha * x - self.beta * x ** 3 + self.gamma * math.cos(th),
                      self.omega / (2 * np.pi)])
        if u is not None:
            d = d + np.asarray(u, dtype=np.float64)
        return d

    def step(self, s, u=None):
        s = super().step(s, u)
        s[2] = s[2] % 1.0
        return s


class Lorenz6Env(ChaoticEnv):
    




    name = "Lorenz6"
    obs_dim = 6
    dt = 0.005
    lo = [-30.0, -35.0, 0.0, -30.0, -35.0, 0.0]
    hi = [30.0, 35.0, 70.0, 30.0, 35.0, 70.0]

    def __init__(self):
        super().__init__()
        self.sigma, self.rho, self.beta, self.k = 10.0, 28.0, 8.0 / 3.0, 0.5

    def deriv(self, s, u=None):
        x1, y1, z1, x2, y2, z2 = s
        d = np.array([
            self.sigma * (y1 - x1) + self.k * (x2 - x1),
            x1 * (self.rho - z1) - y1,
            x1 * y1 - self.beta * z1,
            self.sigma * (y2 - x2) + self.k * (x1 - x2),
            x2 * (self.rho - z2) - y2,
            x2 * y2 - self.beta * z2,
        ])
        if u is not None:
            d = d + np.asarray(u, dtype=np.float64)
        return d


class LorenzNEnv(ChaoticEnv):
    





    def __init__(self, n_sys=2):
        self.n_sys = int(n_sys)
        self.obs_dim = 3 * self.n_sys
        self.lo = [-30.0, -35.0, 0.0] * self.n_sys
        self.hi = [30.0, 35.0, 70.0] * self.n_sys
        self.name = f"LorenzN{self.obs_dim}"
        super().__init__()
        self.sigma, self.rho, self.beta, self.k = 10.0, 28.0, 8.0 / 3.0, 0.5

    def deriv(self, s, u=None):
        X = np.asarray(s, dtype=np.float64).reshape(self.n_sys, 3)
        d = np.empty_like(X)
        for i in range(self.n_sys):
            xi, yi, zi = X[i]
            xp = X[i - 1, 0]
            xq = X[(i + 1) % self.n_sys, 0]
            d[i, 0] = self.sigma * (yi - xi) + self.k * (xp + xq - 2.0 * xi)
            d[i, 1] = xi * (self.rho - zi) - yi
            d[i, 2] = xi * yi - self.beta * zi
        d = d.reshape(-1)
        if u is not None:
            d = d + np.asarray(u, dtype=np.float64)
        return d


ENVS = {"Lorenz": LorenzEnv, "Rossler": RosslerEnv, "Duffing": DuffingEnv, "Lorenz6": Lorenz6Env}


def get_env(name):
    
    if name.startswith("LorenzN"):
        tail = name[len("LorenzN"):]
        if tail.isdigit():
            d = int(tail)
            if d % 3 or d < 3:
                raise ValueError(f"LorenzN<d> 要求 d 为 ≥3 的 3 的倍数，收到 {d}")
            return LorenzNEnv(d // 3)
    return ENVS[name]()





def render_blob(u, v, inten, size=24, sigma=1.2):
    yy, xx = np.mgrid[0:size, 0:size]
    cx = float(np.clip(u, 0, 1)) * (size - 1)
    cy = (1.0 - float(np.clip(v, 0, 1))) * (size - 1)
    g = np.exp(-((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * sigma ** 2))
    img = g * float(np.clip(inten, 0, 1))
    return img.astype(np.float32)


IMG = 24
SIGMA = 1.2


def render_torch(xn, env, size=IMG, sigma=SIGMA, inten_const=None):
    

    raw = xn * torch.tensor(env.sd, dtype=xn.dtype, device=xn.device) + \
        torch.tensor(env.mu, dtype=xn.dtype, device=xn.device)
    lo = torch.tensor(env.lo, dtype=xn.dtype, device=xn.device)
    hi = torch.tensor(env.hi, dtype=xn.dtype, device=xn.device)
    u = (raw[..., 0] - lo[0]) / (hi[0] - lo[0])
    v = (raw[..., 1] - lo[1]) / (hi[1] - lo[1])
    inten = (raw[..., 2] - lo[2]) / (hi[2] - lo[2])
    if inten_const is not None:
        inten = torch.full_like(inten, inten_const)
    ax = torch.arange(size, dtype=xn.dtype, device=xn.device)
    yy, xx = torch.meshgrid(ax, ax, indexing="ij")
    cx = u.clamp(0, 1) * (size - 1)
    cy = (1 - v.clamp(0, 1)) * (size - 1)
    g = torch.exp(-((xx - cx[..., None, None]) ** 2 + (yy - cy[..., None, None]) ** 2) / (2 * sigma ** 2))
    img = g * inten.clamp(0, 1)[..., None, None]
    return img.unsqueeze(-3)


def render_multi_torch(xn, env, size=IMG, sigma=SIGMA, inten_const=None):
    

    raw = xn * torch.tensor(env.sd, dtype=xn.dtype, device=xn.device) + \
        torch.tensor(env.mu, dtype=xn.dtype, device=xn.device)
    lo = torch.tensor(env.lo, dtype=xn.dtype, device=xn.device)
    hi = torch.tensor(env.hi, dtype=xn.dtype, device=xn.device)
    d = raw.shape[-1]
    ax = torch.arange(size, dtype=xn.dtype, device=xn.device)
    yy, xx = torch.meshgrid(ax, ax, indexing="ij")
    img = torch.zeros(raw.shape[:-1] + (size, size), dtype=xn.dtype, device=xn.device)
    for j in range(0, d - 2, 3):
        u = (raw[..., j] - lo[j]) / (hi[j] - lo[j])
        v = (raw[..., j + 1] - lo[j + 1]) / (hi[j + 1] - lo[j + 1])
        inten = (raw[..., j + 2] - lo[j + 2]) / (hi[j + 2] - lo[j + 2])
        if inten_const is not None:
            inten = torch.full_like(inten, inten_const)
        cx = u.clamp(0, 1) * (size - 1)
        cy = (1 - v.clamp(0, 1)) * (size - 1)
        g = torch.exp(-((xx - cx[..., None, None]) ** 2 + (yy - cy[..., None, None]) ** 2) / (2 * sigma ** 2))
        img = img + g * inten.clamp(0, 1)[..., None, None]
    return img.clamp(0, 1).unsqueeze(-3)





class VisionWM(nn.Module):
    




    def __init__(self, env, dim=CORE_DIM, inten_const=None, ch=16, multi=False):
        super().__init__()
        self.env = env
        self.D = DIM if dim == CORE_DIM else eff_dim(dim)
        self.inten_const = inten_const
        self.multi = bool(multi)
        f = IMG // 4
        self.enc = nn.Sequential(
            nn.Conv2d(1, ch, 3, 2, 1), nn.ReLU(),
            nn.Conv2d(ch, ch * 2, 3, 2, 1), nn.ReLU(),
            nn.Flatten(), nn.Linear(ch * 2 * f * f, self.D))
        self.core = HyperChaosArray(dim=dim, back_step=6, alpha=0.10, dt=0.01, hopf_ratio=0.67,
                                    mu=0.3, omega_init=1.0, learnable_params=True,
                                    state_init_mode="zero", device=DEV, learnable_feedback=True)
        self.out = nn.Linear(self.D, env.obs_dim)

    def _render(self, xn):
        if self.multi:
            return render_multi_torch(xn, self.env, inten_const=self.inten_const)
        return render_torch(xn, self.env, inten_const=self.inten_const)

    def encode(self, xn):
        return self.enc(self._render(xn))

    def _init(self, B, device, dtype):
        s = torch.zeros(B, self.D, device=device, dtype=dtype)
        hist = torch.zeros(B, self.core._hist_len, self.D, device=device, dtype=dtype)
        return s, hist, 0, 0

    def forward_roll(self, xn_seed, K, actions=None, seed_actions=None, init_noise=0.0, return_states=False):
        self.core._refresh_cache()
        B, T, _ = xn_seed.shape
        s, hist, ptr, cnt = self._init(B, xn_seed.device, xn_seed.dtype)
        if init_noise > 0:
            s = s + torch.randn_like(s) * init_noise
        ext = self.encode(xn_seed.reshape(-1, self.env.obs_dim)).reshape(B, T, self.D)
        for t in range(T):
            s, hist, ptr, cnt = _core_step(self.core, ext[:, t], s, hist, ptr, cnt)
        x = xn_seed[:, -1]
        preds = []
        for _ in range(K):
            s, hist, ptr, cnt = _core_step(self.core, self.encode(x), s, hist, ptr, cnt)
            x = self.out(s)
            preds.append(x)
        out = torch.stack(preds, 1)
        return (out, s) if return_states else out

    def forward_tf(self, xn_seq):
        self.core._refresh_cache()
        B, T, _ = xn_seq.shape
        s, hist, ptr, cnt = self._init(B, xn_seq.device, xn_seq.dtype)
        ext = self.encode(xn_seq.reshape(-1, self.env.obs_dim)).reshape(B, T, self.D)
        outs = []
        for t in range(T):
            s, hist, ptr, cnt = _core_step(self.core, ext[:, t], s, hist, ptr, cnt)
            outs.append(self.out(s))
        return torch.stack(outs, 1)





class VisionWMVideo(VisionWM):
    






    def __init__(self, env, dim=CORE_DIM, inten_const=None, ch=16, multi=False, n_frames=3):
        super().__init__(env, dim=dim, inten_const=inten_const, ch=ch, multi=multi)
        self.n_frames = int(n_frames)
        f = IMG // 4
        self.enc = nn.Sequential(
            nn.Conv2d(self.n_frames, ch, 3, 2, 1), nn.ReLU(),
            nn.Conv2d(ch, ch * 2, 3, 2, 1), nn.ReLU(),
            nn.Flatten(), nn.Linear(ch * 2 * f * f, self.D))

    def _frames(self, xn_seq):
        
        B, T, _ = xn_seq.shape
        img = self._render(xn_seq.reshape(-1, self.env.obs_dim))
        return img.reshape(B, T, img.shape[-2], img.shape[-1])

    def _stack(self, buf):
        
        if len(buf) < self.n_frames:
            buf = [buf[0]] * (self.n_frames - len(buf)) + buf
        else:
            buf = buf[-self.n_frames:]
        return torch.stack(buf, 1)

    def encode(self, xn):
        
        img = self._render(xn)
        rep = img.repeat(*([1] * (img.dim() - 3)), self.n_frames, 1, 1)
        return self.enc(rep)

    def forward_roll(self, xn_seed, K, actions=None, seed_actions=None, init_noise=0.0, return_states=False):
        self.core._refresh_cache()
        B, T, _ = xn_seed.shape
        s, hist, ptr, cnt = self._init(B, xn_seed.device, xn_seed.dtype)
        if init_noise > 0:
            s = s + torch.randn_like(s) * init_noise
        fr = self._frames(xn_seed)
        buf = []
        for t in range(T):
            buf.append(fr[:, t])
            s, hist, ptr, cnt = _core_step(self.core, self.enc(self._stack(buf)), s, hist, ptr, cnt)
        x = xn_seed[:, -1]
        preds = []
        for _ in range(K):
            buf.append(self._frames(x[:, None])[:, 0])
            s, hist, ptr, cnt = _core_step(self.core, self.enc(self._stack(buf)), s, hist, ptr, cnt)
            x = self.out(s)
            preds.append(x)
        out = torch.stack(preds, 1)
        return (out, s) if return_states else out

    def forward_tf(self, xn_seq):
        self.core._refresh_cache()
        B, T, _ = xn_seq.shape
        s, hist, ptr, cnt = self._init(B, xn_seq.device, xn_seq.dtype)
        fr = self._frames(xn_seq)
        pad = fr[:, :1].expand(B, self.n_frames - 1, fr.shape[2], fr.shape[3])
        cat = torch.cat([pad, fr], 1)
        wins = torch.stack([cat[:, t:t + self.n_frames] for t in range(T)], 1)
        ext = self.enc(wins.reshape(B * T, self.n_frames, fr.shape[2], fr.shape[3])).reshape(B, T, self.D)
        outs = []
        for t in range(T):
            s, hist, ptr, cnt = _core_step(self.core, ext[:, t], s, hist, ptr, cnt)
            outs.append(self.out(s))
        return torch.stack(outs, 1)





def _core_step(core, ext, x, hist, ptr, count):


    if hasattr(core, "step_batch"):
        return core.step_batch(ext, x, hist, ptr, count)
    hist[:, ptr] = x.detach()
    ptr = (ptr + 1) % core._hist_len
    count = count + 1
    fb = torch.zeros_like(x)
    if core.use_delay_feedback and count >= core.back_step:
        delay = hist[:, (ptr - core.back_step) % core._hist_len]
        a = core._fb.clamp(0.05, 0.5) if core.learnable_feedback else core.alpha
        fb = a * (delay - x)
    dx = core._dynamics_batch(x)
    dx = dx + core.external_context_weight * ext
    x = x + (dx + fb) * core.dt
    x = torch.nan_to_num(torch.clamp(x, -25.0, 25.0))
    norm = torch.norm(x, dim=-1, keepdim=True)
    x = x * (math.sqrt(core.dim) * 0.3 / (norm + 1e-8))
    return x, hist, ptr, count





class ChaosWM(nn.Module):
    def __init__(self, env, dim=CORE_DIM, use_cont=True, use_action=False, u_dim=3, cont_std=0.02,
                 nb=None, resid=False, use_code=True,
                 kernel_type="hyperchaos", kernel_kw=None):
        super().__init__()
        self.resid = resid
        self.env = env
        self.obs_dim = env.obs_dim
        self.nb = int(nb) if nb is not None else env.nb
        self.dim = dim
        self.D = DIM if dim == CORE_DIM else eff_dim(dim)
        self.use_cont = use_cont
        self.use_action = use_action



        self.use_code = bool(use_code)
        if not (self.use_code or self.use_cont):
            raise ValueError("use_code 与 use_cont 不能同时为 False（无编码通路）")
        self.register_buffer("lo", torch.tensor(env.lo, dtype=torch.float32))
        self.register_buffer("hi", torch.tensor(env.hi, dtype=torch.float32))
        if self.use_code:
            self.emb = nn.Embedding(self.nb ** env.obs_dim, self.D)
        self.cont = nn.Linear(env.obs_dim, self.D)
        nn.init.normal_(self.cont.weight, std=cont_std)
        nn.init.zeros_(self.cont.bias)


        if str(kernel_type).lower() in ("hyperchaos", "hyper_chaos", "chaos"):
            self.core = HyperChaosArray(dim=dim, back_step=6, alpha=0.10, dt=0.01, hopf_ratio=0.67,
                                        mu=0.3, omega_init=1.0, learnable_params=True,
                                        state_init_mode="zero", device=DEV, learnable_feedback=True)
        else:
            from kernel_factory import get_dynamics_kernel


            self.core = get_dynamics_kernel(kernel_type, dim=self.D, device=DEV,
                                            **(kernel_kw or {}))
        self.kernel_type = str(kernel_type).lower()
        self.out = nn.Linear(self.D + (env.obs_dim if resid else 0), env.obs_dim)
        if use_action:
            self.act = nn.Linear(u_dim, self.D)
            nn.init.normal_(self.act.weight, std=0.5)
            nn.init.zeros_(self.act.bias)

            self.bu = nn.Linear(u_dim, env.obs_dim)
            nn.init.normal_(self.bu.weight, std=0.15)
            nn.init.zeros_(self.bu.bias)
            self.u_dim = u_dim


    def encode(self, xn, u=None):
        
        if self.use_action and u is not None:
            xn = xn + self.bu(u.to(xn.dtype))
        e = None
        if self.use_code:
            raw = xn * torch.tensor(self.env.sd, dtype=torch.float32, device=xn.device) \
                + torch.tensor(self.env.mu, dtype=torch.float32, device=xn.device)
            k = torch.clamp((raw - self.lo.to(raw.dtype)) / (self.hi.to(raw.dtype) - self.lo.to(raw.dtype)) * self.nb,
                            0, self.nb - 1).to(torch.long)
            c = k[..., 0]
            for j in range(1, k.shape[-1]):
                c = c * self.nb + k[..., j]
            e = self.emb(c)
        if self.use_cont:
            cont = self.cont(xn.to(self.cont.weight.dtype))
            e = cont if e is None else e + cont
        if self.use_action and u is not None:
            e = e + self.act(u.to(e.dtype))
        return e

    def _readout(self, s, x):
        return self.out(torch.cat([s, x], -1)) if self.resid else self.out(s)

    def _init(self, B, device, dtype):
        s = torch.zeros(B, self.D, device=device, dtype=dtype)
        hist = torch.zeros(B, self.core._hist_len, self.D, device=device, dtype=dtype)
        return s, hist, 0, 0

    def forward_roll(self, xn_seed, K, actions=None, seed_actions=None, init_noise=0.0,
                     return_states=False, collect_states=False, noise_after_seed=False):
        










        self.core._refresh_cache()
        B, T, _ = xn_seed.shape
        s, hist, ptr, cnt = self._init(B, xn_seed.device, xn_seed.dtype)
        if init_noise > 0 and not noise_after_seed:
            s = s + torch.randn_like(s) * init_noise
        if self.use_action and seed_actions is not None:
            ext = self.encode(xn_seed.reshape(-1, self.obs_dim),
                              seed_actions.reshape(-1, seed_actions.shape[-1])).reshape(B, T, self.D)
        else:
            ext = self.encode(xn_seed.reshape(-1, self.obs_dim)).reshape(B, T, self.D)
        seq = [] if collect_states else None
        for t in range(T):
            s, hist, ptr, cnt = _core_step(self.core, ext[:, t], s, hist, ptr, cnt)
            if collect_states:
                seq.append(s)
        if init_noise > 0 and noise_after_seed:
            s = s + torch.randn_like(s) * init_noise
        x = xn_seed[:, -1]
        preds = []
        for k in range(K):
            u = actions[:, k] if (self.use_action and actions is not None) else None
            s, hist, ptr, cnt = _core_step(self.core, self.encode(x, u), s, hist, ptr, cnt)
            if collect_states:
                seq.append(s)
            x = self._readout(s, x)
            preds.append(x)
        out = torch.stack(preds, 1)
        if collect_states:
            return out, torch.stack(seq, 1)
        if return_states:
            return out, s
        return out

    def plan_rollout(self, seed_obs, seed_act, x_start, cand_actions):
        



        self.core._refresh_cache()
        T = seed_obs.shape[1]
        s, hist, ptr, cnt = self._init(1, seed_obs.device, seed_obs.dtype)
        ext = self.encode(seed_obs.reshape(-1, self.obs_dim),
                          seed_act.reshape(-1, self.u_dim)).reshape(1, T, self.D)
        for t in range(T):
            s, hist, ptr, cnt = _core_step(self.core, ext[:, t], s, hist, ptr, cnt)
        C, K, _ = cand_actions.shape
        s = s.expand(C, -1).contiguous()
        hist = hist.expand(C, -1, -1).contiguous()
        x = x_start.expand(C, -1).contiguous()
        preds = []
        for k in range(K):
            s, hist, ptr, cnt = _core_step(self.core, self.encode(x, cand_actions[:, k]), s, hist, ptr, cnt)
            x = self._readout(s, x)
            preds.append(x)
        return torch.stack(preds, 1)

    def forward_tf(self, xn_seq):
        
        self.core._refresh_cache()
        B, T, _ = xn_seq.shape
        s, hist, ptr, cnt = self._init(B, xn_seq.device, xn_seq.dtype)
        ext = self.encode(xn_seq.reshape(-1, self.obs_dim)).reshape(B, T, self.D)
        outs = []
        for t in range(T):
            s, hist, ptr, cnt = _core_step(self.core, ext[:, t], s, hist, ptr, cnt)
            outs.append(self._readout(s, xn_seq[:, t]))
        return torch.stack(outs, 1)








    @torch.no_grad()
    def states_from(self, xn_seed, init_noise=0.0, noise_after_seed=False):
        






        self.core._refresh_cache()
        x = xn_seed if torch.is_tensor(xn_seed) else torch.tensor(
            np.asarray(xn_seed, np.float32), device=DEV)
        B, T, _ = x.shape
        ext = self.encode(x.reshape(-1, self.obs_dim)).reshape(B, T, self.D)
        s, hist, ptr, cnt = self._init(B, x.device, x.dtype)
        if init_noise > 0 and not noise_after_seed:
            s = s + torch.randn_like(s) * init_noise
        for t in range(T):
            s, hist, ptr, cnt = _core_step(self.core, ext[:, t], s, hist, ptr, cnt)
        if init_noise > 0 and noise_after_seed:
            s = s + torch.randn_like(s) * init_noise
        return s.cpu().numpy().astype(np.float64)

    @torch.no_grad()
    def states_sequence(self, xn, chunk=4096):
        




        self.core._refresh_cache()
        xn = np.asarray(xn, np.float32)
        outs = []
        for a0 in range(0, len(xn), chunk):
            ext = self.encode(torch.tensor(xn[a0:a0 + chunk], device=DEV))
            n = ext.shape[0]
            s, hist, ptr, cnt = self._init(1, DEV, torch.float32)
            buf = []
            for t in range(n):
                s, hist, ptr, cnt = _core_step(self.core, ext[t:t + 1], s, hist, ptr, cnt)
                buf.append(s[0])
            outs.append(torch.stack(buf, 0).cpu().numpy())
        return np.concatenate(outs, 0).astype(np.float64)

    def attach_ridge(self, xn_train, T=16, K_max=160, lam=1e-1, crossover=13,
                     n_win=8000, seed=0):
        



        self.ridge = RidgeReadout.fit(self, xn_train, T=T, K_max=K_max, lam=lam,
                                      crossover=crossover, n_win=n_win, seed=seed)
        return self.ridge









    def install_compile(self, enabled=True):
        
        if getattr(self, "_roll_c", "unset") == "unset":
            self._roll_c = None
            if enabled:
                try:
                    self._roll_c = torch.compile(self.forward_roll, dynamic=False)
                except Exception:
                    self._roll_c = None
        return self._roll_c

    def roll(self, xn_seed, K):
        
        c = getattr(self, "_roll_c", None)
        return c(xn_seed, K) if c is not None else self.forward_roll(xn_seed, K)

    @torch.no_grad()
    def rollout_dual(self, xn_seed, K, crossover=None, init_noise=0.0, noise_after_seed=False):
        









        r = getattr(self, "ridge", None)
        if r is None or r.W_all is None:
            return self.forward_roll(xn_seed, K, init_noise=init_noise,
                                     noise_after_seed=noise_after_seed)

        x = xn_seed if torch.is_tensor(xn_seed) else torch.tensor(
            np.asarray(xn_seed, np.float32), device=DEV)
        if r.T_fit and x.shape[1] != r.T_fit:
            import warnings
            warnings.warn(f"RidgeReadout 拟合于 T={r.T_fit}，推理给了 T={x.shape[1]}；"
                          f"状态分布不匹配会显著劣化长程精度（实测 MAE@20 0.189→0.883）。",
                          RuntimeWarning, stacklevel=2)
        c = int(r.crossover if crossover is None else crossover)
        c = max(1, min(c, K))
        direct = r.predict(self.states_from(x, init_noise=init_noise,
                                            noise_after_seed=noise_after_seed))
        K_use = min(K, direct.shape[1])
        tail = torch.tensor(direct[:, c - 1:K_use], device=DEV, dtype=torch.float32)
        if c <= 1:
            return tail


        ar = (self.roll(x, c - 1) if init_noise == 0
              else self.forward_roll(x, c - 1, init_noise=init_noise,
                                     noise_after_seed=noise_after_seed))
        return torch.cat([ar, tail], 1)





class RidgeReadout:
    








































    def __init__(self, W_all, lam=1e-1, K_max=160, crossover=13, obs_dim=3, meta=None):
        self.W_all = np.asarray(W_all, np.float64)
        self.lam = float(lam)
        self.K_max = int(K_max)
        self.crossover = int(crossover)
        self.obs_dim = int(obs_dim)
        self.meta = dict(meta or {})
        self.T_fit = int(self.meta.get("T_fit", 0)) or None

    def predict(self, S):
        
        S = np.atleast_2d(np.asarray(S, np.float64))
        A = np.hstack([S, np.ones((len(S), 1))])
        return np.einsum("nd,dkc->nkc", A, self.W_all)

    @classmethod
    def fit(cls, model, xn, T=16, K_max=160, lam=1e-1, crossover=13, n_win=8000, seed=0):
        







        xn = np.asarray(xn, np.float32)
        hi = len(xn) - T - K_max - 1
        if hi < 64:
            raise ValueError(f"训练序列过短：可用起点 {hi}（需 ≥64，即 len(xn) > K_max+T+64）")
        rng = np.random.default_rng(seed)
        idx = rng.integers(0, hi, int(n_win))
        win = np.stack([xn[i:i + T] for i in idx]).astype(np.float32)
        Y = np.stack([xn[i + T:i + T + K_max] for i in idx]).astype(np.float64)
        S = model.states_from(torch.tensor(win, device=DEV))
        A = np.hstack([S, np.ones((len(S), 1))])
        G = A.T @ A + lam * np.eye(A.shape[1])

        W_all = np.einsum("dn,nkc->dkc", np.linalg.solve(G, A.T), Y)
        return cls(W_all, lam=lam, K_max=K_max, crossover=crossover, obs_dim=xn.shape[1],
                   meta={"T_fit": int(T), "n_fit": int(len(S)), "core_dim": int(model.D)})

    def save(self, path):
        np.savez(path, W_all=self.W_all, lam=self.lam, K_max=self.K_max,
                 crossover=self.crossover, obs_dim=self.obs_dim,
                 meta=json.dumps(self.meta, ensure_ascii=False))
        return path

    @classmethod
    def load(cls, path):
        if not os.path.exists(path):
            return None
        z = np.load(path, allow_pickle=False)
        return cls(z["W_all"], lam=float(z["lam"]), K_max=int(z["K_max"]),
                   crossover=int(z["crossover"]), obs_dim=int(z["obs_dim"]),
                   meta=json.loads(str(z["meta"])))





class LSTMWM(nn.Module):
    def __init__(self, env, h=64, layers=1, use_action=False, u_dim=3):
        super().__init__()
        self.env = env
        self.obs_dim = env.obs_dim
        self.use_action = use_action
        self.h = h
        self.u_dim = u_dim
        self.rnn = nn.LSTM(env.obs_dim + (u_dim if use_action else 0), h, layers, batch_first=True)
        self.out = nn.Linear(h, env.obs_dim)

    def forward_roll(self, xn_seed, K, actions=None, seed_actions=None, init_noise=0.0,
                     return_states=False, noise_after_seed=True):
        






        h_ = c_ = None
        for t in range(xn_seed.shape[1]):
            inp = xn_seed[:, t:t + 1]
            if self.use_action and seed_actions is not None:
                inp = torch.cat([inp, seed_actions[:, t:t + 1]], -1)
            _, (h_, c_) = self.rnn(inp, (h_, c_) if h_ is not None else None)
        if init_noise > 0 and noise_after_seed:
            h_ = h_ + torch.randn_like(h_) * init_noise
            c_ = c_ + torch.randn_like(c_) * init_noise
        x = xn_seed[:, -1]
        preds = []
        for k in range(K):
            inp = x
            if self.use_action and actions is not None:
                inp = torch.cat([x, actions[:, k]], -1)
            _, (h_, c_) = self.rnn(inp.unsqueeze(1), (h_, c_))
            x = self.out(h_[-1])
            preds.append(x)
        out = torch.stack(preds, 1)
        return (out, h_[-1]) if return_states else out

    def forward_tf(self, xn_seq):
        o, _ = self.rnn(xn_seq)
        return self.out(o)

    def plan_rollout(self, seed_obs, seed_act, x_start, cand_actions):
        
        h_ = c_ = None
        for t in range(seed_obs.shape[1]):
            inp = seed_obs[:, t:t + 1]
            if self.use_action:
                inp = torch.cat([inp, seed_act[:, t:t + 1]], -1)
            _, (h_, c_) = self.rnn(inp, (h_, c_) if h_ is not None else None)
        C, K, _ = cand_actions.shape
        h_ = h_.expand(-1, C, -1).contiguous()
        c_ = c_.expand(-1, C, -1).contiguous()
        x = x_start.expand(C, -1).contiguous()
        preds = []
        for k in range(K):
            inp = torch.cat([x, cand_actions[:, k]], -1) if self.use_action else x
            _, (h_, c_) = self.rnn(inp.unsqueeze(1), (h_, c_))
            x = self.out(h_[-1])
            preds.append(x)
        return torch.stack(preds, 1)


class TFWM(nn.Module):
    def __init__(self, env, d=96, L=2, heads=4, maxlen=64, use_action=False, u_dim=3):
        super().__init__()
        self.env = env
        self.obs_dim = env.obs_dim
        self.use_action = use_action
        self.u_dim = u_dim
        self.maxlen = maxlen
        self.inp = nn.Linear(env.obs_dim + (u_dim if use_action else 0), d)
        self.pos = nn.Parameter(torch.zeros(1, maxlen, d))
        nn.init.normal_(self.pos, std=0.02)
        self.blocks = nn.ModuleList([nn.TransformerEncoderLayer(d, heads, 4 * d, batch_first=True,
                                                                norm_first=True) for _ in range(L)])
        self.norm = nn.LayerNorm(d)
        self.out = nn.Linear(d, env.obs_dim)

    def _run(self, seq):
        h = self.inp(seq) + self.pos[:, :seq.shape[1]]
        for b in self.blocks:
            h = b(h)
        return self.out(self.norm(h))

    def forward_roll(self, xn_seed, K, actions=None, seed_actions=None, init_noise=0.0,
                     return_states=False, noise_after_seed=True):
        






        B, T, _ = xn_seed.shape
        obs = xn_seed
        if init_noise > 0 and not noise_after_seed:
            obs = obs + torch.randn_like(obs) * init_noise
        if self.use_action:
            if seed_actions is not None:
                aa = seed_actions
            else:
                aa = torch.zeros(B, T, self.u_dim, device=xn_seed.device, dtype=xn_seed.dtype)
        preds = []
        for k in range(K):
            inp = torch.cat([obs, aa], -1) if self.use_action else obs
            x = self._run(inp)[:, -1]
            if k == 0 and init_noise > 0 and noise_after_seed:

                x = x + torch.randn_like(x) * init_noise
            preds.append(x)
            obs = torch.cat([obs, x.unsqueeze(1)], 1)
            if self.use_action:
                a_k = actions[:, k:k + 1] if actions is not None else torch.zeros(
                    B, 1, self.u_dim, device=xn_seed.device, dtype=xn_seed.dtype)
                aa = torch.cat([aa, a_k], 1)
        out = torch.stack(preds, 1)
        return (out, None) if return_states else out

    def forward_tf(self, xn_seq):
        return self._run(xn_seq)





def build_env_data(env, n=6000, burn=4000, seed=0):
    rng = np.random.default_rng(seed)
    s0 = env.lo + rng.random(env.obs_dim) * (env.hi - env.lo) * 0.3 + 0.1
    raw = env.simulate(n, s0, burn=burn)
    env.fit_norm(raw)
    xn = env.normalize(raw)
    return raw, xn.astype(np.float32)


def sample_windows(xn, B, T, K, rng, device=DEV):
    
    n = len(xn) - T - K - 1
    i = rng.integers(0, n, B)
    seed = np.stack([xn[j:j + T] for j in i])
    tgt = np.stack([xn[j + T:j + T + K] for j in i])
    return (torch.tensor(seed, device=device), torch.tensor(tgt, device=device))





def erg_loss(pred, tgt):
    
    m = ((pred.mean(1) - tgt.mean(1)) ** 2).mean()
    v = ((pred.std(1) - tgt.std(1)) ** 2).mean()
    zp = pred - pred.mean(1, keepdim=True)
    zt = tgt - tgt.mean(1, keepdim=True)
    ap = (zp[:, 1:] * zp[:, :-1]).mean(1) / (zp * zp).mean(1).clamp_min(1e-6)
    at = (zt[:, 1:] * zt[:, :-1]).mean(1) / (zt * zt).mean(1).clamp_min(1e-6)
    a = ((ap - at) ** 2).mean()
    return m + v + a





@torch.no_grad()
def evaluate(model, xn_test, K=20, T=16, nb_batch=64, n_win=256, seed=123, branch_M=1, init_noise=0.0):
    
    model.eval()
    rng = np.random.default_rng(seed)
    errs = []
    n_done = 0
    while n_done < n_win:
        b = min(nb_batch, n_win - n_done)
        s, t = sample_windows(xn_test, b, T, K, rng)
        if branch_M > 1:
            acc = 0
            for _ in range(branch_M):
                acc = acc + model.forward_roll(s, K, init_noise=init_noise)
            p = acc / branch_M
        else:
            p = model.forward_roll(s, K)
        e = (p - t).abs().mean(-1)
        errs.append(e.cpu().numpy())
        n_done += b
    E = np.concatenate(errs, 0)
    rmse = E.mean(0)
    vpt = int(np.argmax(rmse > 0.30)) if (rmse > 0.30).any() else K
    return rmse, vpt


def param_count(m):
    return sum(p.numel() for p in m.parameters())





class HybridDecision:
    






























    def __init__(self, lstm, chaos, chaos_act=None, tau=0.75, h_long=60, kp=6.0, u_max=300.0,
                 sub=8, t_seed=12, n_cand=96, h_mpc=10, lam_u=0.01, lam_u_risk=0.002, seed=0):
        self.lstm = lstm
        self.chaos = chaos


        self.chaos_act = chaos_act
        self.env = lstm.env
        self.envc = (chaos_act.env if chaos_act is not None else chaos.env)
        self.probe = "act_zero" if chaos_act is not None else "free"
        self.tau = float(tau)
        self.h_long = int(h_long)
        self.kp, self.u_max, self.sub, self.t_seed = float(kp), float(u_max), int(sub), int(t_seed)
        self.n_cand, self.h_mpc = int(n_cand), int(h_mpc)
        self.lam_u, self.lam_u_risk = float(lam_u), float(lam_u_risk)
        self.rng = np.random.default_rng(seed)


    @torch.no_grad()
    def long_range_risk(self, hist_raw, span, K=None, s_raw=None):
        




        K = self.h_long if K is None else int(K)
        envc = self.envc
        h = np.asarray(hist_raw, dtype=np.float32)
        if h.size == 0:
            s = np.array([1.0, 1.0, 1.0], dtype=np.float64)
            for _ in range(4000):
                s = envc.step(s)
            xs = []
            for _ in range(self.t_seed):
                s = envc.step(s)
                xs.append(s.copy())
            h = np.asarray(xs, dtype=np.float32)
            if s_raw is not None:
                h[-1] = np.asarray(s_raw, dtype=np.float32)
        if h.ndim == 1:
            h = h[None]
        n = min(len(h), self.t_seed)
        xn = envc.normalize(h[-n:]).astype(np.float32)
        s = torch.tensor(xn[None], device=DEV, dtype=torch.float32)
        if self.chaos_act is not None:

            ud = int(getattr(self.chaos_act, "u_dim", 3))
            za = torch.zeros(1, K, ud, device=DEV, dtype=torch.float32)
            za_seed = torch.zeros(1, s.shape[1], ud, device=DEV, dtype=torch.float32)
            p = self.chaos_act.forward_roll(s, K, actions=za, seed_actions=za_seed)[0].cpu().numpy()
        else:
            p = self.chaos.forward_roll(s, K)[0].cpu().numpy()
        praw = envc.denormalize(p)
        r = float(np.linalg.norm(praw[-1] - praw[0])) / max(float(span), 1e-6)
        return r, praw


    @torch.no_grad()
    def mpc_action(self, so, sa, s_raw, tgt_raw, lam=None, cand=None):
        
        env = self.env
        lam = self.lam_u if lam is None else float(lam)
        if cand is None:
            cand = self.rng.normal(0, 0.6, (self.n_cand, self.h_mpc, 3)).clip(-1, 1)
            cand[0] = 0.0
            cand[1] = np.clip(self.kp * (tgt_raw - s_raw) / self.u_max, -1, 1)
        c = torch.tensor(cand, dtype=torch.float32, device=DEV)
        so_t = torch.tensor(np.asarray(so, np.float32)[None], device=DEV)
        sa_t = torch.tensor(np.asarray(sa, np.float32)[None], device=DEV)
        xs_t = torch.tensor(env.normalize(np.asarray(s_raw, np.float64))[None].astype(np.float32), device=DEV)
        pred = self.lstm.plan_rollout(so_t, sa_t, xs_t, c)
        tn = torch.tensor(env.normalize(np.asarray(tgt_raw, np.float64)), device=DEV)
        w_k = torch.linspace(0.5, 1.5, self.h_mpc, device=DEV).view(1, self.h_mpc, 1)
        err = ((pred - tn) ** 2).sum(-1, keepdim=True) * w_k
        ctrl = lam * (c ** 2).sum(-1, keepdim=True)
        J = (err + ctrl).sum(1)[:, 0]
        j = int(J.argmin())
        return (cand[j, 0] * self.u_max).astype(np.float64), cand, J


    def safety_action(self, s_raw, tgt_raw):
        return np.clip(self.kp * (np.asarray(tgt_raw) - np.asarray(s_raw)),
                       -self.u_max, self.u_max).astype(np.float64)


    @torch.no_grad()
    def step(self, hist_raw, s_raw, so, sa, tgt_raw, span, cand=None):
        
        r, praw = self.long_range_risk(hist_raw, span, s_raw=s_raw)
        risk = bool(r >= self.tau)
        u_lstm, cand, _ = self.mpc_action(so, sa, s_raw, tgt_raw,
                                          lam=(self.lam_u_risk if risk else self.lam_u), cand=cand)
        u = self.safety_action(s_raw, tgt_raw) if risk else u_lstm
        return u, {"risk": risk, "r": r, "u_lstm": u_lstm.tolist(),
                   "switched": bool(np.abs(u - u_lstm).max() > 1e-6),
                   "pred_free": praw.tolist()}
