












































import torch
import torch.nn as nn


class SeriesDecomp(nn.Module):
    

    def __init__(self, k=25):
        super().__init__()
        self.k, self.pad = k, (k - 1) // 2

    def forward(self, x):
        p = torch.nn.functional.pad(x.permute(0, 2, 1), (self.pad, self.pad), mode="replicate")
        t = torch.nn.functional.avg_pool1d(p, self.k, stride=1).permute(0, 2, 1)
        return x - t, t


class DLinear(nn.Module):
    

    def __init__(self, L, H, C, k=25):
        super().__init__()
        self.decomp = SeriesDecomp(k)
        self.ls, self.lt = nn.Linear(L, H), nn.Linear(L, H)

    def forward(self, x):
        s, t = self.decomp(x)
        return (self.ls(s.permute(0, 2, 1)).permute(0, 2, 1)
                + self.lt(t.permute(0, 2, 1)).permute(0, 2, 1))


class CSRResidual(nn.Module):
    

    def __init__(self, L, H, C, d=32, r=2):
        super().__init__()
        self.Wt = nn.Linear(L, d)
        self.Wh = nn.Linear(d, H)
        g = 1.0 / max(d, 1)
        nn.init.uniform_(self.Wt.weight, -g, g); nn.init.zeros_(self.Wt.bias)
        nn.init.uniform_(self.Wh.weight, -g, g)
        nn.init.normal_(self.Wh.bias, 0.0, 0.01)
        self.U = nn.Parameter(torch.zeros(C, r))
        self.V = nn.Parameter(torch.zeros(C, r))
        self.alpha = nn.Parameter(torch.zeros(1))
        nn.init.normal_(self.U, 0.0, 1.0 / max(C ** 0.5, 1e-6))
        nn.init.normal_(self.V, 0.0, 0.01)
        self.C, self.r, self.d = C, r, d

    def mixing(self):
        return self.U @ self.V.T

    def raw(self, x):
        z = self.Wt(x.permute(0, 2, 1))
        z = torch.einsum("bcd,ec->bed", z, self.mixing())
        return self.Wh(z).permute(0, 2, 1)

    def forward(self, x):
        return self.alpha * self.raw(x)


class CSRPhi(nn.Module):
    

    def __init__(self, L, H, C, d=32, r=2, freeze_base=True, base=None):
        super().__init__()
        self.base = base if base is not None else DLinear(L, H, C)
        if freeze_base:
            for p in self.base.parameters():
                p.requires_grad_(False)
        self.freeze_base = freeze_base
        self.res = CSRResidual(L, H, C, d=d, r=r)

    def forward(self, x):
        b = self.base(x)
        if not self.base.training and self.freeze_base:
            b = b.detach()
        return b + self.res(x)


    def selfcheck(self, x, y=None):
        
        out = {}
        was = self.training
        self.train()
        with torch.no_grad():
            out["init_residual_mse"] = float((self.res(x) ** 2).mean())
            out["equals_base_bitwise"] = float((self(x) - self.base(x)).abs().max())
        self.zero_grad()
        loss = (self(x) ** 2).mean() if y is None else nn.functional.mse_loss(self(x), y)
        loss.backward()
        a = self.res.alpha.grad
        out["grad_alpha"] = float(a.abs().sum()) if a is not None else 0.0
        out["grad_all"] = float(sum(float((p.grad ** 2).sum())
                                    for p in self.res.parameters() if p.grad is not None) ** 0.5)
        self.zero_grad()
        if not was:
            self.eval()
        out["PASS_init_zero"] = out["init_residual_mse"] == 0.0
        out["PASS_grad_alive"] = out["grad_alpha"] > 0.0
        out["PASS_start_at_base"] = out["equals_base_bitwise"] == 0.0
        return out


if __name__ == "__main__":
    torch.manual_seed(0)
    B, L, H, C = 8, 96, 96, 7
    x = torch.randn(B, L, C)
    m = CSRPhi(L, H, C, d=32, r=2)
    chk = m.selfcheck(x)
    for k, v in chk.items():
        print(f"  {k} = {v}")
    assert chk["PASS_init_zero"] and chk["PASS_grad_alive"] and chk["PASS_start_at_base"], "自检未通过"
    print("  自检全部通过：起点逐位等于 DLinear，且梯度通路打开")
