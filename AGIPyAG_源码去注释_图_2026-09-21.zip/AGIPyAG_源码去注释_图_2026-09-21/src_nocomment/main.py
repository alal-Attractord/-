#!/usr/bin/env python3















import os
import sys
import argparse
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('AGIPyAG')


def cmd_train(args):
    from DeeNeuralNetwork.starlight_trainer import main as trainer_main
    sys.argv = [
        'starlight_trainer.py',
        '--data_dir', args.data_dir,
        '--vocab_size', str(args.vocab_size),
        '--seq_len', str(args.seq_len),
        '--hidden_dim', str(args.hidden_dim),
        '--num_layers', str(args.num_layers),
        '--num_heads', str(args.num_heads),
        '--batch_size', str(args.batch_size),
        '--grad_accum', str(args.grad_accum),
        '--epochs', str(args.epochs),
        '--lr', str(args.lr),
        '--checkpoint_dir', args.checkpoint_dir,
    ]
    trainer_main()


def cmd_test(args):
    import torch
    from DeeNeuralNetwork.starlight_core import _self_test as core_test
    from DeeNeuralNetwork.starlight_layers import _self_test as layers_test
    from DeeNeuralNetwork.starlight_model import _self_test as model_test

    print("=" * 60)
    print("AGIPyAG StarLight 全模块自测")
    print("=" * 60)

    core_test()
    print()
    layers_test()
    print()
    model_test()
    print()

    print("=" * 60)
    print("所有自测通过!")
    print("=" * 60)


def cmd_infer(args):
    import torch
    from DeeNeuralNetwork.starlight_model import StarLightModel
    from DeeNeuralNetwork.starlight_trainer import SimpleTokenizer

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"加载检查点: {args.checkpoint}")
    model = StarLightModel.load_checkpoint(args.checkpoint, device=device)[0]
    model.eval()

    tokenizer_path = os.path.join(os.path.dirname(args.checkpoint), 'tokenizer.json')
    tokenizer = SimpleTokenizer()
    if os.path.exists(tokenizer_path):
        tokenizer.load(tokenizer_path)
    else:
        raise FileNotFoundError(f"找不到 tokenizer: {tokenizer_path}")

    input_ids = torch.tensor([tokenizer.encode(args.prompt)], dtype=torch.long, device=device)
    result = model.generate(
        input_ids,
        max_new_tokens=args.max_new_tokens,
        top_k=args.top_k,
        top_p=args.top_p,
        do_sample=args.do_sample,
    )

    generated_text = tokenizer.decode(result['sequences'][0].tolist())
    print(f"Prompt: {args.prompt}")
    print(f"Generated: {generated_text}")
    print(f"Temperature history: {result['temperature_history'][:10]}")


def main():
    parser = argparse.ArgumentParser(description='AGIPyAG 主入口')
    subparsers = parser.add_subparsers(dest='command', required=True)


    train_parser = subparsers.add_parser('train', help='训练 StarLight 模型')
    train_parser.add_argument('--data_dir', type=str, default='data/wikitext-2')
    train_parser.add_argument('--vocab_size', type=int, default=8000)
    train_parser.add_argument('--seq_len', type=int, default=128)
    train_parser.add_argument('--hidden_dim', type=int, default=256)
    train_parser.add_argument('--num_layers', type=int, default=4)
    train_parser.add_argument('--num_heads', type=int, default=8)
    train_parser.add_argument('--batch_size', type=int, default=4)
    train_parser.add_argument('--grad_accum', type=int, default=4)
    train_parser.add_argument('--epochs', type=int, default=5)
    train_parser.add_argument('--lr', type=float, default=3e-4)
    train_parser.add_argument('--checkpoint_dir', type=str, default='checkpoints/starlight')


    subparsers.add_parser('test', help='运行全模块自测')


    infer_parser = subparsers.add_parser('infer', help='使用 StarLight 模型生成')
    infer_parser.add_argument('--checkpoint', type=str, required=True)
    infer_parser.add_argument('--prompt', type=str, default='hello world')
    infer_parser.add_argument('--max_new_tokens', type=int, default=32)
    infer_parser.add_argument('--top_k', type=int, default=50)
    infer_parser.add_argument('--top_p', type=float, default=0.9)
    infer_parser.add_argument('--do_sample', action='store_true', default=True)

    args = parser.parse_args()


    if args.command == 'train':
        if args.vocab_size <= 0 or args.seq_len <= 0 or args.hidden_dim <= 0 or args.num_layers <= 0 or args.num_heads <= 0:
            parser.error("vocab_size/seq_len/hidden_dim/num_layers/num_heads 必须为正整数")
        if args.batch_size <= 0 or args.grad_accum <= 0 or args.epochs <= 0:
            parser.error("batch_size/grad_accum/epochs 必须为正整数")
        if args.lr <= 0:
            parser.error("lr 必须为正数")
        if args.hidden_dim % args.num_heads != 0:
            parser.error("hidden_dim 必须能被 num_heads 整除")


    if args.command == 'infer':
        if args.max_new_tokens <= 0:
            parser.error("max_new_tokens 必须为正整数")
        if args.top_k < 0:
            parser.error("top_k 不能为负数")
        if not (0.0 < args.top_p <= 1.0):
            parser.error("top_p 必须在 (0, 1] 范围内")

    if args.command == 'train':
        cmd_train(args)
    elif args.command == 'test':
        cmd_test(args)
    elif args.command == 'infer':
        cmd_infer(args)


if __name__ == '__main__':
    main()
