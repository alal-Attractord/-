#!/usr/bin/env python3
































import numpy as np
import torch
import torch.nn as nn

import wm_v2 as W



SPECTRAL_DETERMINISTIC = True
SPECTRAL_ITERS = 5


def _det_start(B, D, device, dtype):
    
















    i = torch.arange(D, dtype=torch.float32, device=device)[None, :, None]
    v = (torch.sin(i * 0.7 + 0.3) + torch.cos(i * 1.3 + 0.9) + torch.sin(i * 2.9 + 1.7))
    v = v.expand(B, D, 1).to(dtype)
    return v / (v.norm(dim=1, keepdim=True) + 1e-8)


def _power_spec_norm(A, n_iter=None, eps=1e-8):
    






    single = (A.dim() == 2)
    if single:
        A = A[None]
    B, D, _ = A.shape
    if n_iter is None:
        n_iter = SPECTRAL_ITERS
    if SPECTRAL_DETERMINISTIC:
        v = _det_start(B, D, A.device, A.dtype)
    else:
        v = torch.randn(B, D, 1, device=A.device, dtype=A.dtype)
        v = v / (v.norm(dim=1, keepdim=True) + eps)
    for _ in range(n_iter):
        v = A.transpose(1, 2) @ (A @ v)
        nrm = v.norm(dim=1, keepdim=True).clamp_min(eps)
        v = v / nrm
    sigma = nrm[:, :, 0]
    sigma = sigma.sqrt().clamp_min(eps)
    scale = torch.clamp(sigma, min=1.0)
    out = A / scale[:, :, None]
    return out[0] if single else out


class KoopmanWM(nn.Module):
    

    def __init__(self, env, dim=64, n_basis=8, adaptive=True, hid=128, lift_hid=128,
                 spec_norm=True, use_action=False, u_dim=3):
        super().__init__()
        self.env = env
        self.obs_dim = env.obs_dim
        self.D = int(dim)
        self.adaptive = bool(adaptive)
        self.spec_norm = bool(spec_norm)
        self.use_action = bool(use_action)
        self.u_dim = int(u_dim)
        obs_in = env.obs_dim + (self.u_dim if use_action else 0)


        self.lift = nn.Sequential(nn.Linear(obs_in, lift_hid), nn.GELU(),
                                  nn.Linear(lift_hid, self.D))

        self.K0 = nn.Parameter(torch.eye(self.D) * 0.9 + 0.01 * torch.randn(self.D, self.D))
        self.n_basis = int(n_basis) if adaptive else 0
        if self.n_basis > 0:
            self.Kbasis = nn.Parameter(0.01 * torch.randn(self.n_basis, self.D, self.D))
            self.coef = nn.Sequential(nn.Linear(self.D, hid), nn.GELU(),
                                      nn.Linear(hid, self.n_basis))

        self.out = nn.Linear(self.D, env.obs_dim)


    def _K(self, z):
        




        B = z.shape[0]
        if self.n_basis == 0:
            K = self.K0[None].expand(B, -1, -1)
        else:
            a = torch.softmax(self.coef(z), dim=-1)
            K = self.K0[None] + torch.einsum("bn,nij->bij", a, self.Kbasis)
        return _power_spec_norm(K) if self.spec_norm else K

    def _advance(self, z):
        A = self._K(z)
        return torch.bmm(z.unsqueeze(1), A.transpose(-1, -2)).squeeze(1)

    def _lift(self, x, u=None):
        inp = x if u is None else torch.cat([x, u], -1)
        return self.lift(inp)

    def forward_roll(self, xn_seed, K, actions=None, seed_actions=None,
                     init_noise=0.0, return_states=False, noise_after_seed=False):
        
        B, T, _ = xn_seed.shape
        if init_noise > 0 and not noise_after_seed:
            xn_seed = xn_seed + torch.randn_like(xn_seed) * init_noise

        u_last = seed_actions[:, -1] if (self.use_action and seed_actions is not None) else None
        z = self._lift(xn_seed[:, -1], u_last)
        if init_noise > 0 and noise_after_seed:
            z = z + torch.randn_like(z) * init_noise
        x = xn_seed[:, -1]
        preds, states = [], []
        for k in range(K):
            u = actions[:, k] if (self.use_action and actions is not None) else None
            z = self._advance(z)
            states.append(z)
            x = self.out(z)
            preds.append(x)
        out = torch.stack(preds, 1)
        if return_states:
            return out, z
        return out


    @torch.no_grad()
    def spectrum(self, x):
        
        single = (x.dim() == 1)
        x = x[None] if single else x
        z = self._lift(x.to(next(self.parameters()).dtype))
        A = self._K(z)
        if A.dim() == 2:
            A = A[None].expand(z.shape[0], -1, -1)
        lam = torch.linalg.eigvals(A.cpu())
        lam = lam.numpy()
        return lam[0] if single else lam

    @torch.no_grad()
    def raw_K(self, x):
        
        single = (x.dim() == 1)
        x = x[None] if single else x
        z = self._lift(x.to(next(self.parameters()).dtype))
        B = z.shape[0]
        if self.n_basis == 0:
            K = self.K0[None].expand(B, -1, -1)
        else:
            a = torch.softmax(self.coef(z), dim=-1)
            K = self.K0[None] + torch.einsum("bn,nij->bij", a, self.Kbasis)
        return K[0] if single else K

    @torch.no_grad()
    def spectral_features(self, x):
        









        K = self.raw_K(x)
        lam = torch.linalg.eigvals(K.cpu()).numpy()
        if lam.ndim == 1:
            lam = lam[None]
        r = np.abs(lam)
        rs = np.sort(r, 1)
        rho = r.max(1)
        unit = np.abs(r - 1.0).min(1)
        gap = rs[:, -1] - rs[:, -2]
        gap_ratio = rs[:, -2] / np.maximum(rs[:, -1], 1e-12)
        mean_r = r.mean(1)
        p = r / np.maximum(r.sum(1, keepdims=True), 1e-9)
        ent = -(p * np.log(p + 1e-12)).sum(1)
        imag_frac = (np.abs(lam.imag) > 1e-6 * np.maximum(np.abs(lam.real), 1e-12)).mean(1)
        out = {"spec_rho": rho, "spec_unitdist": unit, "spec_gap": gap,
               "spec_gap_ratio": gap_ratio, "spec_mean": mean_r,
               "spec_entropy": ent, "spec_imagfrac": imag_frac}
        return {k: (float(v) if np.ndim(v) == 0 else v) for k, v in out.items()}


def param_count(m):
    return sum(p.numel() for p in m.parameters())
