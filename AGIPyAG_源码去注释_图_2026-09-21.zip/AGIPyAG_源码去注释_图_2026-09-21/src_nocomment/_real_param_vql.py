






















import os
import sys
import json
import time
import numpy as np

sys.path.insert(0, r'F:\ASI')
import realdata as RD
import _real_param_champion as PC

OUT = r'F:\ASI\_real_param_champion_vql.json'
LOG = r'F:\ASI\_real_param_champion_vql.log'
VQ_R = [32, 128, 256]
VQ_K = [64, 256]
VQ_ALPHA = [1e-4, 1e-2, 1e-1, 1.0]
VQ_SOFT_S = 3
VQ_SOFT_GK = [0.25, 1.0, 4.0]
KM_SEEDS = [0, 1, 2]
MIN_CNT = 8
PLAN = PC.PLAN
_FH = None


def log(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    if _FH:
        _FH.write(s + '\n')
        _FH.flush()


def vql_arm(Ltr, ytr, Lva, yva, soft=False):
    
    from scipy.spatial import cKDTree
    tree = cKDTree(Ltr)
    p = Ltr.shape[1] + 1
    I = np.eye(p)
    best = None
    for sd_ in KM_SEEDS:
        for R in VQ_R:
            if R > len(Ltr):
                continue
            C = PC.kmeans(Ltr, R, sd_)
            for k in VQ_K:
                if k > len(Ltr):
                    continue
                _, nb = tree.query(C, k=k)
                nb = np.atleast_2d(nb)
                Gs, rhs, used = {}, {}, []
                for r in range(R):
                    ii = nb[r]
                    P = PC.add1(Ltr[ii])
                    Gs[r] = P.T @ P
                    rhs[r] = P.T @ ytr[ii]
                    used.append(r)
                if not used:
                    continue
                lv = PC.assign(Lva, C)
                base_v = PC.add1(Lva)
                for al in VQ_ALPHA:
                    wmap = {r: np.linalg.solve(Gs[r] + al * I, rhs[r]) for r in used}
                    if not soft:
                        pv = Lva[:, 0].copy()
                        for r, w in wmap.items():
                            mm = lv == r
                            if mm.any():
                                pv[mm] = PC.add1(Lva[mm]) @ w
                        v = PC.mse(pv, yva)
                        if best is None or v < best['val']:
                            best = dict(val=float(v), seed=int(sd_), R=int(R), k=int(k),
                                        alpha=float(al), ws=wmap, C=C, mode='hard',
                                        kappa=None, R_used=len(used))
                    else:
                        D2v = PC.d2_to_centers(Lva, C)
                        ss = min(VQ_SOFT_S, len(C))
                        nbr = np.argpartition(D2v, ss - 1, axis=1)[:, :ss]
                        d2n = np.take_along_axis(D2v, nbr, 1)
                        s2 = float(np.mean(((Ltr - C[PC.assign(Ltr, C)]) ** 2).sum(1))) + 1e-12
                        for gk in VQ_SOFT_GK:
                            wt = np.exp(-(gk / s2) * d2n)
                            wt = wt / np.maximum(wt.sum(1, keepdims=True), 1e-300)
                            acc = np.zeros(len(Lva))
                            for j in range(ss):
                                idx_r = nbr[:, j]
                                wj = np.zeros((len(Lva), p))
                                for r, w in wmap.items():
                                    mm = idx_r == r
                                    if mm.any():
                                        wj[mm] = w
                                acc += wt[:, j] * np.einsum('bp,bp->b', base_v, wj)
                            v = PC.mse(acc, yva)
                            if best is None or v < best['val']:
                                best = dict(val=float(v), seed=int(sd_), R=int(R), k=int(k),
                                            alpha=float(al), ws=wmap, C=C, mode='soft',
                                            kappa=float(gk), R_used=len(used), s2=float(s2))
    return best


def vql_eval(info, L):
    C, ws = info['C'], info['ws']
    base = PC.add1(L)
    if info['mode'] == 'hard':
        lab = PC.assign(L, C)
        out = L[:, 0].copy()
        for r, w in ws.items():
            mm = lab == r
            if mm.any():
                out[mm] = base[mm] @ w
        return out
    D2v = PC.d2_to_centers(L, C)
    ss = min(VQ_SOFT_S, len(C))
    nbr = np.argpartition(D2v, ss - 1, axis=1)[:, :ss]
    d2n = np.take_along_axis(D2v, nbr, 1)
    s2 = max(float(info['s2']), 1e-12)
    wt = np.exp(-(info['kappa'] / s2) * d2n)
    wt = wt / np.maximum(wt.sum(1, keepdims=True), 1e-300)
    acc = np.zeros(len(L))
    p = base.shape[1]
    for j in range(ss):
        idx_r = nbr[:, j]
        wj = np.zeros((len(L), p))
        for r, w in ws.items():
            mm = idx_r == r
            if mm.any():
                wj[mm] = w
        acc += wt[:, j] * np.einsum('bp,bp->b', base, wj)
    return acc


def chan_run(x, tr, va, te, ycol):
    packs = PC.make_packs(x, tr, va, te)
    if not packs:
        return None
    mstar = PC.select_M_arlin(packs)
    r = dict(ycol=int(ycol), M=int(mstar))
    for tag, soft in (('vql', False), ('vql_soft', True)):
        bv, bm, info = float('inf'), None, None
        for m, (A, ya, B, yb, Cc, yc) in packs.items():
            Af, yf = PC.cap_rows(A, ya, PC.MAX_TR, 7)
            Bf, yb_f = PC.cap_rows(B, yb, PC.MAX_VA, 11)
            got = vql_arm(Af, yf, Bf, yb_f, soft=soft)
            if got is not None and got['val'] < bv:
                bv, bm, info = got['val'], m, got
        if info is None:
            continue
        A, ya, B, yb, Cc, yc = packs[bm]
        Ru = int(info['R_used'])
        M = A.shape[1]
        npar = int(Ru * (M + 1) + Ru * M + (Ru * (M + 1) if soft else 0))
        t0 = time.perf_counter()
        pr = vql_eval(info, Cc)
        ms = (time.perf_counter() - t0) * 1e3
        r[tag] = dict(test=PC.mse(pr, yc), val=float(bv), M=int(bm), R=int(info['R']),
                      k=int(info['k']), alpha=float(info['alpha']), mode=info['mode'],
                      km_seed=int(info['seed']), R_used=Ru, n_params=npar,
                      ms_per_1k=float(ms / max(len(Cc), 1) * 1000),
                      bytes=int(npar * 8),
                      store_note='推理只需码本+局部仿射, 不保存训练集')
    return r


def main():
    global _FH
    _FH = open(LOG, 'a', encoding='utf-8')
    log('=' * 100)
    log('PARAM-VQL  %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
    allr = {}
    if os.path.exists(OUT):
        try:
            allr = json.load(open(OUT, encoding='utf-8'))
        except Exception:
            allr = {}
    names = [a for a in sys.argv[1:] if a in PLAN] or list(PLAN.keys())
    for n in names:
        for dt in PLAN[n]:
            key = '%g' % dt
            allr.setdefault(n, {})
            if key in allr[n] and allr[n][key].get('channels') and not os.environ.get('VQ_FORCE'):
                log('  skip %s dt=%g (cached)' % (n, dt))
                continue
            t0 = time.time()
            try:
                Zs, cols, tr, va, te, stride, T = PC.load_config(n, dt)
                chans = PC.pick_target_channels(Zs, PC.N_CH)
                out = dict(name=n, dt_h=float(dt), T_res=int(T), stride=int(stride),
                           chans=[int(c) for c in chans])
                recs = []
                for c in chans:
                    rec = chan_run(Zs[:, int(c)], tr, va, te, int(c))
                    if rec is None:
                        continue
                    recs.append(rec)
                    log('      ch=%-4d M*=%s vql=%.4e(M%s R%s k%s p=%d) vql_soft=%.4e'
                        % (c, rec['M'], rec.get('vql', {}).get('test', float('nan')),
                           rec.get('vql', {}).get('M'), rec.get('vql', {}).get('R'),
                           rec.get('vql', {}).get('k'), rec.get('vql', {}).get('n_params', -1),
                           rec.get('vql_soft', {}).get('test', float('nan'))))
                out['channels'] = recs
                out['secs'] = round(time.time() - t0, 1)
                allr[n][key] = out
                log('  -> %-12s dt=%-5.1fh done (%.0fs)' % (n, dt, out['secs']))
            except Exception as e:
                import traceback
                log('  !! %s dt=%g FAIL %s: %s' % (n, dt, type(e).__name__, e))
                log(traceback.format_exc())
            json.dump(allr, open(OUT, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)

    champ = PC.load_merged()
    log('--- vql / knn_loclin ---')
    log('%-12s %5s %4s %12s %12s %8s %9s' % ('dataset', 'dt', 'nch', 'knn_ll', 'vql', 'x', 'vql_soft_x'))
    for n, dd in allr.items():
        for k, blk in sorted(dd.items(), key=lambda kv: float(kv[0])):
            recs = blk.get('channels') or []
            if not recs:
                continue
            base = {}
            for cb in (champ.get(n, {}).get(k, {}).get('channels') or []):
                base[cb['ycol']] = cb.get('knn_loclin', {}).get('test')
            kt = [base.get(r['ycol']) for r in recs if base.get(r['ycol'])]
            v1 = [r['vql']['test'] for r in recs if r.get('vql')]
            v2 = [r['vql_soft']['test'] for r in recs if r.get('vql_soft')]
            if not kt or not v1:
                continue
            a = float(np.mean(kt))
            log('%-12s %5s %4d %12.4e %12.4e %8.3f %9.3f' %
                (n, k, len(kt), a, float(np.mean(v1)), float(np.mean(v1)) / a,
                 (float(np.mean(v2)) / a) if v2 else float('nan')))
    log('saved -> %s' % OUT)


if __name__ == '__main__':
    main()
