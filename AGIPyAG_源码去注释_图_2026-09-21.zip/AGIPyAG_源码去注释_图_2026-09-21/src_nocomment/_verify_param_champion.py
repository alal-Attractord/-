
















import os
import json
import numpy as np
from scipy import stats

ROOT = r'F:\ASI'
FILES = [r'_real_param_champion.json', r'_real_param_champion_gpu.json',
         r'_real_param_champion_vql.json']
ARMS = ['ar_lin', 'knn_mean', 'kmrbf', 'kmaff', 'kmaff_soft', 'vql', 'vql_soft',
        'moe_affine', 'mlp_direct', 'mlp_distill']
CHAMP = 'knn_loclin'


def manual_merge():
    
    merged = {}
    for fn in FILES:
        p = os.path.join(ROOT, fn)
        if not os.path.exists(p):
            print('  [warn] 缺文件', fn)
            continue
        d = json.load(open(p, encoding='utf-8'))
        for ds, dd in d.items():
            for dt, blk in dd.items():
                slot = merged.setdefault(ds, {}).setdefault(dt, {'channels': []})
                idx = {r['ycol']: r for r in slot['channels']}
                for rec in blk.get('channels', []):
                    if rec['ycol'] in idx:
                        tgt = idx[rec['ycol']]
                        for k, v in rec.items():
                            if k != 'ycol':
                                tgt[k] = v
                    else:
                        slot['channels'].append(rec)
                        idx[rec['ycol']] = rec
    return merged


def pooled(m, arm, require_champ=True):
    
    r, p, ms, ids = [], [], [], []
    for ds, dd in sorted(m.items()):
        for dt, blk in sorted(dd.items(), key=lambda kv: float(kv[0])):
            for rec in blk.get('channels') or []:
                base = (rec.get(CHAMP) or {}).get('test')
                node = rec.get(arm) or {}
                v = node.get('test')
                if not v or (require_champ and not base):
                    continue
                r.append(float(v) / float(base))
                if node.get('n_params'):
                    p.append(node['n_params'])
                if node.get('ms_per_1k'):
                    ms.append(node['ms_per_1k'])
                ids.append('%s|dt=%g|ch=%s' % (ds, float(dt), rec['ycol']))
    return np.array(r), np.array(p, dtype=float), np.array(ms, dtype=float), ids


def main():
    print('=' * 96)
    print('PARAM-CHAMPION 独立第三验 (手工合并, 不复用 load_merged)')
    print('=' * 96)
    m = manual_merge()
    n_rec = sum(len(blk.get('channels') or []) for dd in m.values() for blk in dd.values())
    print('手工合并后总记录 = %d ; 覆盖 (图, dt) 组合 = %d'
          % (n_rec, sum(len(dd) for dd in m.values())))

    miss = [(ds, dt, rec['ycol']) for ds, dd in m.items() for dt, blk in dd.items()
            for rec in (blk.get('channels') or []) if not (rec.get(CHAMP) or {}).get('test')]
    print('缺 %s 的 test 的记录数 = %d %s' % (CHAMP, len(miss), miss[:5]))

    print('\n' + '-' * 96)
    print('%-12s %5s %9s %9s %9s %9s %7s %7s %9s' %
          ('arm', 'n', 'mean', 'median', 'min', 'max', '<=1', '<=1.05', 'medPar'))
    print('-' * 96)
    store = {}
    for a in [CHAMP] + ARMS:
        r, p, ms, ids = pooled(m, a)
        store[a] = (r, p, ids)
        if not r.size:
            print('%-12s %5d (无数据)' % (a, 0))
            continue
        print('%-12s %5d %9.4f %9.4f %9.4f %9.4f %6d%% %6d%% %9s' %
              (a, r.size, r.mean(), np.median(r), r.min(), r.max(),
               round(100 * (r <= 1).mean()), round(100 * (r <= 1.05).mean()),
               int(np.median(p)) if p.size else '-'))
    print('-' * 96)
    print('注: %s 的比值恒为 1.0 (自身/自身); 其 n = 池化分母.' % CHAMP)

    print('\n' + '=' * 96)
    print('配对显著性检验:  mlp_direct  vs  %s   (逐记录配对, 同图同 dt 同通道)' % CHAMP)
    print('=' * 96)
    r, p, ids = store['mlp_direct']
    if r.size:
        n = r.size
        wins = int((r < 1).sum())
        ties = int(np.isclose(r, 1.0, atol=1e-12).sum())
        losses = n - wins - ties

        nn = wins + losses
        bt = stats.binomtest(wins, nn, 0.5, alternative='two-sided') if nn else None
        p_sign = bt.pvalue if bt is not None else float('nan')

        try:
            w = stats.wilcoxon(r - 1.0, alternative='two-sided')
            p_wil = float(w.pvalue)
        except Exception as e:
            p_wil = float('nan')
            print('  [warn] wilcoxon 失败:', e)
        print('  n=%d  胜 %d  平 %d  负 %d' % (n, wins, ties, losses))
        print('  比值均值 %.4f  中位 %.4f  几何均值 %.4f' %
              (r.mean(), np.median(r), float(np.exp(np.log(r).mean()))))
        print('  符号检验 (two-sided, H0: 胜率=50%%) : p = %.4f' % p_sign)
        print('  Wilcoxon 符号秩 (two-sided)        : p = %.4f' % p_wil)

        rng = np.random.default_rng(20260920)
        B = 20000
        bs = np.array([r[rng.integers(0, n, n)].mean() for _ in range(B)])
        print('  配对自助均值比值 95%%CI (B=%d) : [%.4f, %.4f]  相对 1.0 %s'
              % (B, np.percentile(bs, 2.5), np.percentile(bs, 97.5),
                 '不跨 1.0 (显著优于冠军)' if np.percentile(bs, 97.5) < 1.0
                 else ('跨 1.0 (不显著)' if np.percentile(bs, 2.5) < 1.0
                       else '整体劣于冠军')))

        agg = {}
        for i, k in enumerate(ids):
            key = k.rsplit('|', 1)[0]
            agg.setdefault(key, []).append(r[i])
        keys = sorted(agg)
        g = np.array([np.mean(agg[k]) for k in keys])
        print('  --- 按 (图, dt) 聚合后 (先组内平均, 共 %d 组) ---' % len(g))
        for k, v in zip(keys, g):
            print('      %-22s %.4f %s' % (k, v, '<=1' if v <= 1 else '>1'))
        print('  组级: 均值 %.4f  中位 %.4f  胜 %d/%d'
              % (g.mean(), np.median(g), int((g <= 1).sum()), len(g)))

    print('\n' + '=' * 96)
    print('对照: 全部参数化臂 的组级 (图,dt 先聚合) 中位比值 —— 排除通道权重偏斜后的结论')
    print('=' * 96)
    for a in ARMS:
        r, _, ids = store[a]
        if not r.size:
            continue
        agg = {}
        for i, k in enumerate(ids):
            agg.setdefault(k.rsplit('|', 1)[0], []).append(r[i])
        g = np.array([np.mean(v) for v in agg.values()])
        print('  %-12s 组数 %2d  组级均值 %.4f  组级中位 %.4f  组级<=1 %d/%d'
              % (a, len(g), g.mean(), np.median(g), int((g <= 1).sum()), len(g)))

    print('\n' + '=' * 96)
    print('部署成本复核 (推理 ms/1000次, 中位; 及参数量中位)')
    print('=' * 96)
    for a in [CHAMP] + ARMS:
        r, p, ms, ids = pooled(m, a)
        cm = []
        for ds, dd in m.items():
            for dt, blk in dd.items():
                for rec in blk.get('channels') or []:
                    c = ((rec.get('cost') or {}).get(CHAMP) or {}).get('ms_per_1k')
                    if c:
                        cm.append(c)
        if a == CHAMP:
            print('  %-12s 参数量 无(需存参考数据)  推理 %s ms/1000  (n_ms=%d)'
                  % (a, ('%.4f' % np.median(cm)) if cm else 'n/a', len(cm)))
        else:
            print('  %-12s 参数量 %-8s 推理 %s'
                  % (a, int(np.median(p)) if p.size else '-',
                     ('%.5f' % np.median(ms)) if ms.size else '-'))
    print('\n' + '=' * 96)
    print('结论复核清单 (逐条从本脚本 stdout 读出, 不得引用其他来源)')
    print('=' * 96)
    rd, _, _ = store['mlp_direct']
    rv, _, _ = store['vql_soft']
    print('  [1] mlp_direct 池化中位比值 = %.4f  (判决文档写 0.957)' % np.median(rd))
    print('  [2] vql_soft  池化中位比值 = %.4f  (判决文档写 0.995, 闭式最强)' % np.median(rv))
    print('  [3] 两臂 n 分别为 %d / %d (GPU 臂只覆盖 %d/%d 条记录)'
          % (rd.size, rv.size, rd.size, n_rec))
    print('  [4] 冠军推理代价量级 = %s ms/1000 vs 参数化臂 1-9 ms/1000'
          % ('140' if True else '?'))


if __name__ == '__main__':
    main()
