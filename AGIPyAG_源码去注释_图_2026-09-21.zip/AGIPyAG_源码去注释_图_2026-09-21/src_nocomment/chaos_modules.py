#!/usr/bin/env python3









import math, os, sys
import torch
import torch.nn as nn
import torch.nn.functional as F


ROOT = os.path.dirname(os.path.abspath(__file__))
AGIPYAG = os.path.abspath(os.path.join(ROOT, '..', '..', 'AGI', 'AGIPyAG'))
CHACHA = os.path.join(AGIPYAG, 'DeeNeuralNetwork')
sys.path.insert(0, CHACHA)
sys.path.insert(0, AGIPYAG)

from hopf_bifurcation_attention import HopfBifurcationAttention
from quantum_entangled_attention import QuantumEntangledAttention
from hebbian_layer import HebbianAdaptor


def _nan_to_zero(x: torch.Tensor) -> torch.Tensor:
    
    return torch.where(torch.isnan(x) | torch.isinf(x), torch.zeros_like(x), x)



class HebbianFFN(nn.Module):
    
    def __init__(self, d_model, dim_feedforward, eta=0.003):
        super().__init__()
        self.ffn = nn.Sequential(
            nn.Linear(d_model, dim_feedforward),
            nn.GELU(),
            nn.Linear(dim_feedforward, d_model),
        )

        self.eta = nn.Parameter(torch.tensor(eta))
        self._h_cache = None

    def forward(self, x):
        return self.ffn(x)



class LorenzSystem(nn.Module):
    
    def __init__(self, dim, sigma=10.0, rho=28.0, beta=8/3, dt=0.05):
        super().__init__()
        self.dim = dim

        self.sigma = nn.Parameter(torch.full((dim,), sigma))
        self.rho   = nn.Parameter(torch.full((dim,), rho))
        self.beta  = nn.Parameter(torch.full((dim,), beta))
        self.dt = dt

    def forward(self, state):
        x, y, z = state[:, 0], state[:, 1], state[:, 2]
        dx = self.sigma * (y - x) * self.dt
        dy = (x * (self.rho - z) - y) * self.dt
        dz = (x * y - self.beta * z) * self.dt
        new_state = torch.stack([x + dx, y + dy, z + dz], dim=1)
        return _nan_to_zero(new_state).clamp(-50.0, 50.0)


class ChaosSpikeNeuron(nn.Module):
    







    def __init__(self, dim, seed_anchor=None, layer_name='', stateful=True):
        super().__init__()
        self.dim = dim
        self.stateful = stateful
        self.lorenz = LorenzSystem(dim)
        self.rossler_a = nn.Parameter(torch.full((dim,), 0.2))
        self.rossler_b = nn.Parameter(torch.full((dim,), 0.2))
        self.rossler_c = nn.Parameter(torch.full((dim,), 5.7))
        self.dt = 0.05

        self.spike_threshold = nn.Parameter(torch.ones(dim))
        self.spike_gate = nn.Linear(dim, dim)
        self.output_proj = nn.Linear(dim, dim)
        self.fusion_weight = nn.Parameter(torch.tensor(0.5))


        if stateful:
            self.register_buffer('lorenz_state', torch.zeros(1, 3, dim))
            self.register_buffer('rossler_state', torch.zeros(1, 3, dim))

        self.seed_anchor = seed_anchor
        self.layer_name = layer_name
        self.lyapunov_bound = seed_anchor.get_lyapunov_bound(layer_name) if seed_anchor else 0.3

    def _init_state(self, batch, device):
        return (
            torch.randn(batch, 3, self.dim, device=device) * 0.1,
            torch.randn(batch, 3, self.dim, device=device) * 0.1,
        )

    def _rossler_step(self, state):
        x, y, z = state[:, 0], state[:, 1], state[:, 2]
        a = self.rossler_a.abs().clamp(0.01, 1.0)
        b = self.rossler_b.abs().clamp(0.01, 1.0)
        c = self.rossler_c.abs().clamp(1.0, 10.0)
        dx = (-y - z) * self.dt
        dy = (x + a * y) * self.dt
        dz = (b + z * (x - c)) * self.dt
        new_state = torch.stack([x + dx, y + dy, z + dz], dim=1)
        return _nan_to_zero(new_state).clamp(-50.0, 50.0)

    def forward(self, x, states=None):
        




        B, D = x.shape
        device = x.device

        if self.stateful:
            if self.lorenz_state.shape[0] != B or self.lorenz_state.device != device:
                lz0, rz0 = self._init_state(B, device)
                self.lorenz_state = lz0
                self.rossler_state = rz0
            lorenz_state = self.lorenz_state
            rossler_state = self.rossler_state
        else:
            if states is None:
                lorenz_state, rossler_state = self._init_state(B, device)
            else:
                lorenz_state, rossler_state = states


        lz = self.lorenz(lorenz_state)
        rz = self._rossler_step(rossler_state)


        if self.stateful:
            self.lorenz_state = lz.detach()
            self.rossler_state = rz.detach()


        lz_signal = lz.mean(dim=-2)
        rz_signal = rz.mean(dim=-2)
        threshold = self.spike_threshold.abs().clamp_min(1e-3)
        spike = torch.tanh((lz_signal - rz_signal) / threshold)


        if self.lyapunov_bound > 0:
            spike = spike.clamp(-self.lyapunov_bound, self.lyapunov_bound)
        spike = _nan_to_zero(spike)


        inhibited = spike - 0.5 * self.spike_gate(spike)
        gate = torch.sigmoid(inhibited).clamp(0.0, 1.0)


        alpha = torch.sigmoid(self.fusion_weight)
        out = x * (1 - alpha) + alpha * self.output_proj(x * gate)
        out = _nan_to_zero(out).clamp(-10.0, 10.0)

        return out, (lz, rz)



class ChaosMemoryPool(nn.Module):
    







    def __init__(self, pool_size=512, memory_dim=128, henon_a=1.4, henon_b=0.3,
                 seed_anchor=None, layer_name=''):
        super().__init__()
        self.pool_size = pool_size
        self.memory_dim = memory_dim
        self.henon_a = nn.Parameter(torch.tensor(henon_a))
        self.henon_b = nn.Parameter(torch.tensor(henon_b))

        self.register_buffer('pool', torch.zeros(pool_size, memory_dim))
        self.register_buffer('_cursor', torch.tensor(0, dtype=torch.long))
        self.register_buffer('_total_writes', torch.tensor(0, dtype=torch.long))
        self._step = 0

        self.compress = nn.Linear(memory_dim * 2, memory_dim)
        self.decompress = nn.Linear(memory_dim, memory_dim * 2)

        self.seed_anchor = seed_anchor
        self.layer_name = layer_name

    def write(self, vec):
        



        self._step += 1
        if vec.dim() == 1:
            vec = vec.unsqueeze(0)
        B = vec.shape[0]
        vec = vec.detach().float()


        if vec.shape[-1] > self.memory_dim:
            vec = vec[..., :self.memory_dim]
        elif vec.shape[-1] < self.memory_dim:
            pad = self.memory_dim - vec.shape[-1]
            vec = F.pad(vec, (0, pad))


        if self.seed_anchor:
            real, imag = self.seed_anchor.get_temporal_code(self._step)
            if vec.shape[-1] >= 2:
                vec[..., 0] = vec[..., 0] * 0.9 + real * 0.1
                vec[..., 1] = vec[..., 1] * 0.9 + imag * 0.1


        idx = int(self._cursor.item())
        for i in range(B):
            self.pool[(idx + i) % self.pool_size] = vec[i]
        self._cursor.add_(B)
        self._total_writes.add_(B)

    def retrieve(self, query, top_k=3):
        




        single = query.dim() == 1
        if single:
            query = query.unsqueeze(0)
        q = query[..., :self.memory_dim].float()

        end = min(int(self._total_writes.item()), self.pool_size)
        if end == 0:
            empty = {'top_indices': [], 'top_similarities': []}
            return empty if single else [empty] * q.shape[0]


        pool = self.pool[:end].unsqueeze(0)
        q = q.unsqueeze(1)
        sims = F.cosine_similarity(q, pool, dim=-1)

        k = min(top_k, end)
        top = sims.topk(k, dim=-1)

        result = [
            {'top_indices': top.indices[i].tolist(), 'top_similarities': top.values[i].tolist()}
            for i in range(q.shape[0])
        ]
        return result[0] if single else result

    def associate(self, query, top_k=2):
        
        result = self.retrieve(query, top_k)
        if isinstance(result, list):
            result = result[0]
        if not result['top_indices']:
            return {'indices': [], 'associations': []}

        idx = result['top_indices'][0]
        vec = self.pool[idx]
        x = vec[:self.memory_dim//2]
        y = vec[self.memory_dim//2:]
        a = self.henon_a.abs().clamp(0.5, 1.6)
        b = self.henon_b.abs().clamp(0.1, 0.5)
        next_x = 1 - a * x**2 + y
        next_y = b * x
        jumped = torch.cat([next_x, next_y])
        jr = self.retrieve(jumped, top_k)
        return {'indices': jr['top_indices'], 'associations': jr['top_similarities']}

    def forward(self, x):
        



        B, L, D = x.shape
        if self._total_writes.item() == 0:
            return x


        queries = x.reshape(B * L, D)[..., :self.memory_dim]
        end = min(int(self._total_writes.item()), self.pool_size)
        if end == 0:
            return x

        pool = self.pool[:end].unsqueeze(0)
        q = queries.unsqueeze(1).float()
        sims = F.cosine_similarity(q, pool, dim=-1)
        top_idx = sims.argmax(dim=-1)

        context = self.pool[top_idx].to(x.device).reshape(B, L, self.memory_dim)
        return x + self.decompress(context)[:, :, :D]



class DeepWeightCoupling(nn.Module):
    




    def __init__(self, dim, coupling_strength=0.1, seed_anchor=None):
        super().__init__()
        self.dim = dim
        self.strength = nn.Parameter(torch.tensor(coupling_strength))
        self.coupling_proj = nn.Linear(dim, dim)
        self.register_buffer('_step', torch.tensor(0, dtype=torch.long))
        self.seed_anchor = seed_anchor

    def forward(self, layer_a, layer_b):
        



        self._step.add_(1)
        alpha = torch.sigmoid(self.strength)
        delta = self.coupling_proj(layer_a)
        return layer_b + alpha * _nan_to_zero(delta).clamp(-5.0, 5.0)



class TemporalChaosMemory(nn.Module):
    







    def __init__(self, d_model, mem_slots=4):
        super().__init__()
        self.mem_slots = mem_slots
        self.d_model = d_model
        self.time_enc = nn.Linear(1, d_model)
        self.mem_key = nn.Linear(d_model, d_model)
        self.mem_val = nn.Linear(d_model, d_model)
        self.mem_out = nn.Linear(d_model, d_model)

        self.henon_a = nn.Parameter(torch.tensor(1.4))
        self.henon_b = nn.Parameter(torch.tensor(0.3))

        self.register_buffer('_prev_states', torch.zeros(1, mem_slots, d_model))
        self.tick = 0

    def get_initial_state(self, batch_size, device):
        return torch.zeros(batch_size, self.mem_slots, self.d_model, device=device)

    def forward(self, x):
        



        B, L, D = x.shape
        device = x.device

        if self._prev_states.shape[0] != B or self._prev_states.device != device:
            self._prev_states = self.get_initial_state(B, device)


        ticks = torch.arange(1, L + 1, device=device, dtype=x.dtype) + self.tick
        self.tick += L
        t_vals = torch.sin(ticks / 10000.0).unsqueeze(0).unsqueeze(-1)
        t_enc = self.time_enc(t_vals)
        xt_t = x + t_enc


        k = self.mem_key(xt_t)
        v = self.mem_val(xt_t)

        outputs = []
        state = self._prev_states
        a = self.henon_a.abs().clamp(0.5, 1.6)
        b = self.henon_b.abs().clamp(0.1, 0.5)

        for t in range(L):
            kt = k[:, t]
            vt = v[:, t]


            scores = torch.bmm(kt.unsqueeze(1), state.transpose(1, 2)).squeeze(1)
            scores = scores / math.sqrt(D)
            attn = torch.softmax(scores, dim=-1).unsqueeze(1)


            read = torch.bmm(attn, state).squeeze(1)
            out = xt_t[:, t] + self.mem_out(read)
            outputs.append(out)


            x_n = state[:, :, :D//2]
            y_n = state[:, :, D//2:]
            norm = state.norm(dim=-1, keepdim=True).clamp_min(1.0)
            x_n = x_n / norm
            y_n = y_n / norm

            x_next = 1 - a * x_n.pow(2) + y_n
            y_next = b * x_n
            henon = torch.cat([x_next, y_next], dim=-1)[:, :, :D]
            henon = _nan_to_zero(henon).clamp(-10.0, 10.0)


            new_state = 0.9 * state + 0.1 * vt.unsqueeze(1)
            new_state = 0.95 * new_state + 0.05 * henon
            state = _nan_to_zero(new_state).clamp(-10.0, 10.0)

        self._prev_states = state.detach()
        return torch.stack(outputs, dim=1)



class ChaosFusionGate(nn.Module):
    
    def __init__(self, d_model):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model * 2),
            nn.GELU(),
            nn.Linear(d_model * 2, d_model),
            nn.Sigmoid(),
        )

    def forward(self, standard_out, chaos_out):
        fused = torch.cat([standard_out, chaos_out], dim=-1)
        alpha = self.gate(fused)
        return alpha * chaos_out + (1 - alpha) * standard_out
