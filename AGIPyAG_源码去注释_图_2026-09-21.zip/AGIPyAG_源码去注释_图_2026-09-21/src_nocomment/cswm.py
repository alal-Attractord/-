#!/usr/bin/env python3




















































import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import k3_forecaster as K3
import wm_v2 as W


class CSWM:
    

    def __init__(self, backbone="koopman_fix"):
        self.f = K3.K3Forecaster(backbone)
        self.m = self.f.model
        self.env = self.f.env
        self.dt = float(getattr(self.env, "dt", 1.0))
        self._cache = {}


    @torch.no_grad()
    def op(self, x_seed, normalized=False):
        






        x = torch.as_tensor(x_seed, dtype=torch.float32, device=K3.DEV)
        if x.dim() == 2:
            x = x[-1]
        xn = self.f._norm(x) if not normalized else x
        return self.m.raw_K(xn).detach().cpu().numpy()


    def decompose(self, x_seed):
        
        K = self.op(x_seed)
        lam, V = np.linalg.eig(K)
        Vinv = np.linalg.inv(V)
        self._cache = {"lam": lam, "V": V, "Vinv": Vinv, "K": K}
        return lam, V, Vinv

    def _z0(self, x_seed):
        
        with torch.no_grad():
            x = torch.as_tensor(x_seed, dtype=torch.float32, device=K3.DEV)
            if x.dim() == 2:
                x = x[-1]
            z = self.m._lift(self.f._norm(x)[None])
            return z.cpu().numpy()[0].astype(complex)


    def forecast_spectral(self, x_seed, H, top_r=None):
        
        if not self._cache:
            self.decompose(x_seed)
        lam, V, Vinv = self._cache["lam"], self._cache["V"], self._cache["Vinv"]
        z0 = self._z0(x_seed)
        c = Vinv @ z0
        if top_r is not None and top_r < len(lam):
            keep = np.argsort(-np.abs(lam))[:top_r]
            mask = np.zeros_like(lam, dtype=complex)
            mask[keep] = 1.0
            c = c * mask
        return V @ (lam ** H * c)

    @torch.no_grad()
    def forecast_iter(self, x_seed, H):
        
        x = torch.as_tensor(x_seed, dtype=torch.float32, device=K3.DEV)
        if x.dim() == 2:
            x = x[-1]
        z = self.m._lift(self.f._norm(x)[None])
        for _ in range(H):
            z = self.m._advance(z)
        return z.cpu().numpy()[0].astype(complex)

    def _obs(self, z):
        
        with torch.no_grad():
            zt = torch.as_tensor(np.real(z), dtype=torch.float32,
                                 device=K3.DEV)[None]
            return self.m.out(zt).cpu().numpy()[0]


    def lyapunov(self, x_seed=None):
        




        lam = self._cache["lam"] if self._cache else self.decompose(x_seed)[0]
        rho = float(np.max(np.abs(lam)))
        return {"rho_max": rho,
                "lyapunov_est": float(np.log(max(rho, 1e-12)) / self.dt),
                "dt": self.dt,
                "n_modes": int(len(lam)),
                "imag_frac": float((np.abs(np.angle(lam)) > 0.1).mean())}

    def horizon_attribution(self, x_seed, H, top_k=3):
        
        if not self._cache:
            self.decompose(x_seed)
        lam, V, Vinv = self._cache["lam"], self._cache["V"], self._cache["Vinv"]
        c = Vinv @ self._z0(x_seed)
        contrib = np.abs(lam ** H * c) * np.linalg.norm(V, axis=0)
        total = contrib.sum() + 1e-12
        order = np.argsort(-contrib)[:top_k]
        return [{"mode": int(i),
                 "modulus": round(float(abs(lam[i])), 5),
                 "freq_rad": round(float(abs(np.angle(lam[i]))), 5),
                 "decay_steps": round(float(-1.0 / np.log(max(abs(lam[i]), 1e-9))), 2),
                 "share": round(float(contrib[i] / total), 4)}
                for i in order]



def _seed(f, T=16, rho=28.0, n=400, seed=7):
    






    env = W.get_env("Lorenz")
    env.rho = float(rho)
    raw = env.simulate(n, np.array([1.0, 1.0, 1.0]), rng=np.random.default_rng(seed))
    return raw[:T]


def verify():
    
    c = CSWM()
    x = _seed(c.f)
    c.decompose(x)
    print("=" * 70)
    print("验证：谱路径  vs  迭代路径（数学上恒等，用于验证实现）")
    print("=" * 70)
    print(f"  {'H':>5}{'谱-迭代 最大差':>20}{'谱-迭代 相对':>16}")
    ok = True
    for H in (1, 2, 5, 20, 80):
        a = c.forecast_spectral(x, H)
        b = c.forecast_iter(x, H)
        d = float(np.abs(a - b).max())
        rel = d / (float(np.abs(b).max()) + 1e-12)
        print(f"  {H:>5}{d:>20.3e}{rel:>16.3e}")
        ok &= rel < 1e-3
    print(f"\n  ⇒ {'✅ 一致，谱路径实现正确' if ok else '❌ 不一致，实现有误'}")
    return ok


def speed():
    
    c = CSWM()
    x = _seed(c.f)
    print("=" * 70)
    print("速度：一次分解覆盖任意视界")
    print("=" * 70)
    t0 = time.perf_counter()
    c.decompose(x)
    t_dec = (time.perf_counter() - t0) * 1000
    print(f"  一次特征分解: {t_dec:.3f} ms")
    print(f"  {'H':>6}{'谱 (ms)':>12}{'迭代 (ms)':>12}{'加速':>10}")
    for H in (1, 5, 20, 80, 320):
        t0 = time.perf_counter()
        c.forecast_spectral(x, H)
        t_s = (time.perf_counter() - t0) * 1000
        t0 = time.perf_counter()
        c.forecast_iter(x, H)
        t_i = (time.perf_counter() - t0) * 1000
        print(f"  {H:>6}{t_s:>12.3f}{t_i:>12.3f}{t_i / max(t_s, 1e-9):>9.1f}×")


def truncate():
    




    c = CSWM()
    f = c.f
    env = W.get_env("Lorenz")
    env.rho = 28.0
    raw = env.simulate(500, np.array([1.0, 1.0, 1.0]), rng=np.random.default_rng(7))
    T = 16

    pairs = [(raw[i:i + T], raw[i + T:i + T + 80])
             for i in range(0, len(raw) - T - 81, 8)]

    marks = [(0, "@1"), (4, "@5"), (19, "@20"), (79, "@80")]
    print("=" * 70)
    print(f"谱截断：保留前 r 个主模态（{len(pairs)} 个起点，归一化空间 RMSE）")
    print("=" * 70)
    print(f"  {'r':>6}" + "".join(f"{n:>11}" for _, n in marks))
    for r in (None, 64, 32, 16, 8):
        errs = []
        for s, gt_raw in pairs:
            c.decompose(s)
            row = []
            for k, _ in marks:
                z = c.forecast_spectral(s, k + 1, top_r=r)
                p = c._obs(z)
                gt = f._norm(gt_raw[k]).cpu().numpy()
                row.append(float(np.sqrt(((p - gt) ** 2).mean())))
            errs.append(row)
        mean = np.mean(errs, axis=0)
        label = "全谱" if r is None else str(r)
        print(f"  {label:>6}" + "".join(f"{v:>11.5f}" for v in mean))


def chaos():
    
    c = CSWM()
    x = _seed(c.f)
    c.decompose(x)
    ly = c.lyapunov()
    print("=" * 70)
    print("混沌诊断（世界模型不给的量）")
    print("=" * 70)
    print(f"  谱半径 ρ_max      = {ly['rho_max']:.5f}")
    print(f"  Lyapunov 估计     = {ly['lyapunov_est']:+.4f} / step"
          f"  （dt={ly['dt']}）")
    print(f"  模态数 {ly['n_modes']}｜振荡型占比 {ly['imag_frac']:.1%}")
    print(f"  参考：Lorenz rho=28 的真 Lyapunov ≈ 0.906/时间单位")
    print(f"        ⇒ 每步 ≈ {0.906 * ly['dt']:.5f}")
    print("\n  视界归因（该视界由哪些模态主导）：")
    for H in (1, 20, 80):
        print(f"    H={H:>3}:")
        for a in c.horizon_attribution(x, H):
            print(f"      mode {a['mode']:>3}｜|λ|={a['modulus']:.4f}"
                  f"｜频率 {a['freq_rad']:.3f}｜寿命 {a['decay_steps']} 步"
                  f"｜贡献 {a['share']:.1%}")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "verify"
    {"verify": verify, "speed": speed, "truncate": truncate,
     "chaos": chaos}[mode]()
