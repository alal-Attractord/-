















import os
import sys
import json
import time
import numpy as np

sys.path.insert(0, r'F:\ASI')
import realdata as RD
import _real_dyn_scan as DS
from _real_claim_confirm import resample, pick_target_channels, PLAN, N_CH, M_GRID, ALPHA_GRID

OUT = r'F:\ASI\_real_zerotrain_ci.json'
LOG = r'F:\ASI\_real_zerotrain_ci.log'
N_THREADS = 4
DEV = os.environ.get('RC_DEV', 'cuda' if os.environ.get('RC_NO_CUDA') is None else 'cpu')
BOOT = 30
K_GRID = [16, 32, 64, 128]
RFF_D = 512
RFF_GAMMA = [0.05, 0.2, 0.5, 1.0, 2.0, 5.0]
RFF_LAM = [1e-6, 1e-4, 1e-2, 1e-1, 1.0]
_FH = None


def log(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    if _FH:
        _FH.write(s + '\n')
        _FH.flush()


def chan_zt(x, tr, va, te, ycol):
    
    r = dict(ycol=int(ycol))

    zt = {'persist': [], 'diff1': [], 'diff2': []}
    persist_val = {'persist': [], 'diff1': [], 'diff2': []}
    for m in M_GRID:
        L, y, idx = DS.mk_delay(x, m)
        p_tr = np.where(idx <= tr[-1])[0]
        p_va = np.where((idx >= va[0]) & (idx <= va[-1]))[0]
        p_te = np.where(idx >= te[0])[0]
        if len(p_tr) < 100 or len(p_va) < 30 or len(p_te) < 30:
            continue
        Lva, yva = L[p_va], y[p_va]
        Lte, yte = L[p_te], y[p_te]
        zt['persist'].append((DS.mse(Lte[:, 0], yte), DS.mse(Lva[:, 0], yva), m))
        zt['diff1'].append((DS.mse(Lte[:, 0], yte), DS.mse(Lva[:, 0], yva), m))
        if m >= 2:
            p2 = 2.0 * Lte[:, 0] - Lte[:, 1]
            pv2 = 2.0 * Lva[:, 0] - Lva[:, 1]
            zt['diff2'].append((DS.mse(p2, yte), DS.mse(pv2, yva), m))
    for k, v in zt.items():
        if not v:
            continue
        b = min(v, key=lambda z: z[1])
        r[k] = dict(test=float(b[0]), val=float(b[1]), m=int(b[2]))

    best = None
    for m in M_GRID:
        L, y, idx = DS.mk_delay(x, m)
        p_tr = np.where(idx <= tr[-1])[0]
        p_va = np.where((idx >= va[0]) & (idx <= va[-1]))[0]
        p_te = np.where(idx >= te[0])[0]
        if len(p_tr) < 100 or len(p_va) < 30 or len(p_te) < 30:
            continue
        Ltr, ytr = L[p_tr], y[p_tr]
        Lva, yva = L[p_va], y[p_va]
        Lte, yte = L[p_te], y[p_te]
        bw, bva, ba = None, float('inf'), None
        for a in ALPHA_GRID:
            w = DS.ridge_fit(Ltr, ytr, a)
            v = DS.mse(DS.ridge_pred(Lva, w), yva)
            if v < bva:
                bva, bw, ba = v, w, a
        if best is None or bva < best[0]:
            best = (bva, m, ba)
    if best is None:
        return None
    m_s, a_s = best[1], best[2]
    L, y, idx = DS.mk_delay(x, m_s)
    p_tr = np.where(idx <= tr[-1])[0]
    p_va = np.where((idx >= va[0]) & (idx <= va[-1]))[0]
    p_te = np.where(idx >= te[0])[0]
    Ltr, ytr = L[p_tr], y[p_tr]
    Lva, yva = L[p_va], y[p_va]
    Lte, yte = L[p_te], y[p_te]
    w = DS.ridge_fit(Ltr, ytr, a_s)
    t0 = DS.mse(DS.ridge_pred(Lte, w), yte)
    rng = np.random.RandomState(2026 + int(ycol))
    boot = []
    for _ in range(BOOT):
        ii = rng.randint(0, len(Ltr), len(Ltr))
        wb = DS.ridge_fit(Ltr[ii], ytr[ii], a_s)
        boot.append(DS.mse(DS.ridge_pred(Lte, wb), yte))
    r['ar_lin'] = dict(test=float(t0), m=int(m_s), alpha=float(a_s),
                       boot_mean=float(np.mean(boot)), boot_sd=float(np.std(boot)),
                       n_boot=BOOT)

    if len(Ltr) > 6000:
        ss = np.random.RandomState(7).choice(len(Ltr), 6000, replace=False)
        Ltr_f, ytr_f = Ltr[ss], ytr[ss]
    else:
        Ltr_f, ytr_f = Ltr, ytr
    if len(Lva) > 1200:
        sv = np.random.RandomState(11).choice(len(Lva), 1200, replace=False)
        Lva_s, yva_s = Lva[sv], yva[sv]
    else:
        Lva_s, yva_s = Lva, yva
    bk, bvv, btv = None, float('inf'), None
    for k in K_GRID:
        if k >= len(Ltr_f):
            continue
        v = DS.mse(DS.knn_local(Ltr_f, ytr_f, Lva_s, k, 1), yva_s)
        if v < bvv:
            bvv, bk = v, k
    if bk is not None:
        btv = DS.mse(DS.knn_local(Ltr_f, ytr_f, Lte, bk, 1), yte)
    r['knn_loclin'] = dict(test=None if btv is None else float(btv),
                           val=float(bvv) if bk else None, k=bk,
                           n_train_used=int(len(Ltr_f)), n_val_used=int(len(Lva_s)))
    return r


def run(name, dt):
    stride = max(1, int(round(dt / RD.SPEC[name]['step_h'])))
    Z0, cols = RD.load_one(name)
    Z = resample(Z0, stride)
    T = Z.shape[0]
    tr, va, te = RD.lstf_split(T)
    Zs, mu, sd = RD.standardize(Z, tr)
    chans = pick_target_channels(Zs, N_CH)
    out = dict(name=name, dt_h=float(dt), T_res=int(T), chans=[int(c) for c in chans],
               chan_names=[str(cols[c]) for c in chans])
    recs = []
    for c in chans:
        r = chan_zt(Zs[:, int(c)], tr, va, te, int(c))
        if r is None:
            continue
        recs.append(r)
        log('      ch=%-3d persist=%.4e diff2=%.4e ar_lin=%.4e(+-%.1e boot) knn=%.4e(k=%s)'
            % (c, r['persist']['test'], r.get('diff2', {}).get('test', float('nan')),
               r['ar_lin']['test'], r['ar_lin']['boot_sd'],
               (r['knn_loclin']['test'] if r['knn_loclin']['test'] is not None else float('nan')),
               r['knn_loclin']['k']))
    out['channels'] = recs
    if recs:
        out['ar_lin_boot_sd_mean'] = float(np.mean([r['ar_lin']['boot_sd'] for r in recs]))
        out['diff2_over_persist'] = float(np.mean(
            [r['diff2']['test'] / r['persist']['test'] for r in recs if 'diff2' in r]))
        kn = [r['knn_loclin']['test'] for r in recs if r['knn_loclin']['test'] is not None]
        out['knn_loclin_over_arlin'] = (float(np.mean(
            [r['knn_loclin']['test'] / r['ar_lin']['test'] for r in recs
             if r['knn_loclin']['test'] is not None])) if kn else None)
    return out


def main():
    global _FH
    import torch
    torch.set_num_threads(N_THREADS)
    _FH = open(LOG, 'a', encoding='utf-8')
    names = sys.argv[1:] if len(sys.argv) > 1 else list(PLAN.keys())
    log('=' * 100)
    log('zerotrain-CI  %s  names=%s' % (time.strftime('%Y-%m-%d %H:%M:%S'), names))
    allr = {}
    if os.path.exists(OUT):
        try:
            allr = json.load(open(OUT, encoding='utf-8'))
        except Exception:
            allr = {}
    for n in names:
        for dt in PLAN[n]:
            key = '%g' % dt
            allr.setdefault(n, {})
            if key in allr[n]:
                log('  skip %s dt=%g (cached)' % (n, dt))
                continue
            t0 = time.time()
            try:
                r = run(n, dt)
                r['secs'] = round(time.time() - t0, 1)
                allr[n][key] = r
                log('  -> %-12s dt=%-5.1fh  diff2/persist=%.4f  ar_lin_boot_sd=%.2e  knn/ar_lin=%.3f  (%.0fs)'
                    % (n, dt, r['diff2_over_persist'], r['ar_lin_boot_sd_mean'],
                       r['knn_loclin_over_arlin'] or float('nan'), r['secs']))
            except Exception as e:
                import traceback
                log('  !! %s dt=%g FAIL %s: %s' % (n, dt, type(e).__name__, e))
                log(traceback.format_exc())
            json.dump(allr, open(OUT, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    log('--- 汇总 ---')
    log('%-13s %7s %12s %12s %12s %12s' %
        ('dataset', 'dt(h)', 'diff2/persist', 'arlin_boot_sd', 'knn/ar_lin', 'secs'))
    for n, dd in allr.items():
        for k, r in sorted(dd.items(), key=lambda kv: float(kv[0])):
            log('%-13s %7s %12.4f %12.2e %12.3f %12.0f' %
                (n, k, r['diff2_over_persist'], r['ar_lin_boot_sd_mean'],
                 r['knn_loclin_over_arlin'] or float('nan'), r['secs']))
    log('saved -> %s' % OUT)


if __name__ == '__main__':
    main()
