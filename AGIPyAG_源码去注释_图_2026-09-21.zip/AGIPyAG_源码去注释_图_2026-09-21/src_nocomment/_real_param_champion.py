


























import os
import sys
import json
import time
import numpy as np

sys.path.insert(0, r'F:\ASI')
import realdata as RD
import _real_dyn_scan as DS

OUT = r'F:\ASI\_real_param_champion.json'
OUT_GPU = r'F:\ASI\_real_param_champion_gpu.json'
OUT_VQL = r'F:\ASI\_real_param_champion_vql.json'
LOG = r'F:\ASI\_real_param_champion.log'
XREF = r'F:\ASI\_real_zerotrain_ci.json'
STAGE = os.environ.get('PC_STAGE', 'all')
DEV = os.environ.get('PC_DEV', 'cuda' if os.environ.get('PC_NO_CUDA') is None else 'cpu')
N_THREADS = int(os.environ.get('PC_THREADS', '6'))
N_CH = 5
M_GRID = [2, 4, 8, 16]
ALPHA_GRID = [1e-6, 1e-4, 1e-2, 1e-1, 1.0, 10.0, 100.0]
K_GRID = [16, 32, 64, 128, 256]
RBF_R = [16, 64, 128]
RBF_KAPPA = [1.0, 4.0]
RBF_ALPHA = [1e-6, 1e-4, 1e-2, 1e-1, 1.0, 10.0]
AFF_R = [16, 64, 256]
AFF_ALPHA = [1e-4, 1e-2, 1e-1, 1.0, 10.0]
AFF_SOFT_S = 3
KM_SEEDS = [0, 1, 2]
MAX_TR = 6000
MAX_VA = 1200
N_MLP_SEED = 3
MOE_R_GRID = [32, 128]
MOE_LR = 3e-3
MOE_EPOCHS = 100
DIST_HID = 128
DIST_LR = 3e-3
DIST_EPOCHS = 100
BS = int(os.environ.get('PC_BS', '2048'))

COOL_MICRO = float(os.environ.get('PC_COOL_MICRO', '0.3'))
COOL_EVERY = int(os.environ.get('PC_COOL_EVERY', '8'))
COOL_DEEP = float(os.environ.get('PC_COOL_DEEP', '15.0'))

PLAN = {
    'traffic':     [3.0, 6.0, 12.0],
    'electricity': [3.0, 6.0, 12.0],
    'solar_AL':    [1.0, 3.0, 6.0],
    'weather':     [3.0],
    'ETTh1':       [3.0, 6.0],
}
GPU_PLAN = {
    'traffic':     [3.0, 6.0, 12.0],
    'electricity': [3.0, 6.0, 12.0],
    'solar_AL':    [3.0, 6.0],
    'ETTh1':       [3.0],
}
_FH = None


def log(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    if _FH:
        _FH.write(s + '\n')
        _FH.flush()


def resample(Z, s):
    if s <= 1:
        return Z
    n = len(Z) // s
    return Z[:n * s].reshape(n, s, Z.shape[1]).mean(axis=1)


def pick_target_channels(Zs, nc):
    v = Zs.var(0)
    order = np.argsort(v)
    picks = [order[int(round(q * (len(order) - 1)))] for q in np.linspace(0.15, 0.9, nc)]
    return np.array(sorted(set(int(p) for p in picks)))


def mse(a, b):
    d = np.asarray(a) - np.asarray(b)
    if not np.all(np.isfinite(d)):
        return float('inf')
    return float(np.mean(d * d))


def cap_rows(A, B, cap, seed):
    if len(A) <= cap:
        return A, B
    ii = np.sort(np.random.RandomState(seed).choice(len(A), cap, replace=False))
    return A[ii], B[ii]


def add1(X):
    return np.concatenate([X, np.ones((len(X), 1))], 1)


def load_config(name, dt):
    stride = max(1, int(round(dt / RD.SPEC[name]['step_h'])))
    Z0, cols = RD.load_one(name)
    Z = resample(Z0, stride)
    T = Z.shape[0]
    tr, va, te = RD.lstf_split(T)
    Zs, mu, sd = RD.standardize(Z, tr)
    return Zs, cols, tr, va, te, int(stride), int(T)


def make_packs(x, tr, va, te):
    packs = {}
    for m in M_GRID:
        L, y, idx = DS.mk_delay(x, m)
        p_tr = np.where(idx <= tr[-1])[0]
        p_va = np.where((idx >= va[0]) & (idx <= va[-1]))[0]
        p_te = np.where(idx >= te[0])[0]
        if len(p_tr) < 200 or len(p_va) < 50 or len(p_te) < 50:
            continue
        packs[m] = (L[p_tr], y[p_tr], L[p_va], y[p_va], L[p_te], y[p_te])
    return packs


def select_M_arlin(packs):
    bv, bm = float('inf'), None
    for m, (A, ya, B, yb, Cc, yc) in packs.items():
        for al in ALPHA_GRID:
            w = DS.ridge_fit(A, ya, al)
            v = mse(DS.ridge_pred(B, w), yb)
            if v < bv:
                bv, bm = v, m
    return bm



def _batch_local_affine(Atr, ytr, Ate, nb, lam=1e-8, chunk=2000):
    
    nb = np.asarray(nb)
    if nb.ndim == 1:
        nb = nb[:, None]
    n, k = nb.shape
    if n == 0:
        return np.empty(0)
    p = Atr.shape[1] + 1
    I = lam * np.eye(p)
    out = np.empty(n)
    for s in range(0, n, chunk):
        e = min(s + chunk, n)
        ii = nb[s:e]
        P = np.concatenate([Atr[ii], np.ones((e - s, k, 1))], 2)
        G = np.einsum('bkp,bkq->bpq', P, P) + I[None]
        r = np.einsum('bkp,bk->bp', P, ytr[ii])
        w = np.linalg.solve(G, r[..., None])[..., 0]
        P0 = np.concatenate([Ate[s:e], np.ones((e - s, 1))], 1)
        out[s:e] = np.einsum('bp,bp->b', P0, w)
    return out


def knn_local_fast(Atr, ytr, Ate, k, lam=1e-8, chunk=2000):
    from scipy.spatial import cKDTree
    k = int(min(k, len(Atr)))
    _, nb = cKDTree(Atr).query(Ate, k=k)
    return _batch_local_affine(Atr, ytr, Ate, nb, lam=lam, chunk=chunk)


def knn_mean_fast(Atr, ytr, Ate, k):
    from scipy.spatial import cKDTree
    k = int(min(k, len(Atr)))
    _, nb = cKDTree(Atr).query(Ate, k=k)
    return ytr[np.atleast_2d(nb)].mean(axis=1)


def knn_local_loo(Atr, ytr, k, lam=1e-8):
    
    from scipy.spatial import cKDTree
    k = int(min(k, len(Atr) - 1))
    _, nb = cKDTree(Atr).query(Atr, k=k + 1)
    return _batch_local_affine(Atr, ytr, Atr, np.atleast_2d(nb)[:, 1:])


def selfcheck_knn(A, y):
    d = np.random.RandomState(3).choice(len(A), min(120, len(A)), replace=False)
    a = knn_local_fast(A, y, A[d], 32)
    b = DS.knn_local(A, y, A[d], 32, 1)
    return float(np.max(np.abs(a - b)) / max(np.max(np.abs(b)), 1e-300))



def kmeans(X, R, seed, iters=25, cap=4000):
    rng = np.random.RandomState(seed)
    n = len(X)
    sub = X[np.sort(rng.choice(n, cap, replace=False))] if n > cap else X
    x2 = (sub * sub).sum(1)
    C = np.empty((R, X.shape[1]), dtype=np.float64)
    C[0] = sub[rng.randint(len(sub))]
    d2 = ((sub - C[0]) ** 2).sum(1)
    for r in range(1, R):
        p = d2 / max(d2.sum(), 1e-300)
        i = rng.choice(len(sub), p=p)
        C[r] = sub[i]
        d2 = np.minimum(d2, ((sub - C[r]) ** 2).sum(1))
    for _ in range(iters):
        D2 = x2[:, None] - 2.0 * (sub @ C.T) + (C * C).sum(1)[None, :]
        lab = D2.argmin(1)
        for r in range(R):
            m = lab == r
            if m.any():
                C[r] = sub[m].mean(0)
    return C


def d2_to_centers(X, C):
    return ((X * X).sum(1)[:, None] - 2.0 * (X @ C.T) + (C * C).sum(1)[None, :])


def assign(X, C):
    return d2_to_centers(X, C).argmin(1)



def kmrbf_arm(Ltr, ytr, Lva, yva):
    best = None
    for sd_ in KM_SEEDS:
        for R in RBF_R:
            if R > len(Ltr):
                continue
            C = kmeans(Ltr, R, sd_)
            own = assign(Ltr, C)
            s2 = float(np.mean(((Ltr - C[own]) ** 2).sum(1))) + 1e-12
            for kap in RBF_KAPPA:
                g = kap / s2

                def feat(X, C=C, g=g):
                    return np.concatenate([X, np.exp(-g * np.maximum(d2_to_centers(X, C), 0.0)),
                                           np.ones((len(X), 1))], 1)

                Ftr, Fva = feat(Ltr), feat(Lva)
                G0 = Ftr.T @ Ftr
                rhs = Ftr.T @ ytr
                p = G0.shape[0]
                for al in RBF_ALPHA:
                    w = np.linalg.solve(G0 + al * np.eye(p), rhs)
                    v = mse(Fva @ w, yva)
                    if best is None or v < best[0]:
                        best = (v, sd_, R, kap, al, w, feat, int(p))
    return best



def kmaff_arm(Ltr, ytr, Lva, yva, soft=False):
    best = None
    mincnt = max(8, Ltr.shape[1] + 2)
    p = Ltr.shape[1] + 1
    I = np.eye(p)
    for sd_ in KM_SEEDS:
        for R in AFF_R:
            if R > len(Ltr):
                continue
            C = kmeans(Ltr, R, sd_)
            lab = assign(Ltr, C)
            lva = assign(Lva, C)
            s2 = float(np.mean(((Ltr - C[lab]) ** 2).sum(1))) + 1e-12
            Gs, rhs = {}, {}
            for r in np.unique(lab):
                mm = lab == r
                if mm.sum() < mincnt:
                    continue
                P = add1(Ltr[mm])
                Gs[int(r)] = P.T @ P
                rhs[int(r)] = P.T @ ytr[mm]
            if not Gs:
                continue
            if soft:
                kk = min(AFF_SOFT_S, len(C))
                D2v = d2_to_centers(Lva, C)
                nbr = np.argpartition(D2v, kk - 1, axis=1)[:, :kk]
                d2n = np.take_along_axis(D2v, nbr, 1)
                base = add1(Lva)
                gk_grid = [0.25, 1.0, 4.0]
            else:
                gk_grid = [None]
            for al in AFF_ALPHA:
                wmap = {r: np.linalg.solve(Gs[r] + al * I, rhs[r]) for r in Gs}
                if not soft:
                    pv = Lva[:, 0].copy()
                    for r, w in wmap.items():
                        mm = lva == r
                        if mm.any():
                            pv[mm] = add1(Lva[mm]) @ w
                    v = mse(pv, yva)
                    if best is None or v < best['val']:
                        best = dict(val=float(v), seed=int(sd_), R=int(R), alpha=float(al),
                                    ws=wmap, C=C, mode='hard', kappa=None, s2=float(s2))
                else:
                    base = add1(Lva)
                    for gk in gk_grid:
                        wt = np.exp(-(gk / s2) * d2n)
                        wt = wt / np.maximum(wt.sum(1, keepdims=True), 1e-300)
                        acc = np.zeros(len(Lva))
                        for j in range(kk):
                            idx_r = nbr[:, j]
                            wj = np.zeros((len(Lva), p))
                            for r, w in wmap.items():
                                mm = idx_r == r
                                if mm.any():
                                    wj[mm] = w
                            acc += wt[:, j] * np.einsum('bp,bp->b', base, wj)
                        v = mse(acc, yva)
                        if best is None or v < best['val']:
                            best = dict(val=float(v), seed=int(sd_), R=int(R), alpha=float(al),
                                        ws=wmap, C=C, mode='soft', kappa=float(gk), s2=float(s2))
    return best


def kmaff_eval(info, L):
    C, ws = info['C'], info['ws']
    base = add1(L)
    if info['mode'] == 'hard':
        lab = assign(L, C)
        out = L[:, 0].copy()
        for r, w in ws.items():
            mm = lab == r
            if mm.any():
                out[mm] = base[mm] @ w
        return out
    kk = min(AFF_SOFT_S, len(C))
    D2v = d2_to_centers(L, C)
    nbr = np.argpartition(D2v, kk - 1, axis=1)[:, :kk]
    d2n = np.take_along_axis(D2v, nbr, 1)
    s2 = max(float(info['s2']), 1e-12)
    wt = np.exp(-(info['kappa'] / s2) * d2n)
    wt = wt / np.maximum(wt.sum(1, keepdims=True), 1e-300)
    acc = np.zeros(len(L))
    p = base.shape[1]
    for j in range(kk):
        idx_r = nbr[:, j]
        wj = np.zeros((len(L), p))
        for r, w in ws.items():
            mm = idx_r == r
            if mm.any():
                wj[mm] = w
        acc += wt[:, j] * np.einsum('bp,bp->b', base, wj)
    return acc



def chan_run(x, tr, va, te, ycol):
    r = dict(ycol=int(ycol))
    packs = make_packs(x, tr, va, te)
    if not packs:
        return None
    bv, bt, bm = float('inf'), None, None
    for m, (A, ya, B, yb, Cc, yc) in packs.items():
        v = mse(B[:, 0], yb)
        if v < bv:
            bv, bt, bm = v, mse(Cc[:, 0], yc), m
    r['persist'] = dict(test=float(bt), val=float(bv), M=int(bm))
    bv, bt, bm, ba = float('inf'), None, None, None
    for m, (A, ya, B, yb, Cc, yc) in packs.items():
        for al in ALPHA_GRID:
            w = DS.ridge_fit(A, ya, al)
            v = mse(DS.ridge_pred(B, w), yb)
            if v < bv:
                bv, bt, bm, ba = v, mse(DS.ridge_pred(Cc, w), yc), m, al
    r['ar_lin'] = dict(test=float(bt), val=float(bv), M=int(bm), alpha=float(ba))
    for tag in ('knn_mean', 'knn_loclin'):
        fn = knn_mean_fast if tag == 'knn_mean' else knn_local_fast
        bv, bm, bk = float('inf'), None, None
        for m, (A, ya, B, yb, Cc, yc) in packs.items():
            Af, yf = cap_rows(A, ya, MAX_TR, 7)
            Bf, yb_f = cap_rows(B, yb, MAX_VA, 11)
            for k in K_GRID:
                if k >= len(Af):
                    continue
                v = mse(fn(Af, yf, Bf, k), yb_f)
                if v < bv:
                    bv, bk, bm = v, k, m
        bt = None
        if bk is not None:
            A, ya, B, yb, Cc, yc = packs[bm]
            Af, yf = cap_rows(A, ya, MAX_TR, 7)
            t0 = time.perf_counter()
            pr = fn(Af, yf, Cc, bk)
            ms = (time.perf_counter() - t0) * 1e3
            bt = mse(pr, yc)
            r.setdefault('cost', {})[tag] = dict(
                ms_per_1k=float(ms / max(len(Cc), 1) * 1000),
                bytes=int(Af.nbytes + yf.nbytes))
        r[tag] = dict(test=(None if bt is None else float(bt)), val=float(bv),
                      M=(None if bm is None else int(bm)), k=bk)

    if r['ar_lin']['M'] in packs:
        A, ya, B, yb, Cc, yc = packs[r['ar_lin']['M']]
        Af, yf = cap_rows(A, ya, MAX_TR, 7)
        Bf, yb_f = cap_rows(B, yb, MAX_VA, 11)
        bvv, bk = float('inf'), None
        for k in K_GRID:
            if k >= len(Af):
                continue
            v = mse(knn_local_fast(Af, yf, Bf, k), yb_f)
            if v < bvv:
                bvv, bk = v, k
        if bk is not None:
            r['knn_loclin_mfix'] = dict(test=mse(knn_local_fast(Af, yf, Cc, bk), yc),
                                        val=float(bvv), M=int(r['ar_lin']['M']), k=bk)
    bv, bm, info = float('inf'), None, None
    for m, (A, ya, B, yb, Cc, yc) in packs.items():
        Af, yf = cap_rows(A, ya, MAX_TR, 7)
        Bf, yb_f = cap_rows(B, yb, MAX_VA, 11)
        got = kmrbf_arm(Af, yf, Bf, yb_f)
        if got is not None and got[0] < bv:
            bv, bm, info = got[0], m, got
    if info is not None:
        _, sd_, R, kap, al, w, feat, p = info
        A, ya, B, yb, Cc, yc = packs[bm]
        t0 = time.perf_counter()
        pr = feat(Cc) @ w
        ms = (time.perf_counter() - t0) * 1e3
        r['kmrbf'] = dict(test=mse(pr, yc), val=float(bv), M=int(bm), R=int(R),
                          kappa=float(kap), alpha=float(al), km_seed=int(sd_), n_params=int(p),
                          ms_per_1k=float(ms / max(len(Cc), 1) * 1000),
                          bytes=int(p * 8))
    for tag, soft in (('kmaff', False), ('kmaff_soft', True)):
        bv, bm, info = float('inf'), None, None
        for m, (A, ya, B, yb, Cc, yc) in packs.items():
            Af, yf = cap_rows(A, ya, MAX_TR, 7)
            Bf, yb_f = cap_rows(B, yb, MAX_VA, 11)
            got = kmaff_arm(Af, yf, Bf, yb_f, soft=soft)
            if got is not None and got['val'] < bv:
                bv, bm, info = got['val'], m, got
        if info is not None:
            A, ya, B, yb, Cc, yc = packs[bm]
            t0 = time.perf_counter()
            pr = kmaff_eval(info, Cc)
            ms = (time.perf_counter() - t0) * 1e3
            Ru = len(info['ws'])
            npar = int(Ru * (A.shape[1] + 1) * (2 if soft else 1) + Ru * A.shape[1] * (1 if soft else 0))
            r[tag] = dict(test=mse(pr, yc), val=float(bv), M=int(bm), R=int(info['R']),
                          R_used=int(Ru), alpha=float(info['alpha']), kappa=info.get('kappa'),
                          mode=info['mode'], km_seed=int(info['seed']), n_params=npar,
                          ms_per_1k=float(ms / max(len(Cc), 1) * 1000), bytes=int(npar * 8))
    r['M_star'] = int(r['ar_lin']['M'])
    return r


def closed_stage():
    allr = {}
    if os.path.exists(OUT):
        try:
            allr = json.load(open(OUT, encoding='utf-8'))
        except Exception:
            allr = {}
    names = [a for a in sys.argv[1:] if a in PLAN] or list(PLAN.keys())
    for n in names:
        for dt in PLAN[n]:
            key = '%g' % dt
            allr.setdefault(n, {})
            if key in allr[n] and allr[n][key].get('channels') and not os.environ.get('PC_FORCE'):
                log('  skip %s dt=%g (cached)' % (n, dt))
                continue
            t0 = time.time()
            try:
                Zs, cols, tr, va, te, stride, T = load_config(n, dt)
                chans = pick_target_channels(Zs, N_CH)
                out = dict(name=n, dt_h=float(dt), T_res=int(T), stride=int(stride),
                           blocks=[[int(tr[0]), int(tr[-1])], [int(va[0]), int(va[-1])],
                                   [int(te[0]), int(te[-1])]],
                           chans=[int(c) for c in chans])
                recs = []
                for c in chans:
                    rec = chan_run(Zs[:, int(c)], tr, va, te, int(c))
                    if rec is None:
                        continue
                    recs.append(rec)
                    kk = rec.get('knn_loclin', {})
                    km = rec.get('kmrbf', {})
                    ka = rec.get('kmaff', {})
                    kso = rec.get('kmaff_soft', {})
                    kt = kk.get('test') or float('nan')

                    def _x(d):
                        return (d.get('test') or float('nan')) / kt
                    log('      ch=%-4d M*=%-3s knn_mean=%.4e knn_ll=%.4e(M%s k%s) | kmrbf=%.4e x%.3f'
                        ' | kmaff=%.4e x%.3f | kmaff_soft=%.4e x%.3f'
                        % (c, rec['M_star'], rec.get('knn_mean', {}).get('test') or float('nan'),
                           kt, kk.get('M'), kk.get('k'), km.get('test') or float('nan'), _x(km),
                           ka.get('test') or float('nan'), _x(ka),
                           kso.get('test') or float('nan'), _x(kso)))
                out['channels'] = recs
                out['secs'] = round(time.time() - t0, 1)
                allr[n][key] = out
                if recs:
                    def gm(tag):
                        v = [x.get(tag, {}).get('test') for x in recs]
                        v = [y for y in v if y]
                        return float(np.mean(v)) if v else float('nan')
                    log('  -> %-12s dt=%-5.1fh knn_ll=%.4e kmrbf=%.4e (x%.3f) kmaff=%.4e (x%.3f)'
                        ' kmaff_soft=%.4e (x%.3f) (%.0fs)'
                        % (n, dt, gm('knn_loclin'), gm('kmrbf'),
                           gm('kmrbf') / max(gm('knn_loclin'), 1e-300), gm('kmaff'),
                           gm('kmaff') / max(gm('knn_loclin'), 1e-300), gm('kmaff_soft'),
                           gm('kmaff_soft') / max(gm('knn_loclin'), 1e-300), out['secs']))
            except Exception as e:
                import traceback
                log('  !! %s dt=%g FAIL %s: %s' % (n, dt, type(e).__name__, e))
                log(traceback.format_exc())
            json.dump(allr, open(OUT, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)



def mlp_stage():
    import torch
    import torch.nn as nn

    class MoE(nn.Module):
        def __init__(self, m, R):
            super().__init__()
            self.gate = nn.Linear(m, R)
            self.a = nn.Parameter(torch.randn(R, m) * 0.05)
            self.b = nn.Parameter(torch.zeros(R))

        def forward(self, x):
            g = torch.softmax(self.gate(x), -1)
            return (g * (x @ self.a.T + self.b)).sum(-1)

    class MLP(nn.Module):
        def __init__(self, m, hid):
            super().__init__()
            self.net = nn.Sequential(nn.Linear(m, hid), nn.ReLU(), nn.Linear(hid, hid),
                                     nn.ReLU(), nn.Linear(hid, 1))

        def forward(self, x):
            return self.net(x).squeeze(-1)

    COOL_N = [0]

    def fit(net, Xtr, ytr, Xva, yva, epochs, lr, seed):
        torch.manual_seed(seed)
        dev = torch.device(DEV)
        net = net.to(dev)
        opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-5)
        lossf = nn.MSELoss()
        Xa = torch.tensor(Xtr, dtype=torch.float32, device=dev)
        Ya = torch.tensor(ytr, dtype=torch.float32, device=dev)
        Xv = torch.tensor(Xva, dtype=torch.float32, device=dev)
        Yv = torch.tensor(yva, dtype=torch.float32, device=dev)
        best, bstate = float('inf'), None
        n = len(Xa)
        bs = min(BS, n)
        for ep in range(epochs):
            perm = torch.randperm(n, device=dev)
            for i in range(0, n, bs):
                ii = perm[i:i + bs]
                opt.zero_grad(set_to_none=True)
                lossf(net(Xa[ii]), Ya[ii]).backward()
                opt.step()
            if ep % 20 == 19 or ep == epochs - 1:
                with torch.no_grad():
                    v = float(lossf(net(Xv), Yv))
                if v < best:
                    best, bstate = v, {k: t.detach().clone() for k, t in net.state_dict().items()}
        if bstate:
            net.load_state_dict(bstate)

        try:
            torch.cuda.synchronize()
        except Exception:
            pass
        time.sleep(COOL_MICRO)
        COOL_N[0] += 1
        if COOL_EVERY > 0 and COOL_N[0] % COOL_EVERY == 0:
            log('      [散热] 已完成 %d 次训练, 深冷却 %.0fs ...' % (COOL_N[0], COOL_DEEP))
            time.sleep(COOL_DEEP)
        return net, best, int(sum(p.numel() for p in net.parameters()))

    def pred_ms(net, X):
        t0 = time.perf_counter()
        with torch.no_grad():
            y = net(torch.tensor(X, dtype=torch.float32, device=DEV)).cpu().numpy()
        ms = (time.perf_counter() - t0) * 1e3
        return y, float(ms / max(len(X), 1) * 1000)

    closed = {}
    if os.path.exists(OUT):
        try:
            closed = json.load(open(OUT, encoding='utf-8'))
        except Exception:
            closed = {}
    allg = {}
    if os.path.exists(OUT_GPU):
        try:
            allg = json.load(open(OUT_GPU, encoding='utf-8'))
        except Exception:
            allg = {}
    names = [a for a in sys.argv[1:] if a in GPU_PLAN] or list(GPU_PLAN.keys())
    for n in names:
        for dt in GPU_PLAN[n]:
            key = '%g' % dt
            allg.setdefault(n, {})
            blk = allg[n].setdefault(key, dict(name=n, dt_h=float(dt), channels=[]))
            done = blk.get('channels') or []
            done_y = {r['ycol'] for r in done}
            if len(done) >= N_CH and all(('moe_affine' in r and 'mlp_distill' in r) for r in done) \
                    and not os.environ.get('PC_FORCE'):
                log('  [GPU] skip %s dt=%g (cached)' % (n, dt))
                continue
            t0 = time.time()
            Zs, cols, tr, va, te, stride, T = load_config(n, dt)
            chans = pick_target_channels(Zs, N_CH)
            recs = list(done)
            for c in chans:
                if c in done_y:
                    continue
                x = Zs[:, int(c)]
                packs = make_packs(x, tr, va, te)
                if not packs:
                    continue
                m = select_M_arlin(packs)
                A, ya, B, yb, Cc, yc = packs[m]
                Af, yf = cap_rows(A, ya, MAX_TR, 7)
                Bf, yb_f = cap_rows(B, yb, MAX_VA, 11)
                kref = None
                for rc in (closed.get(n, {}).get(key, {}).get('channels') or []):
                    if rc['ycol'] == c:
                        kref = rc.get('knn_loclin', {}).get('k')
                if not kref:
                    bv, bk = float('inf'), None
                    for k in K_GRID:
                        if k >= len(Af):
                            continue
                        v = mse(knn_local_fast(Af, yf, Bf, k), yb_f)
                        if v < bv:
                            bv, bk = v, k
                    kref = bk
                rec = dict(ycol=int(c), M=int(m))

                bv, binfo = float('inf'), None
                for R in MOE_R_GRID:
                    ts, vs, ps, ms1 = [], [], [], []
                    for sd_ in range(N_MLP_SEED):
                        net, v, p = fit(MoE(m, R), Af, yf, Bf, yb_f, MOE_EPOCHS, MOE_LR, sd_)
                        pr, ms = pred_ms(net, Cc)
                        ts.append(mse(pr, yc))
                        vs.append(v)
                        ps.append(p)
                        ms1.append(ms)
                    if np.mean(vs) < bv:
                        bv, binfo = float(np.mean(vs)), dict(
                            R=int(R), test=float(np.mean(ts)), test_sd=float(np.std(ts)),
                            val=float(np.mean(vs)), n_params=int(max(ps)), n_seeds=N_MLP_SEED,
                            ms_per_1k=float(np.mean(ms1)), bytes=int(max(ps) * 4),
                            per_seed=[float(t) for t in ts])
                rec['moe_affine'] = binfo

                ts, vs, ps, ms1 = [], [], [], []
                for sd_ in range(N_MLP_SEED):
                    net, v, p = fit(MLP(m, DIST_HID), Af, yf, Bf, yb_f, DIST_EPOCHS, DIST_LR, sd_)
                    pr, ms = pred_ms(net, Cc)
                    ts.append(mse(pr, yc))
                    vs.append(v)
                    ps.append(p)
                    ms1.append(ms)
                rec['mlp_direct'] = dict(test=float(np.mean(ts)), test_sd=float(np.std(ts)),
                                         val=float(np.mean(vs)), n_params=int(max(ps)),
                                         n_seeds=N_MLP_SEED, ms_per_1k=float(np.mean(ms1)),
                                         bytes=int(max(ps) * 4))

                if kref:
                    ytar = knn_local_loo(Af, yf, int(kref))
                    ts, vs, ps, ms1 = [], [], [], []
                    for sd_ in range(N_MLP_SEED):
                        net, v, p = fit(MLP(m, DIST_HID), Af, ytar, Bf, yb_f,
                                        DIST_EPOCHS, DIST_LR, sd_)
                        pr, ms = pred_ms(net, Cc)
                        ts.append(mse(pr, yc))
                        vs.append(v)
                        ps.append(p)
                        ms1.append(ms)
                    rec['mlp_distill'] = dict(test=float(np.mean(ts)), test_sd=float(np.std(ts)),
                                              val=float(np.mean(vs)), n_params=int(max(ps)),
                                              n_seeds=N_MLP_SEED, target='knn_loclin LOO',
                                              ms_per_1k=float(np.mean(ms1)),
                                              bytes=int(max(ps) * 4))
                recs.append(rec)
                allg[n][key]['channels'] = recs
                allg[n][key]['secs'] = round(time.time() - t0, 1)
                json.dump(allg, open(OUT_GPU, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
                kt = None
                for rc in (closed.get(n, {}).get(key, {}).get('channels') or []):
                    if rc['ycol'] == c:
                        kt = rc.get('knn_loclin', {}).get('test')
                log('      [GPU] %-11s dt=%-4g ch=%-4d M=%d moe=%.4e (x%.3f R=%d p=%d) '
                    'direct=%.4e distill=%.4e knn_ll=%.4e'
                    % (n, dt, c, m, rec['moe_affine']['test'],
                       rec['moe_affine']['test'] / max(kt or 1e-300, 1e-300),
                       rec['moe_affine']['R'], rec['moe_affine']['n_params'],
                       rec['mlp_direct']['test'], rec.get('mlp_distill', {}).get('test', float('nan')),
                       kt or float('nan')))
            allg[n][key] = dict(name=n, dt_h=float(dt), channels=recs,
                                secs=round(time.time() - t0, 1))
            json.dump(allg, open(OUT_GPU, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)



def load_merged():
    a = json.load(open(OUT, encoding='utf-8')) if os.path.exists(OUT) else {}
    for extra in (OUT_GPU, OUT_VQL):
        b = json.load(open(extra, encoding='utf-8')) if os.path.exists(extra) else {}
        for n, dd in b.items():
            for k, blk in dd.items():
                base = a.setdefault(n, {}).setdefault(k, {'channels': []})
                if not base.get('channels'):
                    base['channels'] = []
                by = {r['ycol']: r for r in base['channels']}
                for rec in blk.get('channels', []):
                    if rec['ycol'] in by:
                        by[rec['ycol']].update({t: v for t, v in rec.items() if t != 'ycol'})
                    else:
                        base['channels'].append(rec)
    return a


def cross_check(allr):
    if not os.path.exists(XREF):
        return
    ref = json.load(open(XREF, encoding='utf-8'))
    n_ok, n_bad, worst, worst_at = 0, 0, 0.0, None
    for n, dd in allr.items():
        for k, blk in dd.items():
            rb = ref.get(n, {}).get(k)
            if not rb:
                continue
            for rec in blk.get('channels', []):
                rc = next((z for z in rb['channels'] if z['ycol'] == rec['ycol']), None)
                if rc is None:
                    continue
                for tag in ('persist', 'ar_lin', 'knn_loclin_mfix'):
                    a = rec.get(tag, {}).get('test')
                    b = rc.get(tag, {}).get('test')
                    if a is None or b is None:
                        continue
                    d = abs(a - b) / max(abs(b), 1e-300)
                    if d < 1e-9:
                        n_ok += 1
                    else:
                        n_bad += 1
                        if d > worst:
                            worst, worst_at = d, '%s dt=%s ch=%d %s' % (n, k, rec['ycol'], tag)
    log('--- 交叉核验 vs _real_zerotrain_ci.json (同口径必须同数字) ---')
    log('    一致(=完全相同) %d 项 | 不一致 %d 项 | 最大相对差 %.3e %s'
        % (n_ok, n_bad, worst, worst_at or ''))


def pooled(allr):
    tags = ('ar_lin', 'knn_mean', 'kmrbf', 'kmaff', 'kmaff_soft', 'vql', 'vql_soft',
            'moe_affine', 'mlp_direct', 'mlp_distill')
    out = {}
    for tag in tags:
        v, cost = [], []
        for n, dd in allr.items():
            for k, blk in dd.items():
                for rec in blk.get('channels') or []:
                    a = rec.get('knn_loclin', {}).get('test')
                    b = rec.get(tag, {}).get('test')
                    if a and b:
                        v.append(b / a)
                    if rec.get(tag, {}).get('ms_per_1k'):
                        cost.append(rec[tag]['ms_per_1k'])
        if not v:
            continue
        v = np.array(v)
        out[tag] = dict(n=int(len(v)), mean=float(v.mean()), median=float(np.median(v)),
                        mn=float(v.min()), mx=float(v.max()),
                        ge1=float((v >= 1).mean()), le105=float((v <= 1.05).mean()),
                        ms_per_1k=float(np.median(cost)) if cost else None)
    return out


def summarize(allr):
    log('--- 参数化 vs 非参冠军 (每格 = 该配置 5 通道 test MSE 均值; x = /knn_loclin) ---')
    hdr = ('%-12s %5s %4s %11s %11s %6s %11s %6s %11s %6s %11s %6s %11s %6s %8s %8s %8s %8s')
    log(hdr % ('dataset', 'dt', 'nch', 'persist', 'ar_lin', 'x', 'knn_mean', 'x',
               'knn_loclin', 'x', 'kmrbf', 'x', 'kmaff', 'x', 'kmsoft_x', 'vql_x',
               'vqlsoft_x', 'moe_x'))
    rows = []
    for n, dd in allr.items():
        for k, blk in sorted(dd.items(), key=lambda kv: float(kv[0])):
            recs = blk.get('channels') or []
            if not recs:
                continue

            def gm(tag):
                v = [x.get(tag, {}).get('test') for x in recs]
                v = [y for y in v if y]
                return float(np.mean(v)) if v else float('nan')
            a = gm('knn_loclin')

            def q(t):
                return gm(t) / a if a and a == a else float('nan')
            row = [n, k, len(recs), gm('persist'), gm('ar_lin'), q('ar_lin'), gm('knn_mean'),
                   q('knn_mean'), a, 1.0, gm('kmrbf'), q('kmrbf'), gm('kmaff'), q('kmaff'),
                   q('kmaff_soft'), q('vql'), q('vql_soft'), q('moe_affine')]
            rows.append(row)
            log(hdr % tuple(row))
    return rows


def main():
    global _FH
    import torch
    torch.set_num_threads(N_THREADS)
    _FH = open(LOG, 'a', encoding='utf-8')
    log('=' * 104)
    log('PARAM-CHAMPION  %s  stage=%s dev=%s threads=%d'
        % (time.strftime('%Y-%m-%d %H:%M:%S'), STAGE, DEV, N_THREADS))
    try:
        rng = np.random.RandomState(0)
        As = rng.randn(800, 6)
        ys = As[:, 0] * 0.5 + As[:, 1] * 0.2 + rng.randn(800) * 0.05
        log('  [自检] 向量化 kNN 局部仿射 vs 逐点实现: 最大相对差 = %.3e (应 <1e-10)'
            % selfcheck_knn(As, ys))
    except Exception as e:
        log('  [自检] 失败: %s' % e)
    if STAGE in ('closed', 'all'):
        closed_stage()
    if STAGE in ('mlp', 'all'):
        mlp_stage()
    allr = load_merged()
    rows = summarize(allr)
    cross_check(json.load(open(OUT, encoding='utf-8')) if os.path.exists(OUT) else {})
    pl = pooled(allr)
    if pl:
        log('--- 逐 (图, dt, 通道) 池化: 各臂 / knn_loclin (越小越好, >1 = 输给冠军) ---')
        log('%-13s %5s %9s %9s %9s %9s %10s %12s %12s' %
            ('arm', 'n', 'mean', 'median', 'min', 'max', '>=1 占比', '<=1.05 占比', 'ms/1k 中位'))
        for tag, v in pl.items():
            log('%-13s %5d %9.3f %9.3f %9.3f %9.3f %9.1f%% %11.1f%% %12s' %
                (tag, v['n'], v['mean'], v['median'], v['mn'], v['mx'], v['ge1'] * 100,
                 v['le105'] * 100, ('%.5f' % v['ms_per_1k']) if v['ms_per_1k'] else '-'))
    with open(r'F:\ASI\_real_param_champion_pool.json', 'w', encoding='utf-8') as f:
        json.dump(dict(pooled=pl, table=rows), f, indent=1, ensure_ascii=False)
    log('saved -> %s' % OUT)


if __name__ == '__main__':
    main()
