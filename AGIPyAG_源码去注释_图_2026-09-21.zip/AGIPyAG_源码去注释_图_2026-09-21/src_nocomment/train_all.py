#!/usr/bin/env python3






















import os
import sys
import re
import json
import math
import time
import argparse
import logging
import traceback
import importlib.util
from typing import Optional, Dict, Any, List, Tuple
from collections import Counter, deque
from datetime import datetime




_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts, CosineAnnealingLR

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('AGIPyAG.TrainAll')




DEFAULTS = {
    'data_dir': os.path.join(_PROJECT_ROOT, 'data', 'wikitext-2'),
    'checkpoint_dir': os.path.join(_PROJECT_ROOT, 'checkpoints'),
    'models_dir': os.path.join('F:', 'AGI', 'models'),
    'corpus_path': os.path.join(_PROJECT_ROOT, 'backend', 'data', 'corpus.txt'),
    'device': 'cuda' if torch.cuda.is_available() else 'cpu',
}
os.makedirs(DEFAULTS['checkpoint_dir'], exist_ok=True)
os.makedirs(DEFAULTS['models_dir'], exist_ok=True)






def setup_amp(device: torch.device):
    
    cuda = device.type == 'cuda'
    has_bf16 = cuda and torch.cuda.is_bf16_supported()
    use_amp = cuda
    amp_dtype = torch.bfloat16 if has_bf16 else torch.float16
    scaler = torch.amp.GradScaler('cuda', enabled=(cuda and not has_bf16)) if cuda else None
    device_type = 'cuda' if cuda else 'cpu'
    logger.info(f"AMP: cuda={cuda}, bf16={has_bf16}, dtype={amp_dtype}, scaler={scaler is not None}")
    return use_amp, amp_dtype, scaler, device_type


def _safe_loss_check(loss_val: float, thread_name: str = "train") -> bool:
    
    if math.isnan(loss_val) or math.isinf(loss_val):
        logger.warning(f"[{thread_name}] 非有限损失: {loss_val}，跳过")
        return True
    return False


def ensure_wikitext(data_dir: str):
    
    os.makedirs(data_dir, exist_ok=True)
    base_url = "https://raw.githubusercontent.com/pytorch/examples/main/word_language_model/data/wikitext-2"
    for split in ['train', 'valid', 'test']:
        path = os.path.join(data_dir, f'{split}.txt')
        if not os.path.exists(path):
            try:
                import urllib.request
                url = f"{base_url}/{split}.txt"
                logger.info(f"下载 {url} ...")
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    with open(path, "wb") as f:
                        f.write(resp.read())
            except Exception as e:
                logger.error(f"下载失败: {e}")
                raise






class SimpleTokenizer:
    

    def __init__(self, vocab_size: int = 10000):
        self.vocab_size = vocab_size
        self.pad_token = '[PAD]'
        self.unk_token = '[UNK]'
        self.bos_token = '[BOS]'
        self.eos_token = '[EOS]'
        self.pad_id = 0
        self.unk_id = 1
        self.bos_id = 2
        self.eos_id = 3
        self.vocab = {
            self.pad_token: self.pad_id,
            self.unk_token: self.unk_id,
            self.bos_token: self.bos_id,
            self.eos_token: self.eos_id,
        }
        self.reverse_vocab = {v: k for k, v in self.vocab.items()}

    def _tokenize(self, text: str) -> List[str]:
        text = text.lower()
        text = re.sub(r"[^a-z0-9\s\.\,\!\?\;\:\-\'\"]", " ", text)
        return text.split()

    def fit(self, texts: List[str]):
        counter = Counter()
        for text in texts:
            counter.update(self._tokenize(text))
        for token, _ in counter.most_common(self.vocab_size - len(self.vocab)):
            if token not in self.vocab:
                idx = len(self.vocab)
                self.vocab[token] = idx
                self.reverse_vocab[idx] = token
        self.vocab_size = len(self.vocab)
        logger.info(f"Tokenizer 词表大小: {self.vocab_size}")

    def encode(self, text: str) -> List[int]:
        return [self.vocab.get(t, self.unk_id) for t in self._tokenize(text)]

    def decode(self, ids: List[int], skip_special: bool = True) -> str:
        tokens = []
        for i in ids:
            tok = self.reverse_vocab.get(i, self.unk_token)
            if skip_special and tok in {self.pad_token, self.bos_token, self.eos_token}:
                continue
            tokens.append(tok)
        return ' '.join(tokens)

    def save(self, path: str):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self.vocab, f, ensure_ascii=False, indent=2)

    def load(self, path: str):
        with open(path, 'r', encoding='utf-8') as f:
            self.vocab = json.load(f)
        self.reverse_vocab = {int(v): k for k, v in self.vocab.items()}
        self.vocab_size = len(self.vocab)


class WikiTextDataset(Dataset):
    def __init__(self, token_ids: List[int], seq_len: int = 128):
        self.seq_len = seq_len
        self.tokens = token_ids
        self.num_samples = max(1, len(token_ids) // seq_len)

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        start = idx * self.seq_len
        end = start + self.seq_len + 1
        chunk = self.tokens[start:end]
        if len(chunk) < self.seq_len + 1:
            chunk = chunk + [0] * (self.seq_len + 1 - len(chunk))
        x = torch.tensor(chunk[:-1], dtype=torch.long)
        y = torch.tensor(chunk[1:], dtype=torch.long)
        return x, y


class TrainingFirewall:
    

    def __init__(self, spike_factor: float = 3.0, ema_decay: float = 0.95, max_grad_norm: float = 1.0):
        self.spike_factor = spike_factor
        self.ema_decay = ema_decay
        self.max_grad_norm = max_grad_norm
        self.loss_ema = None
        self.skip_count = 0
        self.nan_count = 0

    def check_loss(self, loss: torch.Tensor) -> Tuple[bool, float]:
        val = loss.item()
        if math.isnan(val) or math.isinf(val):
            self.nan_count += 1
            return True, self.loss_ema if self.loss_ema is not None else 1.0
        if self.loss_ema is None:
            self.loss_ema = val
        else:
            self.loss_ema = self.ema_decay * self.loss_ema + (1 - self.ema_decay) * val
        if val > self.spike_factor * max(self.loss_ema, 1e-6):
            self.skip_count += 1
            return True, self.loss_ema
        return False, self.loss_ema

    def clip_gradients(self, model: nn.Module, optimizer, scaler=None) -> float:
        if scaler is not None:
            scaler.unscale_(optimizer)
        total_norm = nn.utils.clip_grad_norm_(model.parameters(), self.max_grad_norm)
        if torch.isnan(total_norm) or torch.isinf(total_norm):
            return 1e6
        return float(total_norm)


def _load_starlight_trainer():
    
    from DeeNeuralNetwork.starlight_model import StarLightModel, StarLightConfig
    from DeeNeuralNetwork.starlight_trainer import StarLightTrainer
    return StarLightModel, StarLightConfig, StarLightTrainer


def train_starlight(args):
    
    logger.info("=" * 60)
    logger.info("  StarLight 训练启动")
    logger.info("=" * 60)

    ensure_wikitext(args.data_dir)
    StarLightModel, StarLightConfig, StarLightTrainer = _load_starlight_trainer()

    device = torch.device(args.device)
    use_amp, amp_dtype, scaler, device_type = setup_amp(device)


    with open(os.path.join(args.data_dir, 'train.txt'), 'r', encoding='utf-8') as f:
        train_text = f.read()
    with open(os.path.join(args.data_dir, 'valid.txt'), 'r', encoding='utf-8') as f:
        val_text = f.read()

    ckpt_dir = os.path.join(args.checkpoint_dir, 'starlight')
    os.makedirs(ckpt_dir, exist_ok=True)
    tokenizer_path = os.path.join(ckpt_dir, 'tokenizer.json')

    tokenizer = SimpleTokenizer(vocab_size=args.vocab_size)
    if os.path.exists(tokenizer_path):
        tokenizer.load(tokenizer_path)
    else:
        tokenizer.fit([train_text])
        tokenizer.save(tokenizer_path)

    train_ids = tokenizer.encode(train_text)
    val_ids = tokenizer.encode(val_text)

    train_dataset = WikiTextDataset(train_ids, seq_len=args.seq_len)
    val_dataset = WikiTextDataset(val_ids, seq_len=args.seq_len)
    loader_kwargs = {
        "batch_size": args.batch_size,
        "num_workers": args.num_workers,
        "pin_memory": (device.type == 'cuda'),
    }
    if device.type == 'cuda' and hasattr(DataLoader, '__init__') and 'pin_memory_device' in DataLoader.__init__.__code__.co_varnames:
        loader_kwargs["pin_memory_device"] = str(device)
    if args.num_workers > 0:
        loader_kwargs["persistent_workers"] = True

    train_loader = DataLoader(train_dataset, shuffle=True, **loader_kwargs)
    val_loader = DataLoader(val_dataset, shuffle=False, **loader_kwargs)


    config = StarLightConfig(
        vocab_size=tokenizer.vocab_size,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        num_heads=args.num_heads,
        max_seq_len=args.seq_len,
        use_lyap_reg=True,
        use_rank_anchor=True,
        norm_first=True,
        tie_weights=True,
        use_compile=args.compile,
    )
    model = StarLightModel(config).to(device)
    param_count = sum(p.numel() for p in model.parameters()) / 1e6
    logger.info(f"模型参数量: {param_count:.2f}M")

    trainer = StarLightTrainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        lr=args.lr,
        weight_decay=args.weight_decay,
        max_grad_norm=args.max_grad_norm,
        grad_accum_steps=args.grad_accum,
        warmup_steps=args.warmup_steps,
        T_0=args.T_0,
        checkpoint_dir=ckpt_dir,
        log_interval=args.log_interval,
        device=device,
    )


    if args.resume:
        trainer.load_checkpoint(args.resume)

    trainer.train(num_epochs=args.epochs)
    logger.info("StarLight 训练完成")
    return ckpt_dir






def _load_chaos_nn():
    from DeeNeuralNetwork.chaos_neural_network import ChaosNeuralNetwork, SecurityManager
    return ChaosNeuralNetwork, SecurityManager


def _generate_lorenz_trajectory(n: int = 4096, dt: float = 0.01,
                                sigma: float = 10.0, rho: float = 28.0,
                                beta: float = 8.0 / 3.0) -> torch.Tensor:
    
    traj = torch.zeros(n, 3)
    traj[0] = torch.tensor([1.0, 1.0, 1.0])
    for i in range(1, n):
        x, y, z = traj[i - 1]
        dx = sigma * (y - x) * dt
        dy = (x * (rho - z) - y) * dt
        dz = (x * y - beta * z) * dt
        traj[i] = torch.tensor([x + dx, y + dy, z + dz])
    return traj


def train_chaos_nn(args):
    
    logger.info("=" * 60)
    logger.info("  ChaosNN 训练启动")
    logger.info("=" * 60)

    ChaosNeuralNetwork, SecurityManager = _load_chaos_nn()
    device = torch.device(args.device)

    security = SecurityManager()
    model = ChaosNeuralNetwork(
        input_size=args.chaos_input_size,
        hidden_size=args.chaos_hidden_size,
        output_size=args.chaos_output_size,
        security_manager=security,
    ).to(device)

    window = model.input_size // 3
    out_win = model.output_size // 3 + 1
    traj = _generate_lorenz_trajectory(n=4096)


    traj_min = traj.min(dim=0, keepdim=True).values
    traj_max = traj.max(dim=0, keepdim=True).values
    traj = (traj - traj_min) / (traj_max - traj_min + 1e-8) * 8.0 - 4.0

    feats, tgts = [], []
    for i in range(len(traj) - window - out_win):
        feats.append(traj[i:i + window].flatten())
        tgt = traj[i + window:i + window + out_win].flatten()
        tgts.append(tgt[:model.output_size])
    X = torch.stack(feats).to(device)
    Y = torch.stack(tgts).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    ema_loss = None
    t0 = time.time()

    model.train()
    for step in range(1, args.steps + 1):
        idx = torch.randint(0, len(X), (args.batch_size,))
        bx, by = X[idx], Y[idx]
        optimizer.zero_grad(set_to_none=True)
        loss, p_t, aux_loss = model.train_step(bx, by)

        if not torch.isfinite(loss):
            logger.warning(f"[ChaosNN] step {step}: 非有限损失，跳过")
            continue

        loss.backward()
        gn = torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()

        lv = loss.item()
        ema_loss = lv if ema_loss is None else 0.95 * ema_loss + 0.05 * lv

        if step % args.log_interval == 0:
            logger.info(f"[ChaosNN] step {step}/{args.steps} loss={ema_loss:.6f} gn={float(gn):.4f}")

    ckpt_path = os.path.join(DEFAULTS['models_dir'], 'chaos_nn.pt')
    torch.save({'model_state': model.state_dict(), 'step': args.steps}, ckpt_path)
    logger.info(f"ChaosNN 已保存: {ckpt_path} | 总耗时 {time.time() - t0:.1f}s")
    return ckpt_path






def train_phased(args):
    
    logger.info("=" * 60)
    logger.info("  四阶段混沌训练启动")
    logger.info("=" * 60)

    chaos_train_path = os.path.join(os.path.dirname(os.path.dirname(_PROJECT_ROOT)), 'chaos_train.py')
    if not os.path.exists(chaos_train_path):

        chaos_train_path = 'F:/AGI/AGI/chaos_train.py'
    if not os.path.exists(chaos_train_path):
        raise FileNotFoundError(f"找不到 chaos_train.py: {chaos_train_path}")


    spec = importlib.util.spec_from_file_location("chaos_train", chaos_train_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["chaos_train"] = module
    spec.loader.exec_module(module)

    phase = args.phase
    steps = args.steps
    batch = args.batch_size
    seq = args.seq_len

    logger.info(f"运行 Phase {phase}: {getattr(module, 'PHASE_NAMES', {}).get(phase, 'Unknown')}")
    train_phase = getattr(module, 'train_phase')
    passed, metrics, model = train_phase(phase, steps=steps, batch=batch, seq=seq)

    save_dir = os.path.join(args.checkpoint_dir, 'phased')
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f'phase{phase}_final.pt')
    torch.save({
        'model_state_dict': model.module.state_dict() if hasattr(model, 'module') else model.state_dict(),
        'metrics': metrics,
        'passed': passed,
        'phase': phase,
    }, save_path)
    logger.info(f"Phase {phase} 模型已保存: {save_path} | 安全检查通过={passed}")
    return save_path






def _load_backend_engine():
    from backend.engine import AGIEngine
    return AGIEngine


def train_backend(args):
    
    logger.info("=" * 60)
    logger.info("  后端引擎训练启动")
    logger.info("=" * 60)

    AGIEngine = _load_backend_engine()
    engine = AGIEngine()

    result = engine.trainer.start(
        model_type=args.model_type,
        steps=args.steps,
        batch=args.batch_size,
        lr=args.lr,
        seq_len=args.seq_len,
        phase=args.phase,
    )
    logger.info(f"启动结果: {result}")

    if not result.get('ok'):
        return

    try:
        while True:
            status = engine.trainer.status()
            logger.info(
                f"[backend] step={status['step']}/{status['total_steps']} "
                f"loss={status.get('loss')} lyap={status.get('lyap')} "
                f"msg={status.get('message')} elapsed={status.get('elapsed')}s"
            )
            if not status.get('running', False):
                break
            time.sleep(2.0)
    except KeyboardInterrupt:
        logger.info("收到中断，停止训练...")
        engine.trainer.stop()

    logger.info("后端训练结束")
    return engine.trainer.status()






def _load_pure_chaos():
    
    import sys as _sys
    _argv = _sys.argv[:]
    import pure_chaos_lm_one_file as pclm
    _sys.argv = _argv
    return pclm


def train_pure_chaos(args):
    
    logger.info("=" * 60)
    logger.info("  纯混沌 LLM 训练启动（无注意力，HyperChaosArray 动力学）")
    logger.info("=" * 60)
    pclm = _load_pure_chaos()

    config = pclm.DEFAULT_CONFIG.copy()
    config.update({
        'vocab_size': getattr(args, 'vocab_size', 32000),
        'chaos_dim': getattr(args, 'chaos_dim', 256),
        'seq_len': getattr(args, 'seq_len', 32),
        'batch_size': getattr(args, 'batch_size', 4),
        'lr': getattr(args, 'lr', 1e-3),
        'train_epochs': getattr(args, 'epochs', 5),
        'device': getattr(args, 'device', 'cuda' if torch.cuda.is_available() else 'cpu'),
        'use_chaos_db': False,
        'num_chaos_layers': getattr(args, 'num_chaos_layers', 1),
        'use_batch_training': getattr(args, 'use_batch', False),
        'tokenizer_type': 'char',
    })


    tokenizer = pclm.CharTokenizer(config['vocab_size'])
    corpus_path = os.path.join(_PROJECT_ROOT, 'data', 'corpus.txt')
    if not os.path.exists(corpus_path):
        corpus_path = os.path.join(_PROJECT_ROOT, 'backend', 'data', 'corpus.txt')
    if os.path.exists(corpus_path):
        with open(corpus_path, 'r', encoding='utf-8') as f:
            text = f.read()
    else:
        import tempfile
        tmp = os.path.join(tempfile.gettempdir(), 'pclm_synth.txt')
        pclm.build_synthetic_corpus(tmp, lines=2000)
        with open(tmp, 'r', encoding='utf-8') as f:
            text = f.read()

    ids = tokenizer.encode(text)
    split = int(len(ids) * 0.9)
    train_ds = pclm.TokenDataset(ids[:split], seq_len=config['seq_len'])
    val_ds = pclm.TokenDataset(ids[split:], seq_len=config['seq_len'])
    train_loader = DataLoader(train_ds, batch_size=config['batch_size'], shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=config['batch_size'], shuffle=False)

    ckpt_dir = os.path.join(args.checkpoint_dir, 'pure_chaos')
    result = pclm.train_chaos_llm(config, train_loader, val_loader,
                                  checkpoint_dir=ckpt_dir, run_id='pure_chaos_trainall')
    logger.info(f"纯混沌 LLM 训练完成: {ckpt_dir}（RAM store 条目: {list(result.get('ram_store').names()) if result.get('ram_store') else 'n/a'}）")
    return ckpt_dir






def train_all(args):
    
    logger.info("=" * 60)
    logger.info("  AGIPyAG 全模块训练流水线")
    logger.info("=" * 60)

    results = {}


    starlight_args = argparse.Namespace(**vars(args))
    starlight_args.epochs = max(1, args.epochs)
    results['starlight'] = train_starlight(starlight_args)


    chaos_args = argparse.Namespace(**vars(args))
    results['chaos_nn'] = train_chaos_nn(chaos_args)


    phased_args = argparse.Namespace(**vars(args))
    phased_args.phase = 4
    results['phased'] = train_phased(phased_args)

    logger.info("=" * 60)
    logger.info("  全模块训练完成")
    for k, v in results.items():
        logger.info(f"  {k}: {v}")
    logger.info("=" * 60)
    return results






def main():
    parser = argparse.ArgumentParser(description='AGIPyAG 统一训练入口')
    subparsers = parser.add_subparsers(dest='command', required=True)


    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--device', type=str, default=DEFAULTS['device'])
    common.add_argument('--data_dir', type=str, default=DEFAULTS['data_dir'])
    common.add_argument('--checkpoint_dir', type=str, default=DEFAULTS['checkpoint_dir'])
    common.add_argument('--batch_size', type=int, default=4)
    common.add_argument('--lr', type=float, default=3e-4)
    common.add_argument('--max_grad_norm', type=float, default=1.0)
    common.add_argument('--log_interval', type=int, default=10)
    common.add_argument('--num_workers', type=int, default=0, help='DataLoader 工作进程数')
    common.add_argument('--compile', action='store_true', help='启用 torch.compile（StarLight）')


    p_star = subparsers.add_parser('starlight', parents=[common], help='训练 StarLight 模型')
    p_star.add_argument('--vocab_size', type=int, default=8000)
    p_star.add_argument('--seq_len', type=int, default=128)
    p_star.add_argument('--hidden_dim', type=int, default=256)
    p_star.add_argument('--num_layers', type=int, default=4)
    p_star.add_argument('--num_heads', type=int, default=8)
    p_star.add_argument('--grad_accum', type=int, default=4)
    p_star.add_argument('--epochs', type=int, default=5)
    p_star.add_argument('--weight_decay', type=float, default=0.01)
    p_star.add_argument('--warmup_steps', type=int, default=100)
    p_star.add_argument('--T_0', type=int, default=500)
    p_star.add_argument('--resume', type=str, default=None, help='恢复检查点文件名')


    p_chaos = subparsers.add_parser('chaos_nn', parents=[common], help='训练 ChaosNN')
    p_chaos.add_argument('--steps', type=int, default=2000)
    p_chaos.add_argument('--chaos_input_size', type=int, default=24)
    p_chaos.add_argument('--chaos_hidden_size', type=int, default=96)
    p_chaos.add_argument('--chaos_output_size', type=int, default=24)


    p_phased = subparsers.add_parser('phased', parents=[common], help='四阶段混沌训练')
    p_phased.add_argument('--phase', type=int, default=4, choices=[1, 2, 3, 4])
    p_phased.add_argument('--steps', type=int, default=300)
    p_phased.add_argument('--seq_len', type=int, default=256)


    p_backend = subparsers.add_parser('backend', parents=[common], help='后端引擎课程式训练')
    p_backend.add_argument('--model_type', type=str, default='full',
                           choices=['starlight', 'chaos', 'full'])
    p_backend.add_argument('--steps', type=int, default=1000)
    p_backend.add_argument('--seq_len', type=int, default=128)
    p_backend.add_argument('--phase', type=int, default=4)


    p_pure = subparsers.add_parser('pure_chaos', parents=[common], help='纯混沌 LLM 训练（无注意力）')
    p_pure.add_argument('--vocab_size', type=int, default=32000)
    p_pure.add_argument('--chaos_dim', type=int, default=256)
    p_pure.add_argument('--seq_len', type=int, default=32)
    p_pure.add_argument('--epochs', type=int, default=5)
    p_pure.add_argument('--num_chaos_layers', type=int, default=1)
    p_pure.add_argument('--use_batch', action='store_true',
                        help='batch 并行训练（状态批量化 [B,dim]，消除 batch 内序列串行）')


    p_all = subparsers.add_parser('all', parents=[common], help='顺序运行全部模块')
    p_all.add_argument('--vocab_size', type=int, default=8000)
    p_all.add_argument('--seq_len', type=int, default=128)
    p_all.add_argument('--hidden_dim', type=int, default=256)
    p_all.add_argument('--num_layers', type=int, default=4)
    p_all.add_argument('--num_heads', type=int, default=8)
    p_all.add_argument('--grad_accum', type=int, default=4)
    p_all.add_argument('--epochs', type=int, default=3)
    p_all.add_argument('--steps', type=int, default=1000)
    p_all.add_argument('--weight_decay', type=float, default=0.01)
    p_all.add_argument('--warmup_steps', type=int, default=100)
    p_all.add_argument('--T_0', type=int, default=500)

    args = parser.parse_args()

    try:
        if args.command == 'starlight':
            train_starlight(args)
        elif args.command == 'chaos_nn':
            train_chaos_nn(args)
        elif args.command == 'phased':
            train_phased(args)
        elif args.command == 'backend':
            train_backend(args)
        elif args.command == 'pure_chaos':
            train_pure_chaos(args)
        elif args.command == 'all':
            train_all(args)
    except Exception as e:
        logger.error(f"训练失败: {e}")
        logger.error(traceback.format_exc())
        raise


if __name__ == '__main__':
    main()
