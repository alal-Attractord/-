#!/usr/bin/env python3




































import json
import os
import sys
import threading
import time

import numpy as np
import torch

sys_ = os.path.dirname(os.path.abspath(__file__))
if sys_ not in sys.path:
    sys.path.insert(0, sys_)

import wm_v2 as W
import koopman_core as KC

DEV = W.DEV
CKPT = os.path.join(sys_, "data", "koopman")
DEFAULT_BACKBONE = "koopman_adapt"
_LOCK = threading.RLock()
_ENGINE = None


class KoopmanEngine:
    

    def __init__(self, ckpt_dir=CKPT, backbone=DEFAULT_BACKBONE):
        self.ckpt_dir = ckpt_dir
        self.backbone = backbone
        self.ready = False
        self.missing = []
        self.meta = {}
        self.env = None
        self.models = {}
        self.active = None
        self._spec = None


    @staticmethod
    def _env_from_meta(meta):
        env = W.get_env(meta.get("env", "Lorenz"))
        env.mu = np.asarray(meta["mu"], dtype=np.float64)
        env.sd = np.asarray(meta["sd"], dtype=np.float64)
        env.lo_t = torch.tensor(env.lo, dtype=torch.float32)
        env.hi_t = torch.tensor(env.hi, dtype=torch.float32)
        return env

    def load(self):
        with _LOCK:
            if self.ready:
                return self
            mp = os.path.join(self.ckpt_dir, "meta.json")
            if not os.path.exists(mp):
                self.missing.append("meta.json")
                return self
            with open(mp, encoding="utf-8") as f:
                self.meta = json.load(f)
            self.env = self._env_from_meta(self.meta)
            for tag in ("koopman_fix", "koopman_adapt"):
                p = os.path.join(self.ckpt_dir, f"{tag}.pt")
                if not os.path.exists(p):
                    self.missing.append(f"{tag}.pt")
                    continue
                ck = torch.load(p, map_location="cpu", weights_only=False)
                cfg = ck["cfg"]
                m = KC.KoopmanWM(self.env, dim=cfg["dim"], adaptive=cfg["adaptive"],
                                 n_basis=cfg.get("n_basis", 0)).to(DEV)
                m.load_state_dict(ck["state_dict"])
                m.eval()
                self.models[tag] = {"model": m, "ckpt": ck}
            if self.models:
                self.active = (self.backbone if self.backbone in self.models
                               else next(iter(self.models)))
            self.ready = bool(self.models)
            return self


    def status(self):
        return {
            "ready": self.ready, "device": DEV, "missing": list(self.missing),
            "backbone": self.active, "loaded": sorted(self.models.keys()),
            "params": {k: v["ckpt"].get("params", 0) for k, v in self.models.items()},
            "metrics": {k: v["ckpt"].get("metrics", {}) for k, v in self.models.items()},
            "spectrum": {k: v["ckpt"].get("spectrum", {}) for k, v in self.models.items()},
            "env": self.meta.get("env"), "version": self.meta.get("version"),
        }

    def capability(self):
        
        return {
            "verified_wins": [
                {"axis": "短程预测 @1", "koopman_adapt": 0.0055, "lstm": 0.0164,
                 "tfwm": 0.0345, "verdict": "胜 LSTM 约 3.0×，胜 TFWM 约 6.3×"},
                {"axis": "短程预测 @5", "koopman_adapt": 0.0116, "lstm": 0.0161,
                 "tfwm": 0.0383, "verdict": "胜"},
                {"axis": "参数效率（全视界）", "koopman_fix_params": 22403,
                 "tfwm_params": 245475, "verdict": "少 11× 参数，却在每个视界都优于 TFWM"},
            ],
            "verified_losses": [
                {"axis": "中程 @20", "koopman": 0.2792, "lstm": 0.0530, "verdict": "输 5.3×"},
                {"axis": "长程 @160 / VPT", "koopman": 0.7491, "VPT160": 21,
                 "lstm": 0.5871, "lstm_VPT160": 75, "verdict": "输；有效预测时长不足 LSTM 的 1/3"},
                {"axis": "原生 OOD 判别", "koopman_spectral_best_auc": 0.616,
                 "trivial_baseline_auc": 0.603,
                 "verdict": "去尺度后 ≈0.5，与平凡基线无显著差 → **不成立**"},
            ],
            "not_claimed": ["谱分析原生支持幻觉/OOD 检出", "看齐/超越 Transformer 生成能力"],
            "evidence": {
                "e1_e2": "wm_results_koopman.json",
                "report": "KOOPMAN_E1E2_2026-09-11.md",
                "protocol": "Lorenz-3；T=16；同一 train/test 划分与 1200–1500 步训练；"
                            "对照 LSTM(h=96,39K) 与 TFWM(d=96,L=2,245K)"},
        }


    @torch.no_grad()
    def forecast(self, x_window, horizons=(1, 5, 20, 60, 160)):
        




        if not self.ready:
            return None
        x = np.asarray(x_window, dtype=np.float64)
        if x.ndim == 1:
            x = x[None]
        xn = self.env.normalize(x).astype(np.float32)
        s = torch.tensor(xn[None], device=DEV, dtype=torch.float32)
        Kmax = int(max(horizons))
        rec = self.models[self.active]["model"]
        with torch.no_grad():
            traj = rec.forward_roll(s, Kmax)[0].cpu().numpy()
        raw = self.env.denormalize(traj)
        out = {"backbone": self.active, "K_max": Kmax, "horizons": {}}
        for h in horizons:
            out["horizons"][str(h)] = raw[int(h) - 1].tolist()
        return out

    @torch.no_grad()
    def spectrum(self, x_last):
        
        if not self.ready:
            return None
        x = np.asarray(x_last, dtype=np.float64).reshape(-1)[:self.env.obs_dim]
        xn = self.env.normalize(x[None]).astype(np.float32)
        t = torch.tensor(xn, device=DEV, dtype=torch.float32)
        rec = self.models[self.active]["model"]
        K = rec.raw_K(t).cpu().numpy()
        if K.ndim > 2:
            K = K.reshape(K.shape[-2], K.shape[-1])
        lam = np.linalg.eigvals(K)
        r = np.abs(lam)
        top = np.argsort(-r)[:5]
        return {
            "rho": float(r.max()),
            "unit_dist": float(np.abs(r - 1.0).min()),
            "imag_frac": float((np.abs(lam.imag) > 1e-6 * np.maximum(np.abs(lam.real), 1e-12)).mean()),
            "top5": [{"abs": float(r[i]), "real": float(lam[i].real), "imag": float(lam[i].imag)}
                     for i in top],
            "note": "诊断量；本轮实验未支持其作为 OOD/风险检测器（见 capability）",
        }














    def _spec_decompose(self, x_window=None):
        
        if not self.ready:
            return None
        if x_window is None:
            x_window = self._seed_window()
        x = np.asarray(x_window, dtype=np.float64)
        if x.ndim == 3:
            x = x[0]
        if x.ndim == 2:
            x = x[-1]
        xn = self.env.normalize(x[None]).astype(np.float32)
        t = torch.tensor(xn, device=DEV, dtype=torch.float32)
        rec = self.models[self.active]["model"]
        with torch.no_grad():
            K = rec.raw_K(t).detach().cpu().numpy()
            if K.ndim > 2:
                K = K.reshape(K.shape[-2], K.shape[-1])
            z0 = rec._lift(t)[0].detach().cpu().numpy().astype(complex)
        lam, V = np.linalg.eig(K)
        nb = int(getattr(rec, "n_basis", 0))
        self._spec = {"lam": lam, "V": V, "Vinv": np.linalg.inv(V),
                      "K": K, "z0": z0, "x": x, "n_basis": nb,
                      "exact": nb == 0,
                      "stamp": time.strftime("%Y-%m-%d %H:%M:%S")}
        return self._spec

    def spectral_forecast(self, horizons=(1, 5, 20, 80, 160)):
        
        s = self._spec or self._spec_decompose()
        if not s:
            return None
        rec = self.models[self.active]["model"]
        c = s["Vinv"] @ s["z0"]
        exact = bool(s.get("exact", True))
        t0 = time.perf_counter()
        out = {"backbone": self.active, "method": "spectral", "exact": exact,
               "note": (None if exact else
                        "算子自适应（n_basis>0）⇒ K 随 z 变化，K^H=VΛ^H V⁻¹ 仅在 K 常数时成立；"
                        "此处为一次分解的**近似**，精确结果请用 forecast()"),
               "horizons": {}}
        with torch.no_grad():
            for h in horizons:
                z = s["V"] @ (s["lam"] ** int(h) * c)
                zt = torch.tensor(np.real(z)[None], device=DEV, dtype=torch.float32)
                xh = rec.out(zt)[0].cpu().numpy()
                out["horizons"][str(h)] = self.env.denormalize(xh).tolist()
        out["elapsed_ms"] = round((time.perf_counter() - t0) * 1000, 3)
        return out

    def chaos_diag(self):
        








        s = self._spec or self._spec_decompose()
        if not s:
            return None
        lam = s["lam"]
        r = np.abs(lam)
        dt = float(getattr(self.env, "dt", 1.0))
        rho = float(r.max())
        return {
            "rho_max": rho,
            "lyapunov_est": float(np.log(max(rho, 1e-12)) / dt),
            "dt": dt,
            "n_modes": int(len(lam)),
            "imag_frac": float((np.abs(np.angle(lam)) > 0.1).mean()),
            "decay_steps_top3": [round(float(-1.0 / np.log(max(v, 1e-9))), 2)
                                 for v in np.sort(r)[::-1][:3]],
            "interpretation": ("收缩：状态每步被压缩，长程会衰减回均值"
                               if rho < 1 else "发散：正 Lyapunov，轨迹对初值敏感"),
        }

    def attribution(self, h=20, top_k=3):
        
        s = self._spec or self._spec_decompose()
        if not s:
            return None
        lam, V, Vinv = s["lam"], s["V"], s["Vinv"]
        c = Vinv @ s["z0"]
        contrib = np.abs(lam ** int(h) * c) * np.linalg.norm(V, axis=0)
        total = float(contrib.sum()) + 1e-12
        order = np.argsort(-contrib)[:top_k]
        return {"horizon": int(h), "top": [
            {"mode": int(i),
             "modulus": round(float(abs(lam[i])), 5),
             "freq_rad": round(float(abs(np.angle(lam[i]))), 5),
             "decay_steps": round(float(-1.0 / np.log(max(abs(lam[i]), 1e-9))), 2),
             "share": round(float(contrib[i] / total), 4)} for i in order]}


    def run(self, text="", with_mpc=False, max_new=60):
        t0 = time.time()
        if not self.ready:
            return {"ok": False, "error": f"Koopman 权重缺失: {self.missing}（先跑 train_koopman.py）",
                    "status": self.status()}
        raw, xn = self._seed_window()
        fc = self.forecast(raw)
        sp = self.spectrum(raw[-1])
        wave, judge = _describe(fc, self.env)
        speech = _speak(wave, judge, max_new)
        res = {"ok": True, "backbone": self.active, "text": text,
               "wave": wave, "judge": judge, "result": speech,
               "forecast": fc, "spectrum": sp,
               "capability": self.capability(),
               "status": self.status(),
               "signal_validated": False,
               "elapsed_ms": round((time.time() - t0) * 1000, 1)}
        return res

    def _seed_window(self, T=16, seed=42, obs=None):
        env = self.env
        if obs is not None:
            s = np.asarray(obs, dtype=np.float64).reshape(-1)[:env.obs_dim]
            xs, cur = [s.copy()], s.copy()
            for _ in range(T - 1):
                cur = cur - env.dt * env.deriv(cur)
                xs.append(cur.copy())
            raw = np.asarray(xs[::-1], dtype=np.float32)
        else:
            rng = np.random.default_rng(int(seed))
            s = env.lo + rng.random(env.obs_dim) * (env.hi - env.lo) * 0.3 + 0.1
            for _ in range(4000):
                s = env.step(s)
            xs = []
            for _ in range(T):
                s = env.step(s)
                xs.append(s.copy())
            raw = np.asarray(xs, dtype=np.float32)
        return raw, env.normalize(raw).astype(np.float32)


def _describe(fc, env):
    
    if fc is None:
        return "未知", "无预测"
    env_ = env
    span = float(np.linalg.norm(np.asarray(env_.hi) - np.asarray(env_.lo)))
    h1 = np.asarray(fc["horizons"]["1"])
    hN = np.asarray(fc["horizons"][str(fc["K_max"])])
    r = float(np.linalg.norm(hN - h1)) / max(span, 1e-6)
    if r < 0.15:
        return "波动不大", "系统平稳"
    if r < 0.35:
        return "波动正在加大", "进入不稳定窗口"
    return "轨迹快速发散", "当前处于敏感区域"


def _speak(wave, judge, max_new=60):
    try:
        import importlib
        ac = importlib.import_module("agent_core")
        return ac.ask(wave, judge, max_new=max_new)
    except Exception as e:
        return (f"当前{wave}，预测后续轨迹{'难以精确收敛' if '发散' in wave else '会保持在吸引子内'}。"
                f"判断：{judge}。建议：保持观察，不干预。（语言脑不可用：{str(e)[:60]}）")


def get_engine():
    global _ENGINE
    with _LOCK:
        if _ENGINE is None:
            _ENGINE = KoopmanEngine().load()
        return _ENGINE


def run(text="", **kw):
    return get_engine().run(text, **kw)


def answer(text="", **kw):
    r = run(text, **kw)
    return r.get("result", r.get("error", "")), r


if __name__ == "__main__":
    e = get_engine()
    print("status:", json.dumps({k: v for k, v in e.status().items()
                                 if k in ("ready", "backbone", "loaded", "params", "missing")},
                                ensure_ascii=False))
    out = e.run("Koopman 波形诊断")
    print("wave:", out["wave"], "| judge:", out["judge"])
    print("forecast @1/@20/@160:", out["forecast"]["horizons"]["1"],
          out["forecast"]["horizons"]["20"], out["forecast"]["horizons"]["160"])
    print("spectrum:", json.dumps(out["spectrum"], ensure_ascii=False)[:300])
    print("文本:", out["result"])
