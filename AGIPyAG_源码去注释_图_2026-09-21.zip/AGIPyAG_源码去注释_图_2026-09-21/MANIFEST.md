# AGIPyAG 活代码（去注释）+ 图片 打包 MANIFEST

- 生成时间：2026-09-21 12:55:07
- 源目录：`F:\ASI`
- 归档：`F:\AGIPyAG_源码去注释_图_2026-09-21.zip`
- **只读**：源文件未改动。

## 1 源码去注释

| 项 | 值 |
|---|---|
| 源码文件数 | 57 |
| 去注释前 | 745.5 KB |
| 去注释后 | 619.6 KB |
| 缩减 | 16.9% |
| 处理方式 | Python：tokenize 定位 COMMENT + ast 定位 docstring，按字符区间空白化（保留换行，行号不变）|
| **硬校验** | 去注释后 AST 必须 == 原 AST 去掉 docstring 节点；不等则拒绝写入并回退原文件 |
| 失败/回退 | 0 个 |

## 2 图片

共 **65** 张（含顶层图、`figs/`、`webui` 资产）：

```
OURS_PHR_FIG_2026-09-18.png
REGIME_SCAN_FIG_2026-09-18.png
_t2.png
_t3.png
chaos_basis_verdict.png
chaos_c3_partial_obs.png
chaos_capability_matrix.png
chaos_coupling.png
chaos_demo_live.png
chaos_heatmap.png
chaos_longmem.png
chaos_lorenz_extrap.png
chaos_pca3d.png
chaos_phase.png
chaos_probe_auc.png
chaos_small_vs_big.png
chaos_statistics.png
chaos_vs_transformer_lm.png
core_lorenz_verdict.png
dca_verdict.png
ext_mem_verdict.png
fig1_flops_complexity.png
fig2_latency.png
fig3_speedup.png
fig4_theory_vs_measured.png
fig5_inference - 副本.png
fig5_inference.png
fig6_train_vs_inference.png
figs/autoreg_room.png
figs/bilin_verdict.png
figs/ceiling_verdict.png
figs/chaos_landscape_a.png
figs/chaos_landscape_b.png
figs/combined_verdict.png
figs/fix_attribution.png
figs/lga_G_impact.png
figs/lga_G_verdict.png
figs/mpath.png
figs/param_vs_nonparam.png
figs/r15_r8_verdict.png
figs/real_arms.png
figs/real_battle.png
figs/real_param.png
figs/real_s0.png
figs/real_tau.png
figs/real_verdict.png
figs/why_mlp.png
final_verdict.png
koopman_lm_bench.png
koopman_tower_verdict.png
native_ops_v2_seeds.png
native_ops_v2_verdict.png
native_ops_verdict.png
res_final_verdict.png
wm_ablate_branch.png
wm_gap_analysis.png
wm_mpc.png
wm_multistep_rmse.png
wm_multistep_vpt.png
wm_u1_interaction.png
wm_u2_hybrid.png
wm_u3_vision.png
wm_u4_scenes.png
wm_u5_lyap.png
wm_vision.png
```

## 3 目录结构

```
AGIPyAG_源码去注释_图_2026-09-21/MANIFEST.md
AGIPyAG_源码去注释_图_2026-09-21/src_nocomment/<原相对路径>     去注释源码
AGIPyAG_源码去注释_图_2026-09-21/images/<原相对路径>            图片
AGIPyAG_源码去注释_图_2026-09-21/strip_stats.json               逐文件去注释统计
```